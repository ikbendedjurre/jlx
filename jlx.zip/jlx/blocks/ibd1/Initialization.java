package jlx.blocks.ibd1;

import jlx.asal.j.JVoid;

public class Initialization extends Operation<JVoid> {
	public Initialization(String code0, String... code) {
		super(true, code0, code);
	}
}
