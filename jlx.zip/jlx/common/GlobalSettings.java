package jlx.common;

public class GlobalSettings {
	public static boolean areDataFlowsGrouped() {
		return true;
	}
}
