package jlx.utils;

import java.util.*;

public class PostMortem {
	public static List<String> msgs = new ArrayList<String>();
}
