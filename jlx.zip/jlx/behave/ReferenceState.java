package jlx.behave;

public abstract class ReferenceState<T extends StateMachine> extends State {
	//Empty.
}
