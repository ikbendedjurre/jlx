package jlx.behave;

public abstract class CompositeState extends State {
	//Empty.
}
