package jlx.behave;

public abstract class JunctionVertex extends Vertex {
	//Empty.
}
