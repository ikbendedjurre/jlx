package jlx.behave;

public class TerminateVertex extends Vertex {
	@Override
	public final Outgoing[] getOutgoing() {
		return null;
	}
}
