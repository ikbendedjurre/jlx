package jlx.behave;

public interface StateMachine {
	//Empty.
}
