package jlx.behave;

public abstract class InitialState extends Vertex {
	@Override
	public final Incoming[] getIncoming() {
		return null;
	}
}
