package jlx.behave;

public abstract class ForkVertex extends Vertex {
	//Empty.
}
