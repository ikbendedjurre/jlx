package jlx.behave;

public abstract class ChoiceVertex extends Vertex {
	//Empty.
}
