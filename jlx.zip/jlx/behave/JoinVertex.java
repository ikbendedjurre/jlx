package jlx.behave;

public class JoinVertex extends Vertex {
	//Empty.
}
