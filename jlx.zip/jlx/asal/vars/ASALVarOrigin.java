package jlx.asal.vars;

public enum ASALVarOrigin {
	STM_VAR,
	STM_PORT,
	FCT_PARAM,
}
