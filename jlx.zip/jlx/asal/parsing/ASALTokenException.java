package jlx.asal.parsing;

@SuppressWarnings("serial")
public class ASALTokenException extends Exception {
	public ASALTokenException(String message) {
		super(message);
	}
}
