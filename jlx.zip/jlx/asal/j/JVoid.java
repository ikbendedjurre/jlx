package jlx.asal.j;

public class JVoid extends JUserType<JVoid> {
	//Empty.
}
