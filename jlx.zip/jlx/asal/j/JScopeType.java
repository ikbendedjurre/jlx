package jlx.asal.j;

public enum JScopeType {
	INIT,
	OPERATION,
	BLOCK
}
