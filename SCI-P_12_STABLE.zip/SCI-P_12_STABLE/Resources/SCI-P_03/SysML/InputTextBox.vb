Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.InputTextBox
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class InputTextBox : Inherits TextBox
    Protected outp As OOutputPort(Of String)
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Public Sub send(ByVal Ph As OPhase) Handles SimCore.OnWriteOutputs
      ' ## VBOperationBody [c13f9e4b-ab9e-4e06-b574-7ff1c0a1c694] 
      outp.SetValue(Me.Text)
      ' ## VBOperationBody End 
    End Sub
    
  End Class
End Namespace
