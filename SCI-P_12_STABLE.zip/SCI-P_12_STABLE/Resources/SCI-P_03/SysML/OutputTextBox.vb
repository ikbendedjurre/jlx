Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.OutputTextBox
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class OutputTextBox : Inherits TextBox
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Protected inp As OInputPort(Of String)
    Public Sub receive(ByVal Ph As OPhase) Handles SimCore.OnReadInputs
      ' ## VBOperationBody [8991f1ca-1bf1-4b38-91ce-58f8fff570b8] 
      Me.Text = inp.GetLatchedValue()
      ' ## VBOperationBody End 
    End Sub
    
  End Class
End Namespace
