Option Explicit On

' ## Imports [68b91994-3af0-42ba-a5b4-932ddb0cf7e9] 
Imports SIMULATOR.SubS_P_SRPackage
' ## Imports End 

Namespace SIMULATOR
  Partial Public Class SubS_P_SRForm : Inherits PredefinedControls.OFormBase
    
    ' ## Designer [68b91994-3af0-42ba-a5b4-932ddb0cf7e9] 
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
    If disposing AndAlso components IsNot Nothing Then
    components.Dispose()
    End If
    Finally
    MyBase.Dispose(disposing)
    End Try
    End Sub
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Me.Label25 = New System.Windows.Forms.Label()
    Me.Label24 = New System.Windows.Forms.Label()
    Me.Label50 = New System.Windows.Forms.Label()
    Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
    Me.TabPage2 = New System.Windows.Forms.TabPage()
    Me.GroupBox22 = New System.Windows.Forms.GroupBox()
    Me.Label31 = New System.Windows.Forms.Label()
    Me.Label30 = New System.Windows.Forms.Label()
    Me.D51_F_EST_EfeS_Gen_SR_state1 = New SIMULATOR.SubS_P_SRPackage.D51_F_EST_EfeS_Gen_SR_state()
    Me.Label32 = New System.Windows.Forms.Label()
    Me.Label29 = New System.Windows.Forms.Label()
    Me.Label35 = New System.Windows.Forms.Label()
    Me.T15_Msg_Initialisation_Completed1 = New SIMULATOR.SubS_P_SRPackage.T15_Msg_Initialisation_Completed()
    Me.T18_Start_Status_Report1 = New SIMULATOR.SubS_P_SRPackage.T18_Start_Status_Report()
    Me.T14_Msg_Start_Initialisation1 = New SIMULATOR.SubS_P_SRPackage.T14_Msg_Start_Initialisation()
    Me.Label34 = New System.Windows.Forms.Label()
    Me.Label96 = New System.Windows.Forms.Label()
    Me.D50_PDI_Connection_State_S1 = New SIMULATOR.SubS_P_SRPackage.D50_PDI_Connection_State_S()
    Me.DT13_Result1 = New SIMULATOR.SubS_P_SRPackage.DT13_Result()
    Me.DT13_Checksum_data1 = New SIMULATOR.SubS_P_SRPackage.DT13_Checksum_data()
    Me.T12_Disconnect_SCP1 = New SIMULATOR.SubS_P_SRPackage.T12_Disconnect_SCP()
    Me.T13_Msg_PDI_Version_Check1 = New SIMULATOR.SubS_P_SRPackage.T13_Msg_PDI_Version_Check()
    Me.Label28 = New System.Windows.Forms.Label()
    Me.GroupBox21 = New System.Windows.Forms.GroupBox()
    Me.Label100 = New System.Windows.Forms.Label()
    Me.T8_Cd_Initialisation_Request12 = New SIMULATOR.SubS_P_SRPackage.T8_Cd_Initialisation_Request1()
    Me.DT7_PDI_Version11 = New SIMULATOR.SubS_P_SRPackage.DT7_PDI_Version1()
    Me.Label99 = New System.Windows.Forms.Label()
    Me.Label98 = New System.Windows.Forms.Label()
    Me.T12_Terminate_SCP_Connection_I1 = New SIMULATOR.SubS_P_SRPackage.T12_Terminate_SCP_Connection_I()
    Me.T7_Cd_PDI_Version_Check11 = New SIMULATOR.SubS_P_SRPackage.T7_Cd_PDI_Version_Check1()
    Me.T6_Establish_SCP_Connection_I1 = New SIMULATOR.SubS_P_SRPackage.T6_Establish_SCP_Connection_I()
    Me.Label95 = New System.Windows.Forms.Label()
    Me.D50_PDI_Connection_State1 = New SIMULATOR.SubS_P_SRPackage.D50_PDI_Connection_State()
    Me.GroupBox10 = New System.Windows.Forms.GroupBox()
    Me.T21_Data_Update_Finished1 = New SIMULATOR.SubS_P_SRPackage.T21_Data_Update_Finished()
    Me.Label69 = New System.Windows.Forms.Label()
    Me.Label39 = New System.Windows.Forms.Label()
    Me.Label38 = New System.Windows.Forms.Label()
    Me.T20_Ready_For_Update_Of_Data1 = New SIMULATOR.SubS_P_SRPackage.T20_Ready_For_Update_Of_Data()
    Me.T19_Validate_Data1 = New SIMULATOR.SubS_P_SRPackage.T19_Validate_Data()
    Me.TabControl2 = New System.Windows.Forms.TabControl()
    Me.TabPage6 = New System.Windows.Forms.TabPage()
    Me.GroupBox9 = New System.Windows.Forms.GroupBox()
    Me.DT20_Position1 = New SIMULATOR.SubS_P_SRPackage.DT20_Position()
    Me.T02_Msg_Point_Position1 = New SIMULATOR.SubS_P_SRPackage.T2_Msg_Point_Position()
    Me.Label42 = New System.Windows.Forms.Label()
    Me.Label37 = New System.Windows.Forms.Label()
    Me.Label36 = New System.Windows.Forms.Label()
    Me.GroupBox11 = New System.Windows.Forms.GroupBox()
    Me.T5_Info_End_Position_Arrived1 = New SIMULATOR.SubS_P_SRPackage.T5_Info_End_Position_Arrived()
    Me.Label101 = New System.Windows.Forms.Label()
    Me.Label67 = New System.Windows.Forms.Label()
    Me.D25_Redrive1 = New SIMULATOR.SubS_P_SRPackage.D25_Redrive()
    Me.D06_Detection_State1 = New SIMULATOR.SubS_P_SRPackage.D6_Detection_State()
    Me.Label84 = New System.Windows.Forms.Label()
    Me.T12_Reset_PMs1 = New SIMULATOR.SubS_P_SRPackage.T12_Reset_PMs()
    Me.Label71 = New System.Windows.Forms.Label()
    Me.D05_Drive_State1 = New SIMULATOR.SubS_P_SRPackage.D5_Drive_State()
    Me.T07_Information_Out_Of_Sequence1 = New SIMULATOR.SubS_P_SRPackage.T7_Information_Out_Of_Sequence()
    Me.T06_Information_Trailed_Point1 = New SIMULATOR.SubS_P_SRPackage.T6_Information_Trailed_Point()
    Me.Label51 = New System.Windows.Forms.Label()
    Me.T04_Information_No_End_Position1 = New SIMULATOR.SubS_P_SRPackage.T4_Information_No_End_Position()
    Me.Label19 = New System.Windows.Forms.Label()
    Me.Label54 = New System.Windows.Forms.Label()
    Me.Label53 = New System.Windows.Forms.Label()
    Me.Label52 = New System.Windows.Forms.Label()
    Me.Label41 = New System.Windows.Forms.Label()
    Me.Label40 = New System.Windows.Forms.Label()
    Me.D6_Move_Right1 = New SIMULATOR.SubS_P_SRPackage.D6_Move_Right()
    Me.D5_Move_Left1 = New SIMULATOR.SubS_P_SRPackage.D5_Move_Left()
    Me.TabPage7 = New System.Windows.Forms.TabPage()
    Me.TabPage4 = New System.Windows.Forms.TabPage()
    Me.GroupBox14 = New System.Windows.Forms.GroupBox()
    Me.Label63 = New System.Windows.Forms.Label()
    Me.Label62 = New System.Windows.Forms.Label()
    Me.Label61 = New System.Windows.Forms.Label()
    Me.Label60 = New System.Windows.Forms.Label()
    Me.Label59 = New System.Windows.Forms.Label()
    Me.Label58 = New System.Windows.Forms.Label()
    Me.Label57 = New System.Windows.Forms.Label()
    Me.Label48 = New System.Windows.Forms.Label()
    Me.D38_0085001 = New SIMULATOR.SubS_P_SRPackage.D38_Con_008500()
    Me.D37_0084001 = New SIMULATOR.SubS_P_SRPackage.D37_Con_008400()
    Me.D36_0083001 = New SIMULATOR.SubS_P_SRPackage.D36_Con_008300()
    Me.D35_0082001 = New SIMULATOR.SubS_P_SRPackage.D35_Con_008200()
    Me.D34_0080001 = New SIMULATOR.SubS_P_SRPackage.D34_Con_008000()
    Me.D33_0079001 = New SIMULATOR.SubS_P_SRPackage.D33_Con_007900()
    Me.D32_0076001 = New SIMULATOR.SubS_P_SRPackage.D32_Con_007600()
    Me.D30_0070001 = New SIMULATOR.SubS_P_SRPackage.D30_Con_007000()
    Me.TabPage3 = New System.Windows.Forms.TabPage()
    Me.GroupBox15 = New System.Windows.Forms.GroupBox()
    Me.GroupBox17 = New System.Windows.Forms.GroupBox()
    Me.Label79 = New System.Windows.Forms.Label()
    Me.PM2_Position_Out1 = New SIMULATOR.SubS_P_SRPackage.PM2_Position_Out()
    Me.Label74 = New System.Windows.Forms.Label()
    Me.PM2_Position1 = New SIMULATOR.SubS_P_SRPackage.PM2_Position()
    Me.PM2_Active1 = New SIMULATOR.SubS_P_SRPackage.PM2_Active()
    Me.Label68 = New System.Windows.Forms.Label()
    Me.GroupBox16 = New System.Windows.Forms.GroupBox()
    Me.Label78 = New System.Windows.Forms.Label()
    Me.PM1_Position_Out1 = New SIMULATOR.SubS_P_SRPackage.PM1_Position_Out()
    Me.Label73 = New System.Windows.Forms.Label()
    Me.PM1_Position1 = New SIMULATOR.SubS_P_SRPackage.PM1_Position()
    Me.GroupBox13 = New System.Windows.Forms.GroupBox()
    Me.D04_Con_tmax_Point_Operation2 = New SIMULATOR.SubS_P_SRPackage.D4_Con_tmax_Point_Operation()
    Me.Label43 = New System.Windows.Forms.Label()
    Me.GroupBox12 = New System.Windows.Forms.GroupBox()
    Me.DT01_Move_Point_Target2 = New SIMULATOR.SubS_P_SRPackage.DT1_Move_Point_Target()
    Me.T01_Cmd_Move_Point2 = New SIMULATOR.SubS_P_SRPackage.T1_Move_Point()
    Me.Label45 = New System.Windows.Forms.Label()
    Me.Label44 = New System.Windows.Forms.Label()
    Me.TabControl1 = New System.Windows.Forms.TabControl()
    Me.TabPage5 = New System.Windows.Forms.TabPage()
    Me.GroupBox7 = New System.Windows.Forms.GroupBox()
    Me.Label14 = New System.Windows.Forms.Label()
    Me.Label13 = New System.Windows.Forms.Label()
    Me.Label12 = New System.Windows.Forms.Label()
    Me.Label11 = New System.Windows.Forms.Label()
    Me.Label10 = New System.Windows.Forms.Label()
    Me.T12_Data_Installation_Successfully1 = New SIMULATOR.SubS_P_SRPackage.T12_Data_Installation_Successfully()
    Me.T6_Data_Up_To_Date1 = New SIMULATOR.SubS_P_SRPackage.T6_Data_Up_To_Date()
    Me.T11_Data_Invalid1 = New SIMULATOR.SubS_P_SRPackage.T11_Data_Invalid()
    Me.Label9 = New System.Windows.Forms.Label()
    Me.T7_Data_Not_Up_To_Date1 = New SIMULATOR.SubS_P_SRPackage.T7_Data_Not_Up_To_Date()
    Me.T10_Data_Valid1 = New SIMULATOR.SubS_P_SRPackage.T10_Data_Valid()
    Me.T8_Data1 = New SIMULATOR.SubS_P_SRPackage.T8_Data()
    Me.Label8 = New System.Windows.Forms.Label()
    Me.T9_Transmission_Complete1 = New SIMULATOR.SubS_P_SRPackage.T9_Transmission_Complete()
    Me.GroupBox2 = New System.Windows.Forms.GroupBox()
    Me.D5_Con_tmax_DataTransmission1 = New SIMULATOR.SubS_P_SRPackage.D5_Con_tmax_DataTransmission()
    Me.Label5 = New System.Windows.Forms.Label()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.D4_Con_tmax_Response_MDM1 = New SIMULATOR.SubS_P_SRPackage.D4_Con_tmax_Response_MDM()
    Me.D3_Con_t_Ini_Max1 = New SIMULATOR.SubS_P_SRPackage.D3_Con_t_Ini_Max()
    Me.D2_Con_t_Ini_Step1 = New SIMULATOR.SubS_P_SRPackage.D2_Con_t_Ini_Step()
    Me.D1_Con_t_Ini_Def_Delay1 = New SIMULATOR.SubS_P_SRPackage.D1_Con_t_Ini_Def_Delay()
    Me.Lable1 = New System.Windows.Forms.Label()
    Me.D20_Con_MDM_Used1 = New SIMULATOR.SubS_P_SRPackage.D20_Con_MDM_Used()
    Me.TabPage8 = New System.Windows.Forms.TabPage()
    Me.GroupBox20 = New System.Windows.Forms.GroupBox()
    Me.GroupBox26 = New System.Windows.Forms.GroupBox()
    Me.Label46 = New System.Windows.Forms.Label()
    Me.Label33 = New System.Windows.Forms.Label()
    Me.T20_Protocol_Error1 = New SIMULATOR.SubS_P_SRPackage.T20_Protocol_Error()
    Me.Label27 = New System.Windows.Forms.Label()
    Me.T21_Formal_Telegram_Error1 = New SIMULATOR.SubS_P_SRPackage.T21_Formal_Telegram_Error()
    Me.T22_Content_Telegram_Error1 = New SIMULATOR.SubS_P_SRPackage.T22_Content_Telegram_Error()
    Me.GroupBox27 = New System.Windows.Forms.GroupBox()
    Me.Label92 = New System.Windows.Forms.Label()
    Me.D23_Con_Checksum_Data_Used1 = New SIMULATOR.SubS_P_SRPackage.D23_Con_Checksum_Data_Used()
    Me.Label22 = New System.Windows.Forms.Label()
    Me.Label21 = New System.Windows.Forms.Label()
    Me.D4_Checksum_Data1 = New SIMULATOR.SubS_P_SRPackage.D4_Checksum_Data()
    Me.D3_Con_PDI_Version1 = New SIMULATOR.SubS_P_SRPackage.D3_Con_PDI_Version()
    Me.GroupBox19 = New System.Windows.Forms.GroupBox()
    Me.GroupBox25 = New System.Windows.Forms.GroupBox()
    Me.T22_Content_Telegram_Error_I1 = New SIMULATOR.SubS_P_SRPackage.T22_Content_Telegram_Error_I()
    Me.T21_Formal_Telegram_Error_I1 = New SIMULATOR.SubS_P_SRPackage.T21_Formal_Telegram_Error_I()
    Me.T20_Protocol_Error_I1 = New SIMULATOR.SubS_P_SRPackage.T20_Protocol_Error_I()
    Me.Label90 = New System.Windows.Forms.Label()
    Me.Label89 = New System.Windows.Forms.Label()
    Me.Label88 = New System.Windows.Forms.Label()
    Me.GroupBox24 = New System.Windows.Forms.GroupBox()
    Me.D4_Con_Checksum_Data_I1 = New SIMULATOR.SubS_P_SRPackage.D4_Con_Checksum_Data_I()
    Me.D3_Con_PDI_Version_I1 = New SIMULATOR.SubS_P_SRPackage.D3_Con_PDI_Version_I()
    Me.Label87 = New System.Windows.Forms.Label()
    Me.Label86 = New System.Windows.Forms.Label()
    Me.Label85 = New System.Windows.Forms.Label()
    Me.D2_Con_tmax_PDI_Connection_I1 = New SIMULATOR.SubS_P_SRPackage.D2_Con_tmax_PDI_Connection_I()
    Me.GroupBox18 = New System.Windows.Forms.GroupBox()
    Me.Label91 = New System.Windows.Forms.Label()
    Me.T10_SCP_Connection_Terminated1 = New SIMULATOR.SubS_P_SRPackage.T10_SCP_Connection_Terminated()
    Me.T5_SCP_Connection1 = New SIMULATOR.SubS_P_SRPackage.T5_SCP_Connection()
    Me.Label23 = New System.Windows.Forms.Label()
    Me.GroupBox8 = New System.Windows.Forms.GroupBox()
    Me.T5_SIL_Not_Fulfilled1 = New SIMULATOR.SubS_P_SRPackage.T5_SIL_Not_Fulfilled()
    Me.Label97 = New System.Windows.Forms.Label()
    Me.D44_Con_tmax_Booting1 = New SIMULATOR.SubS_P_SRPackage.D44_Con_tmax_Booting()
    Me.Label47 = New System.Windows.Forms.Label()
    Me.Label20 = New System.Windows.Forms.Label()
    Me.Label18 = New System.Windows.Forms.Label()
    Me.Label17 = New System.Windows.Forms.Label()
    Me.Label16 = New System.Windows.Forms.Label()
    Me.Label15 = New System.Windows.Forms.Label()
    Me.T7_Invalid_Or_Missing_Basic_Data1 = New SIMULATOR.SubS_P_SRPackage.T7_Invalid_Or_Missing_Basic_Data()
    Me.T4_Booted1 = New SIMULATOR.SubS_P_SRPackage.T4_Booted()
    Me.T3_Reset1 = New SIMULATOR.SubS_P_SRPackage.T3_Reset()
    Me.T2_Power_Off_Detected1 = New SIMULATOR.SubS_P_SRPackage.T2_Power_Off_Detected()
    Me.T1_Power_On_Detected1 = New SIMULATOR.SubS_P_SRPackage.T1_Power_On_Detected()
    Me.SySimControlBar_SubS_P_SR1 = New SIMULATOR.SubS_P_SRPackage.SySimControlBar_SubS_P_SR()
    Me.DT4_End_Position1 = New SIMULATOR.SubS_P_SRPackage.DT20_Position()
    Me.T3_Information_No_End_Position1 = New SIMULATOR.SubS_P_SRPackage.T4_Information_No_End_Position()
    Me.D10_Drive_State1 = New SIMULATOR.SubS_P_SRPackage.D5_Drive_State()
    Me.DT2_Point_Position1 = New SIMULATOR.SubS_P_SRPackage.DT2_Point_Position()
    Me.T2_Msg_Point_Position1 = New SIMULATOR.SubS_P_SRPackage.T2_Msg_Point_Position()
    Me.T10_SIL_Not_Fulfilled1 = New SIMULATOR.SubS_P_SRPackage.T23_SIL_Not_Fulfilled()
    '' Me.T3_Msg_Timeout1 = New SIMULATOR.SubS_P_SRPackage.T3_Msg_Timeout()
    Me.TabPage2.SuspendLayout()
    Me.GroupBox22.SuspendLayout()
    CType(Me.T15_Msg_Initialisation_Completed1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T18_Start_Status_Report1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T14_Msg_Start_Initialisation1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T12_Disconnect_SCP1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T13_Msg_PDI_Version_Check1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox21.SuspendLayout()
    CType(Me.T8_Cd_Initialisation_Request12, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T12_Terminate_SCP_Connection_I1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T7_Cd_PDI_Version_Check11, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T6_Establish_SCP_Connection_I1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox10.SuspendLayout()
    CType(Me.T21_Data_Update_Finished1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T20_Ready_For_Update_Of_Data1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T19_Validate_Data1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TabControl2.SuspendLayout()
    Me.TabPage6.SuspendLayout()
    Me.GroupBox9.SuspendLayout()
    CType(Me.T02_Msg_Point_Position1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox11.SuspendLayout()
    CType(Me.T5_Info_End_Position_Arrived1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D25_Redrive1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T12_Reset_PMs1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T07_Information_Out_Of_Sequence1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T06_Information_Trailed_Point1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T04_Information_No_End_Position1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D6_Move_Right1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D5_Move_Left1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TabPage7.SuspendLayout()
    Me.TabPage4.SuspendLayout()
    Me.GroupBox14.SuspendLayout()
    CType(Me.D38_0085001, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D37_0084001, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D36_0083001, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D35_0082001, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D34_0080001, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D33_0079001, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D32_0076001, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.D30_0070001, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TabPage3.SuspendLayout()
    Me.GroupBox15.SuspendLayout()
    Me.GroupBox17.SuspendLayout()
    CType(Me.PM2_Active1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox16.SuspendLayout()
    Me.GroupBox13.SuspendLayout()
    Me.GroupBox12.SuspendLayout()
    Me.TabControl1.SuspendLayout()
    Me.TabPage5.SuspendLayout()
    Me.GroupBox7.SuspendLayout()
    Me.GroupBox2.SuspendLayout()
    CType(Me.D20_Con_MDM_Used1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.TabPage8.SuspendLayout()
    Me.GroupBox20.SuspendLayout()
    Me.GroupBox26.SuspendLayout()
    Me.GroupBox27.SuspendLayout()
    CType(Me.D23_Con_Checksum_Data_Used1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox19.SuspendLayout()
    Me.GroupBox25.SuspendLayout()
    Me.GroupBox24.SuspendLayout()
    Me.GroupBox18.SuspendLayout()
    Me.GroupBox8.SuspendLayout()
    CType(Me.T3_Information_No_End_Position1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T2_Msg_Point_Position1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T10_SIL_Not_Fulfilled1, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.T3_Msg_Timeout1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'Label25
    '
    Me.Label25.AutoSize = True
    Me.Label25.Location = New System.Drawing.Point(354, 68)
    Me.Label25.Name = "Label25"
    Me.Label25.Size = New System.Drawing.Size(93, 13)
    Me.Label25.TabIndex = 6
    Me.Label25.Text = "DT7_PDI_Version"
    '
    'Label24
    '
    Me.Label24.AutoSize = True
    Me.Label24.Location = New System.Drawing.Point(54, 68)
    Me.Label24.Name = "Label24"
    Me.Label24.Size = New System.Drawing.Size(141, 13)
    Me.Label24.TabIndex = 5
    Me.Label24.Text = "T7_Cd_PDI_Version_Check"
    '
    'Label50
    '
    Me.Label50.AutoSize = True
    Me.Label50.Location = New System.Drawing.Point(486, 69)
    Me.Label50.Name = "Label50"
    Me.Label50.Size = New System.Drawing.Size(142, 13)
    Me.Label50.TabIndex = 5
    Me.Label50.Text = "D50_PDI_Connection_State"
    '
    'RichTextBox1
    '
    Me.RichTextBox1.Location = New System.Drawing.Point(6, 6)
    Me.RichTextBox1.Name = "RichTextBox1"
    Me.RichTextBox1.ReadOnly = True
    Me.RichTextBox1.Size = New System.Drawing.Size(166, 131)
    Me.RichTextBox1.TabIndex = 0
    Me.RichTextBox1.Text = "Point (P) GUI" & Global.Microsoft.VisualBasic.ChrW(10) & "Iteration: 4" & Global.Microsoft.VisualBasic.ChrW(10) & "PTC Model Version: 15.6.9" & Global.Microsoft.VisualBasic.ChrW(10) & "Date of delivery: 28.03.2019" &
    "" & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(10) & "Integrated Generic LCps" & Global.Microsoft.VisualBasic.ChrW(10) & "PTC Model Version: 31" & Global.Microsoft.VisualBasic.ChrW(10) & "Date of deleivery: -"
    '
    'TabPage2
    '
    Me.TabPage2.Controls.Add(Me.GroupBox22)
    Me.TabPage2.Controls.Add(Me.GroupBox21)
    Me.TabPage2.Controls.Add(Me.GroupBox10)
    Me.TabPage2.Location = New System.Drawing.Point(4, 22)
    Me.TabPage2.Name = "TabPage2"
    Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
    Me.TabPage2.Size = New System.Drawing.Size(672, 683)
    Me.TabPage2.TabIndex = 0
    Me.TabPage2.Text = "Generic"
    Me.TabPage2.UseVisualStyleBackColor = True
    '
    'GroupBox22
    '
    Me.GroupBox22.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox22.Controls.Add(Me.Label31)
    Me.GroupBox22.Controls.Add(Me.Label30)
    Me.GroupBox22.Controls.Add(Me.D51_F_EST_EfeS_Gen_SR_state1)
    Me.GroupBox22.Controls.Add(Me.Label32)
    Me.GroupBox22.Controls.Add(Me.Label29)
    Me.GroupBox22.Controls.Add(Me.Label35)
    Me.GroupBox22.Controls.Add(Me.T15_Msg_Initialisation_Completed1)
    Me.GroupBox22.Controls.Add(Me.T18_Start_Status_Report1)
    Me.GroupBox22.Controls.Add(Me.T14_Msg_Start_Initialisation1)
    Me.GroupBox22.Controls.Add(Me.Label34)
    Me.GroupBox22.Controls.Add(Me.Label96)
    Me.GroupBox22.Controls.Add(Me.D50_PDI_Connection_State_S1)
    Me.GroupBox22.Controls.Add(Me.DT13_Result1)
    Me.GroupBox22.Controls.Add(Me.Label50)
    Me.GroupBox22.Controls.Add(Me.DT13_Checksum_data1)
    Me.GroupBox22.Controls.Add(Me.T12_Disconnect_SCP1)
    Me.GroupBox22.Controls.Add(Me.T13_Msg_PDI_Version_Check1)
    Me.GroupBox22.Controls.Add(Me.Label28)
    Me.GroupBox22.Location = New System.Drawing.Point(6, 77)
    Me.GroupBox22.Name = "GroupBox22"
    Me.GroupBox22.Size = New System.Drawing.Size(663, 227)
    Me.GroupBox22.TabIndex = 3
    Me.GroupBox22.TabStop = False
    Me.GroupBox22.Text = "SCI (Secondary)"
    '
    'Label31
    '
    Me.Label31.AutoSize = True
    Me.Label31.Location = New System.Drawing.Point(486, 27)
    Me.Label31.Name = "Label31"
    Me.Label31.Size = New System.Drawing.Size(171, 13)
    Me.Label31.TabIndex = 7
    Me.Label31.Text = "D51_F_EST_EfeS_Gen_SR_state"
    '
    'Label30
    '
    Me.Label30.AutoSize = True
    Me.Label30.Location = New System.Drawing.Point(54, 152)
    Me.Label30.Name = "Label30"
    Me.Label30.Size = New System.Drawing.Size(168, 13)
    Me.Label30.TabIndex = 6
    Me.Label30.Text = "T15_Msg_Initialisation_Completed"
    '
    'D51_F_EST_EfeS_Gen_SR_state1
    '
    Me.D51_F_EST_EfeS_Gen_SR_state1.Location = New System.Drawing.Point(244, 23)
    Me.D51_F_EST_EfeS_Gen_SR_state1.Name = "D51_F_EST_EfeS_Gen_SR_state1"
    Me.D51_F_EST_EfeS_Gen_SR_state1.Size = New System.Drawing.Size(236, 20)
    Me.D51_F_EST_EfeS_Gen_SR_state1.SySimTooltip = "D51_F_EST_EfeS_Gen_SR_state:OutputTextBox"
    Me.D51_F_EST_EfeS_Gen_SR_state1.TabIndex = 16
    '
    'Label32
    '
    Me.Label32.AutoSize = True
    Me.Label32.Location = New System.Drawing.Point(54, 72)
    Me.Label32.Name = "Label32"
    Me.Label32.Size = New System.Drawing.Size(154, 13)
    Me.Label32.TabIndex = 12
    Me.Label32.Text = "T13_Msg_PDI_Version_Check"
    '
    'Label29
    '
    Me.Label29.AutoSize = True
    Me.Label29.Location = New System.Drawing.Point(54, 112)
    Me.Label29.Name = "Label29"
    Me.Label29.Size = New System.Drawing.Size(140, 13)
    Me.Label29.TabIndex = 5
    Me.Label29.Text = "T14_Msg_Start_Initialisation"
    '
    'Label35
    '
    Me.Label35.AutoSize = True
    Me.Label35.Location = New System.Drawing.Point(368, 114)
    Me.Label35.Name = "Label35"
    Me.Label35.Size = New System.Drawing.Size(70, 13)
    Me.Label35.TabIndex = 15
    Me.Label35.Text = "DT13_Result"
    '
    'T15_Msg_Initialisation_Completed1
    '
    Me.T15_Msg_Initialisation_Completed1.BackColor = System.Drawing.Color.DarkGray
    Me.T15_Msg_Initialisation_Completed1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T15_Msg_Initialisation_Completed1.Location = New System.Drawing.Point(9, 143)
    Me.T15_Msg_Initialisation_Completed1.Name = "T15_Msg_Initialisation_Completed1"
    Me.T15_Msg_Initialisation_Completed1.Size = New System.Drawing.Size(30, 30)
    Me.T15_Msg_Initialisation_Completed1.SySimTooltip = "T15_Msg_Initialisation_Completed:PulseIndicator"
    Me.T15_Msg_Initialisation_Completed1.TabIndex = 2
    Me.T15_Msg_Initialisation_Completed1.TabStop = False
    '
    'T18_Start_Status_Report1
    '
    Me.T18_Start_Status_Report1.BackColor = System.Drawing.Color.DarkGray
    Me.T18_Start_Status_Report1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T18_Start_Status_Report1.Location = New System.Drawing.Point(9, 183)
    Me.T18_Start_Status_Report1.Name = "T18_Start_Status_Report1"
    Me.T18_Start_Status_Report1.Size = New System.Drawing.Size(30, 30)
    Me.T18_Start_Status_Report1.SySimTooltip = "T18_Start_Status_Report:PulseIndicator"
    Me.T18_Start_Status_Report1.TabIndex = 12
    Me.T18_Start_Status_Report1.TabStop = False
    '
    'T14_Msg_Start_Initialisation1
    '
    Me.T14_Msg_Start_Initialisation1.BackColor = System.Drawing.Color.DarkGray
    Me.T14_Msg_Start_Initialisation1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T14_Msg_Start_Initialisation1.Location = New System.Drawing.Point(9, 103)
    Me.T14_Msg_Start_Initialisation1.Name = "T14_Msg_Start_Initialisation1"
    Me.T14_Msg_Start_Initialisation1.Size = New System.Drawing.Size(30, 30)
    Me.T14_Msg_Start_Initialisation1.SySimTooltip = "T14_Msg_Start_Initialisation:PulseIndicator"
    Me.T14_Msg_Start_Initialisation1.TabIndex = 1
    Me.T14_Msg_Start_Initialisation1.TabStop = False
    '
    'Label34
    '
    Me.Label34.AutoSize = True
    Me.Label34.Location = New System.Drawing.Point(368, 154)
    Me.Label34.Name = "Label34"
    Me.Label34.Size = New System.Drawing.Size(117, 13)
    Me.Label34.TabIndex = 14
    Me.Label34.Text = "DT13_Checksum_data"
    '
    'Label96
    '
    Me.Label96.AutoSize = True
    Me.Label96.Location = New System.Drawing.Point(54, 192)
    Me.Label96.Name = "Label96"
    Me.Label96.Size = New System.Drawing.Size(128, 13)
    Me.Label96.TabIndex = 13
    Me.Label96.Text = "T18_Start_Status_Report"
    '
    'D50_PDI_Connection_State_S1
    '
    Me.D50_PDI_Connection_State_S1.Location = New System.Drawing.Point(244, 65)
    Me.D50_PDI_Connection_State_S1.Name = "D50_PDI_Connection_State_S1"
    Me.D50_PDI_Connection_State_S1.Size = New System.Drawing.Size(236, 20)
    Me.D50_PDI_Connection_State_S1.SySimTooltip = "D50_PDI_Connection_State_S:OutputTextBox"
    Me.D50_PDI_Connection_State_S1.TabIndex = 11
    '
    'DT13_Result1
    '
    Me.DT13_Result1.Location = New System.Drawing.Point(244, 110)
    Me.DT13_Result1.Name = "DT13_Result1"
    Me.DT13_Result1.Size = New System.Drawing.Size(100, 20)
    Me.DT13_Result1.SySimTooltip = "DT13_Result:OutputTextBox"
    Me.DT13_Result1.TabIndex = 11
    Me.DT13_Result1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'DT13_Checksum_data1
    '
    Me.DT13_Checksum_data1.Location = New System.Drawing.Point(244, 150)
    Me.DT13_Checksum_data1.Name = "DT13_Checksum_data1"
    Me.DT13_Checksum_data1.Size = New System.Drawing.Size(100, 20)
    Me.DT13_Checksum_data1.SySimTooltip = "DT13_Checksum_data:OutputTextBox"
    Me.DT13_Checksum_data1.TabIndex = 10
    Me.DT13_Checksum_data1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'T12_Disconnect_SCP1
    '
    Me.T12_Disconnect_SCP1.BackColor = System.Drawing.Color.DarkGray
    Me.T12_Disconnect_SCP1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T12_Disconnect_SCP1.Location = New System.Drawing.Point(9, 23)
    Me.T12_Disconnect_SCP1.Name = "T12_Disconnect_SCP1"
    Me.T12_Disconnect_SCP1.Size = New System.Drawing.Size(30, 30)
    Me.T12_Disconnect_SCP1.SySimTooltip = "T12_Disconnect_SCP:PulseIndicator"
    Me.T12_Disconnect_SCP1.TabIndex = 10
    Me.T12_Disconnect_SCP1.TabStop = False
    '
    'T13_Msg_PDI_Version_Check1
    '
    Me.T13_Msg_PDI_Version_Check1.BackColor = System.Drawing.Color.DarkGray
    Me.T13_Msg_PDI_Version_Check1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T13_Msg_PDI_Version_Check1.Location = New System.Drawing.Point(9, 63)
    Me.T13_Msg_PDI_Version_Check1.Name = "T13_Msg_PDI_Version_Check1"
    Me.T13_Msg_PDI_Version_Check1.Size = New System.Drawing.Size(30, 30)
    Me.T13_Msg_PDI_Version_Check1.SySimTooltip = "T13_Msg_PDI_Version_Check:PulseIndicator"
    Me.T13_Msg_PDI_Version_Check1.TabIndex = 8
    Me.T13_Msg_PDI_Version_Check1.TabStop = False
    '
    'Label28
    '
    Me.Label28.AutoSize = True
    Me.Label28.Location = New System.Drawing.Point(54, 32)
    Me.Label28.Name = "Label28"
    Me.Label28.Size = New System.Drawing.Size(113, 13)
    Me.Label28.TabIndex = 4
    Me.Label28.Text = "T12_Disconnect_SCP"
    '
    'GroupBox21
    '
    Me.GroupBox21.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox21.Controls.Add(Me.Label100)
    Me.GroupBox21.Controls.Add(Me.T8_Cd_Initialisation_Request12)
    Me.GroupBox21.Controls.Add(Me.DT7_PDI_Version11)
    Me.GroupBox21.Controls.Add(Me.Label99)
    Me.GroupBox21.Controls.Add(Me.Label25)
    Me.GroupBox21.Controls.Add(Me.Label98)
    Me.GroupBox21.Controls.Add(Me.T12_Terminate_SCP_Connection_I1)
    Me.GroupBox21.Controls.Add(Me.T7_Cd_PDI_Version_Check11)
    Me.GroupBox21.Controls.Add(Me.T6_Establish_SCP_Connection_I1)
    Me.GroupBox21.Controls.Add(Me.Label95)
    Me.GroupBox21.Controls.Add(Me.Label24)
    Me.GroupBox21.Controls.Add(Me.D50_PDI_Connection_State1)
    Me.GroupBox21.Location = New System.Drawing.Point(6, 306)
    Me.GroupBox21.Name = "GroupBox21"
    Me.GroupBox21.Size = New System.Drawing.Size(663, 222)
    Me.GroupBox21.TabIndex = 2
    Me.GroupBox21.TabStop = False
    Me.GroupBox21.Text = "SCI (Primary)"
    '
    'Label100
    '
    Me.Label100.AutoSize = True
    Me.Label100.Location = New System.Drawing.Point(54, 106)
    Me.Label100.Name = "Label100"
    Me.Label100.Size = New System.Drawing.Size(145, 13)
    Me.Label100.TabIndex = 20
    Me.Label100.Text = "T8_Cd_Initialisation_Request"
    '
    'T8_Cd_Initialisation_Request12
    '
    Me.T8_Cd_Initialisation_Request12.BackColor = System.Drawing.Color.DarkGray
    Me.T8_Cd_Initialisation_Request12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T8_Cd_Initialisation_Request12.Location = New System.Drawing.Point(9, 97)
    Me.T8_Cd_Initialisation_Request12.Name = "T8_Cd_Initialisation_Request12"
    Me.T8_Cd_Initialisation_Request12.Size = New System.Drawing.Size(30, 30)
    Me.T8_Cd_Initialisation_Request12.SySimTooltip = "T8_Cd_Initialisation_Request1:PulseIndicator"
    Me.T8_Cd_Initialisation_Request12.TabIndex = 19
    Me.T8_Cd_Initialisation_Request12.TabStop = False
    '
    'DT7_PDI_Version11
    '
    Me.DT7_PDI_Version11.Location = New System.Drawing.Point(244, 64)
    Me.DT7_PDI_Version11.Name = "DT7_PDI_Version11"
    Me.DT7_PDI_Version11.Size = New System.Drawing.Size(100, 20)
    Me.DT7_PDI_Version11.SySimTooltip = "DT7_PDI_Version1:OutputTextBox"
    Me.DT7_PDI_Version11.TabIndex = 18
    '
    'Label99
    '
    Me.Label99.AutoSize = True
    Me.Label99.Location = New System.Drawing.Point(54, 144)
    Me.Label99.Name = "Label99"
    Me.Label99.Size = New System.Drawing.Size(166, 13)
    Me.Label99.TabIndex = 5
    Me.Label99.Text = "T12_Terminate_SCP_Connection"
    '
    'Label98
    '
    Me.Label98.AutoSize = True
    Me.Label98.Location = New System.Drawing.Point(54, 30)
    Me.Label98.Name = "Label98"
    Me.Label98.Size = New System.Drawing.Size(155, 13)
    Me.Label98.TabIndex = 4
    Me.Label98.Text = "T6_Establish_SCP_Connection"
    '
    'T12_Terminate_SCP_Connection_I1
    '
    Me.T12_Terminate_SCP_Connection_I1.BackColor = System.Drawing.Color.DarkGray
    Me.T12_Terminate_SCP_Connection_I1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T12_Terminate_SCP_Connection_I1.Location = New System.Drawing.Point(9, 135)
    Me.T12_Terminate_SCP_Connection_I1.Name = "T12_Terminate_SCP_Connection_I1"
    Me.T12_Terminate_SCP_Connection_I1.Size = New System.Drawing.Size(30, 30)
    Me.T12_Terminate_SCP_Connection_I1.SySimTooltip = "T12_Terminate_SCP_Connection_I:PulseIndicator"
    Me.T12_Terminate_SCP_Connection_I1.TabIndex = 3
    Me.T12_Terminate_SCP_Connection_I1.TabStop = False
    '
    'T7_Cd_PDI_Version_Check11
    '
    Me.T7_Cd_PDI_Version_Check11.BackColor = System.Drawing.Color.DarkGray
    Me.T7_Cd_PDI_Version_Check11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T7_Cd_PDI_Version_Check11.Location = New System.Drawing.Point(9, 59)
    Me.T7_Cd_PDI_Version_Check11.Name = "T7_Cd_PDI_Version_Check11"
    Me.T7_Cd_PDI_Version_Check11.Size = New System.Drawing.Size(30, 30)
    Me.T7_Cd_PDI_Version_Check11.SySimTooltip = "T7_Cd_PDI_Version_Check1:PulseIndicator"
    Me.T7_Cd_PDI_Version_Check11.TabIndex = 16
    Me.T7_Cd_PDI_Version_Check11.TabStop = False
    '
    'T6_Establish_SCP_Connection_I1
    '
    Me.T6_Establish_SCP_Connection_I1.BackColor = System.Drawing.Color.DarkGray
    Me.T6_Establish_SCP_Connection_I1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T6_Establish_SCP_Connection_I1.Location = New System.Drawing.Point(9, 21)
    Me.T6_Establish_SCP_Connection_I1.Name = "T6_Establish_SCP_Connection_I1"
    Me.T6_Establish_SCP_Connection_I1.Size = New System.Drawing.Size(30, 30)
    Me.T6_Establish_SCP_Connection_I1.SySimTooltip = "T6_Establish_SCP_Connection_I:PulseIndicator"
    Me.T6_Establish_SCP_Connection_I1.TabIndex = 2
    Me.T6_Establish_SCP_Connection_I1.TabStop = False
    '
    'Label95
    '
    Me.Label95.AutoSize = True
    Me.Label95.Location = New System.Drawing.Point(486, 30)
    Me.Label95.Name = "Label95"
    Me.Label95.Size = New System.Drawing.Size(142, 13)
    Me.Label95.TabIndex = 1
    Me.Label95.Text = "D50_PDI_Connection_State"
    '
    'D50_PDI_Connection_State1
    '
    Me.D50_PDI_Connection_State1.Location = New System.Drawing.Point(244, 26)
    Me.D50_PDI_Connection_State1.Name = "D50_PDI_Connection_State1"
    Me.D50_PDI_Connection_State1.Size = New System.Drawing.Size(236, 20)
    Me.D50_PDI_Connection_State1.SySimTooltip = "D50_PDI_Connection_State:OutputTextBox"
    Me.D50_PDI_Connection_State1.TabIndex = 0
    '
    'GroupBox10
    '
    Me.GroupBox10.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox10.Controls.Add(Me.T21_Data_Update_Finished1)
    Me.GroupBox10.Controls.Add(Me.Label69)
    Me.GroupBox10.Controls.Add(Me.Label39)
    Me.GroupBox10.Controls.Add(Me.Label38)
    Me.GroupBox10.Controls.Add(Me.T20_Ready_For_Update_Of_Data1)
    Me.GroupBox10.Controls.Add(Me.T19_Validate_Data1)
    Me.GroupBox10.Location = New System.Drawing.Point(6, 6)
    Me.GroupBox10.Name = "GroupBox10"
    Me.GroupBox10.Size = New System.Drawing.Size(663, 65)
    Me.GroupBox10.TabIndex = 1
    Me.GroupBox10.TabStop = False
    Me.GroupBox10.Text = "SubS_MDM (SMI)"
    '
    'T21_Data_Update_Finished1
    '
    Me.T21_Data_Update_Finished1.BackColor = System.Drawing.Color.DarkGray
    Me.T21_Data_Update_Finished1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T21_Data_Update_Finished1.Location = New System.Drawing.Point(459, 19)
    Me.T21_Data_Update_Finished1.Name = "T21_Data_Update_Finished1"
    Me.T21_Data_Update_Finished1.Size = New System.Drawing.Size(30, 30)
    Me.T21_Data_Update_Finished1.SySimTooltip = "T21_Data_Update_Finished:PulseIndicator"
    Me.T21_Data_Update_Finished1.TabIndex = 24
    Me.T21_Data_Update_Finished1.TabStop = False
    '
    'Label69
    '
    Me.Label69.AutoSize = True
    Me.Label69.Location = New System.Drawing.Point(504, 28)
    Me.Label69.Name = "Label69"
    Me.Label69.Size = New System.Drawing.Size(141, 13)
    Me.Label69.TabIndex = 23
    Me.Label69.Text = "T21_Data_Update_Finished"
    '
    'Label39
    '
    Me.Label39.AutoSize = True
    Me.Label39.Location = New System.Drawing.Point(243, 28)
    Me.Label39.Name = "Label39"
    Me.Label39.Size = New System.Drawing.Size(171, 13)
    Me.Label39.TabIndex = 3
    Me.Label39.Text = "T20_Ready_For_Update_Of_Data"
    '
    'Label38
    '
    Me.Label38.AutoSize = True
    Me.Label38.Location = New System.Drawing.Point(54, 28)
    Me.Label38.Name = "Label38"
    Me.Label38.Size = New System.Drawing.Size(99, 13)
    Me.Label38.TabIndex = 2
    Me.Label38.Text = "T19_Validate_Data"
    '
    'T20_Ready_For_Update_Of_Data1
    '
    Me.T20_Ready_For_Update_Of_Data1.BackColor = System.Drawing.Color.DarkGray
    Me.T20_Ready_For_Update_Of_Data1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T20_Ready_For_Update_Of_Data1.Location = New System.Drawing.Point(198, 19)
    Me.T20_Ready_For_Update_Of_Data1.Name = "T20_Ready_For_Update_Of_Data1"
    Me.T20_Ready_For_Update_Of_Data1.Size = New System.Drawing.Size(30, 30)
    Me.T20_Ready_For_Update_Of_Data1.SySimTooltip = "T20_Ready_For_Update_Of_Data:PulseIndicator"
    Me.T20_Ready_For_Update_Of_Data1.TabIndex = 1
    Me.T20_Ready_For_Update_Of_Data1.TabStop = False
    '
    'T19_Validate_Data1
    '
    Me.T19_Validate_Data1.BackColor = System.Drawing.Color.DarkGray
    Me.T19_Validate_Data1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T19_Validate_Data1.Location = New System.Drawing.Point(9, 19)
    Me.T19_Validate_Data1.Name = "T19_Validate_Data1"
    Me.T19_Validate_Data1.Size = New System.Drawing.Size(30, 30)
    Me.T19_Validate_Data1.SySimTooltip = "T19_Validate_Data:PulseIndicator"
    Me.T19_Validate_Data1.TabIndex = 0
    Me.T19_Validate_Data1.TabStop = False
    '
    'TabControl2
    '
    Me.TabControl2.Controls.Add(Me.TabPage6)
    Me.TabControl2.Controls.Add(Me.TabPage2)
    Me.TabControl2.Controls.Add(Me.TabPage7)
    Me.TabControl2.Location = New System.Drawing.Point(746, 7)
    Me.TabControl2.Name = "TabControl2"
    Me.TabControl2.SelectedIndex = 0
    Me.TabControl2.Size = New System.Drawing.Size(680, 709)
    Me.TabControl2.TabIndex = 3
    '
    'TabPage6
    '
    Me.TabPage6.Controls.Add(Me.GroupBox9)
    Me.TabPage6.Controls.Add(Me.GroupBox11)
    Me.TabPage6.Location = New System.Drawing.Point(4, 22)
    Me.TabPage6.Name = "TabPage6"
    Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
    Me.TabPage6.Size = New System.Drawing.Size(672, 683)
    Me.TabPage6.TabIndex = 1
    Me.TabPage6.Text = "Sub P Outputs"
    Me.TabPage6.UseVisualStyleBackColor = True
    '
    'GroupBox9
    '
    Me.GroupBox9.BackColor = System.Drawing.Color.Transparent
    '' Me.GroupBox9.Controls.Add(Me.T3_Msg_Timeout1)
    Me.GroupBox9.Controls.Add(Me.DT20_Position1)
    Me.GroupBox9.Controls.Add(Me.T02_Msg_Point_Position1)
    Me.GroupBox9.Controls.Add(Me.Label42)
    Me.GroupBox9.Controls.Add(Me.Label37)
    Me.GroupBox9.Controls.Add(Me.Label36)
    Me.GroupBox9.Location = New System.Drawing.Point(16, 23)
    Me.GroupBox9.Name = "GroupBox9"
    Me.GroupBox9.Size = New System.Drawing.Size(639, 102)
    Me.GroupBox9.TabIndex = 2
    Me.GroupBox9.TabStop = False
    Me.GroupBox9.Text = "SCI P"
    '
    'DT20_Position1
    '
    Me.DT20_Position1.Location = New System.Drawing.Point(319, 25)
    Me.DT20_Position1.Name = "DT20_Position1"
    Me.DT20_Position1.Size = New System.Drawing.Size(160, 20)
    Me.DT20_Position1.SySimTooltip = "DT20_Position:OutputTextBox"
    Me.DT20_Position1.TabIndex = 24
    '
    'T02_Msg_Point_Position1
    '
    Me.T02_Msg_Point_Position1.BackColor = System.Drawing.Color.DarkGray
    Me.T02_Msg_Point_Position1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T02_Msg_Point_Position1.Location = New System.Drawing.Point(22, 20)
    Me.T02_Msg_Point_Position1.Name = "T02_Msg_Point_Position1"
    Me.T02_Msg_Point_Position1.Size = New System.Drawing.Size(30, 30)
    Me.T02_Msg_Point_Position1.SySimTooltip = "T02_Msg_Point_Position:PulseIndicator"
    Me.T02_Msg_Point_Position1.TabIndex = 12
    Me.T02_Msg_Point_Position1.TabStop = False
    '
    'Label42
    '
    Me.Label42.AutoSize = True
    Me.Label42.Location = New System.Drawing.Point(58, 66)
    Me.Label42.Name = "Label42"
    Me.Label42.Size = New System.Drawing.Size(90, 13)
    Me.Label42.TabIndex = 5
    Me.Label42.Text = "T3_Msg_Timeout"
    '
    'Label37
    '
    Me.Label37.AutoSize = True
    Me.Label37.Location = New System.Drawing.Point(485, 29)
    Me.Label37.Name = "Label37"
    Me.Label37.Size = New System.Drawing.Size(101, 13)
    Me.Label37.TabIndex = 3
    Me.Label37.Text = "DT2_Point_Position"
    '
    'Label36
    '
    Me.Label36.AutoSize = True
    Me.Label36.Location = New System.Drawing.Point(58, 29)
    Me.Label36.Name = "Label36"
    Me.Label36.Size = New System.Drawing.Size(119, 13)
    Me.Label36.TabIndex = 2
    Me.Label36.Text = "T2_Msg_Point_Position"
    '
    'GroupBox11
    '
    Me.GroupBox11.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox11.Controls.Add(Me.T5_Info_End_Position_Arrived1)
    Me.GroupBox11.Controls.Add(Me.Label101)
    Me.GroupBox11.Controls.Add(Me.Label67)
    Me.GroupBox11.Controls.Add(Me.D25_Redrive1)
    Me.GroupBox11.Controls.Add(Me.D06_Detection_State1)
    Me.GroupBox11.Controls.Add(Me.Label84)
    Me.GroupBox11.Controls.Add(Me.T12_Reset_PMs1)
    Me.GroupBox11.Controls.Add(Me.Label71)
    Me.GroupBox11.Controls.Add(Me.D05_Drive_State1)
    Me.GroupBox11.Controls.Add(Me.D6_Move_Right1)
    Me.GroupBox11.Controls.Add(Me.Label41)
    Me.GroupBox11.Controls.Add(Me.T07_Information_Out_Of_Sequence1)
    Me.GroupBox11.Controls.Add(Me.T06_Information_Trailed_Point1)
    Me.GroupBox11.Controls.Add(Me.Label51)
    Me.GroupBox11.Controls.Add(Me.T04_Information_No_End_Position1)
    Me.GroupBox11.Controls.Add(Me.Label19)
    Me.GroupBox11.Controls.Add(Me.Label54)
    Me.GroupBox11.Controls.Add(Me.Label53)
    Me.GroupBox11.Controls.Add(Me.Label52)
    Me.GroupBox11.Controls.Add(Me.Label40)
    Me.GroupBox11.Controls.Add(Me.D5_Move_Left1)
    Me.GroupBox11.Location = New System.Drawing.Point(16, 131)
    Me.GroupBox11.Name = "GroupBox11"
    Me.GroupBox11.Size = New System.Drawing.Size(639, 386)
    Me.GroupBox11.TabIndex = 3
    Me.GroupBox11.TabStop = False
    Me.GroupBox11.Text = "P3"
    '
    'T5_Info_End_Position_Arrived1
    '
    Me.T5_Info_End_Position_Arrived1.BackColor = System.Drawing.Color.DarkGray
    Me.T5_Info_End_Position_Arrived1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T5_Info_End_Position_Arrived1.Location = New System.Drawing.Point(22, 72)
    Me.T5_Info_End_Position_Arrived1.Name = "T5_Info_End_Position_Arrived1"
    Me.T5_Info_End_Position_Arrived1.Size = New System.Drawing.Size(30, 30)
    Me.T5_Info_End_Position_Arrived1.SySimTooltip = "T5_Info_End_Position_Arrived:PulseIndicator"
    Me.T5_Info_End_Position_Arrived1.TabIndex = 21
    Me.T5_Info_End_Position_Arrived1.TabStop = False
    '
    'Label101
    '
    Me.Label101.AutoSize = True
    Me.Label101.Location = New System.Drawing.Point(58, 267)
    Me.Label101.Name = "Label101"
    Me.Label101.Size = New System.Drawing.Size(70, 13)
    Me.Label101.TabIndex = 20
    Me.Label101.Text = "D25_Redrive"
    '
    'Label67
    '
    Me.Label67.AutoSize = True
    Me.Label67.Location = New System.Drawing.Point(536, 169)
    Me.Label67.Name = "Label67"
    Me.Label67.Size = New System.Drawing.Size(104, 13)
    Me.Label67.TabIndex = 22
    Me.Label67.Text = "D6_Detection_State"
    '
    'D25_Redrive1
    '
    Me.D25_Redrive1.BackColor = System.Drawing.Color.DarkGray
    Me.D25_Redrive1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.D25_Redrive1.Location = New System.Drawing.Point(22, 258)
    Me.D25_Redrive1.Name = "D25_Redrive1"
    Me.D25_Redrive1.Size = New System.Drawing.Size(30, 30)
    Me.D25_Redrive1.SySimTooltip = "D25_Redrive:BoolIndicator"
    Me.D25_Redrive1.TabIndex = 19
    Me.D25_Redrive1.TabStop = False
    '
    'D06_Detection_State1
    '
    Me.D06_Detection_State1.Location = New System.Drawing.Point(367, 165)
    Me.D06_Detection_State1.Name = "D06_Detection_State1"
    Me.D06_Detection_State1.Size = New System.Drawing.Size(161, 20)
    Me.D06_Detection_State1.SySimTooltip = "D06_Detection_State:OutputTextBox"
    Me.D06_Detection_State1.TabIndex = 21
    '
    'Label84
    '
    Me.Label84.AutoSize = True
    Me.Label84.Location = New System.Drawing.Point(58, 219)
    Me.Label84.Name = "Label84"
    Me.Label84.Size = New System.Drawing.Size(87, 13)
    Me.Label84.TabIndex = 8
    Me.Label84.Text = "T12_Reset_PMs"
    '
    'T12_Reset_PMs1
    '
    Me.T12_Reset_PMs1.BackColor = System.Drawing.Color.DarkGray
    Me.T12_Reset_PMs1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T12_Reset_PMs1.Location = New System.Drawing.Point(22, 212)
    Me.T12_Reset_PMs1.Name = "T12_Reset_PMs1"
    Me.T12_Reset_PMs1.Size = New System.Drawing.Size(30, 30)
    Me.T12_Reset_PMs1.SySimTooltip = "T12_Reset_PMs:PulseIndicator"
    Me.T12_Reset_PMs1.TabIndex = 7
    Me.T12_Reset_PMs1.TabStop = False
    '
    'Label71
    '
    Me.Label71.AutoSize = True
    Me.Label71.Location = New System.Drawing.Point(58, 170)
    Me.Label71.Name = "Label71"
    Me.Label71.Size = New System.Drawing.Size(173, 13)
    Me.Label71.TabIndex = 18
    Me.Label71.Text = "T7_Information_Out_Of_Sequence"
    '
    'D05_Drive_State1
    '
    Me.D05_Drive_State1.Location = New System.Drawing.Point(367, 124)
    Me.D05_Drive_State1.Name = "D05_Drive_State1"
    Me.D05_Drive_State1.Size = New System.Drawing.Size(161, 20)
    Me.D05_Drive_State1.SySimTooltip = "D05_Drive_State:OutputTextBox"
    Me.D05_Drive_State1.TabIndex = 16
    '
    'T07_Information_Out_Of_Sequence1
    '
    Me.T07_Information_Out_Of_Sequence1.BackColor = System.Drawing.Color.DarkGray
    Me.T07_Information_Out_Of_Sequence1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T07_Information_Out_Of_Sequence1.Location = New System.Drawing.Point(22, 160)
    Me.T07_Information_Out_Of_Sequence1.Name = "T07_Information_Out_Of_Sequence1"
    Me.T07_Information_Out_Of_Sequence1.Size = New System.Drawing.Size(30, 30)
    Me.T07_Information_Out_Of_Sequence1.SySimTooltip = "T07_Information_Out_Of_Sequence:PulseIndicator"
    Me.T07_Information_Out_Of_Sequence1.TabIndex = 16
    Me.T07_Information_Out_Of_Sequence1.TabStop = False
    '
    'T06_Information_Trailed_Point1
    '
    Me.T06_Information_Trailed_Point1.BackColor = System.Drawing.Color.DarkGray
    Me.T06_Information_Trailed_Point1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T06_Information_Trailed_Point1.Location = New System.Drawing.Point(22, 115)
    Me.T06_Information_Trailed_Point1.Name = "T06_Information_Trailed_Point1"
    Me.T06_Information_Trailed_Point1.Size = New System.Drawing.Size(30, 30)
    Me.T06_Information_Trailed_Point1.SySimTooltip = "T06_Information_Trailed_Point:PulseIndicator"
    Me.T06_Information_Trailed_Point1.TabIndex = 15
    Me.T06_Information_Trailed_Point1.TabStop = False
    '
    'Label51
    '
    Me.Label51.AutoSize = True
    Me.Label51.Location = New System.Drawing.Point(533, 128)
    Me.Label51.Name = "Label51"
    Me.Label51.Size = New System.Drawing.Size(83, 13)
    Me.Label51.TabIndex = 11
    Me.Label51.Text = "D5_Drive_State"
    '
    'T04_Information_No_End_Position1
    '
    Me.T04_Information_No_End_Position1.BackColor = System.Drawing.Color.DarkGray
    Me.T04_Information_No_End_Position1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T04_Information_No_End_Position1.Location = New System.Drawing.Point(22, 25)
    Me.T04_Information_No_End_Position1.Name = "T04_Information_No_End_Position1"
    Me.T04_Information_No_End_Position1.Size = New System.Drawing.Size(30, 30)
    Me.T04_Information_No_End_Position1.SySimTooltip = "T04_Information_No_End_Position:PulseIndicator"
    Me.T04_Information_No_End_Position1.TabIndex = 13
    Me.T04_Information_No_End_Position1.TabStop = False
    '
    'Label19
    '
    Me.Label19.AutoSize = True
    Me.Label19.Location = New System.Drawing.Point(58, 124)
    Me.Label19.Name = "Label19"
    Me.Label19.Size = New System.Drawing.Size(146, 13)
    Me.Label19.TabIndex = 12
    Me.Label19.Text = "T6_Information_Trailed_Point"
    '
    'Label54
    '
    Me.Label54.AutoSize = True
    Me.Label54.Location = New System.Drawing.Point(480, 112)
    Me.Label54.Name = "Label54"
    Me.Label54.Size = New System.Drawing.Size(0, 13)
    Me.Label54.TabIndex = 9
    '
    'Label53
    '
    Me.Label53.AutoSize = True
    Me.Label53.Location = New System.Drawing.Point(58, 81)
    Me.Label53.Name = "Label53"
    Me.Label53.Size = New System.Drawing.Size(185, 13)
    Me.Label53.TabIndex = 8
    Me.Label53.Text = "T5_Information_End_Position_Arrived"
    '
    'Label52
    '
    Me.Label52.AutoSize = True
    Me.Label52.Location = New System.Drawing.Point(58, 33)
    Me.Label52.Name = "Label52"
    Me.Label52.Size = New System.Drawing.Size(166, 13)
    Me.Label52.TabIndex = 7
    Me.Label52.Text = "T4_Information_No_End_Position"
    '
    'Label41
    '
    Me.Label41.AutoSize = True
    Me.Label41.Location = New System.Drawing.Point(403, 77)
    Me.Label41.Name = "Label41"
    Me.Label41.Size = New System.Drawing.Size(91, 13)
    Me.Label41.TabIndex = 3
    Me.Label41.Text = "D11_Move_Right"
    '
    'Label40
    '
    Me.Label40.AutoSize = True
    Me.Label40.Location = New System.Drawing.Point(403, 34)
    Me.Label40.Name = "Label40"
    Me.Label40.Size = New System.Drawing.Size(84, 13)
    Me.Label40.TabIndex = 2
    Me.Label40.Text = "D10_Move_Left"
    '
    'D6_Move_Right1
    '
    Me.D6_Move_Right1.BackColor = System.Drawing.Color.DarkGray
    Me.D6_Move_Right1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.D6_Move_Right1.Location = New System.Drawing.Point(367, 72)
    Me.D6_Move_Right1.Name = "D6_Move_Right1"
    Me.D6_Move_Right1.Size = New System.Drawing.Size(30, 30)
    Me.D6_Move_Right1.SySimTooltip = "D6_Move_Right:BoolIndicator"
    Me.D6_Move_Right1.TabIndex = 1
    Me.D6_Move_Right1.TabStop = False
    '
    'D5_Move_Left1
    '
    Me.D5_Move_Left1.BackColor = System.Drawing.Color.DarkGray
    Me.D5_Move_Left1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.D5_Move_Left1.Location = New System.Drawing.Point(367, 25)
    Me.D5_Move_Left1.Name = "D5_Move_Left1"
    Me.D5_Move_Left1.Size = New System.Drawing.Size(30, 30)
    Me.D5_Move_Left1.SySimTooltip = "D5_Move_Left:BoolIndicator"
    Me.D5_Move_Left1.TabIndex = 0
    Me.D5_Move_Left1.TabStop = False
    '
    'TabPage7
    '
    Me.TabPage7.Controls.Add(Me.RichTextBox1)
    Me.TabPage7.Location = New System.Drawing.Point(4, 22)
    Me.TabPage7.Name = "TabPage7"
    Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
    Me.TabPage7.Size = New System.Drawing.Size(672, 683)
    Me.TabPage7.TabIndex = 2
    Me.TabPage7.Text = "GUI Version"
    Me.TabPage7.UseVisualStyleBackColor = True
    '
    'TabPage4
    '
    Me.TabPage4.Controls.Add(Me.GroupBox14)
    Me.TabPage4.Location = New System.Drawing.Point(4, 22)
    Me.TabPage4.Name = "TabPage4"
    Me.TabPage4.Size = New System.Drawing.Size(672, 683)
    Me.TabPage4.TabIndex = 2
    Me.TabPage4.Text = "Configuration"
    Me.TabPage4.UseVisualStyleBackColor = True
    '
    'GroupBox14
    '
    Me.GroupBox14.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox14.Controls.Add(Me.Label63)
    Me.GroupBox14.Controls.Add(Me.Label62)
    Me.GroupBox14.Controls.Add(Me.Label61)
    Me.GroupBox14.Controls.Add(Me.Label60)
    Me.GroupBox14.Controls.Add(Me.Label59)
    Me.GroupBox14.Controls.Add(Me.Label58)
    Me.GroupBox14.Controls.Add(Me.Label57)
    Me.GroupBox14.Controls.Add(Me.Label48)
    Me.GroupBox14.Controls.Add(Me.D38_0085001)
    Me.GroupBox14.Controls.Add(Me.D37_0084001)
    Me.GroupBox14.Controls.Add(Me.D36_0083001)
    Me.GroupBox14.Controls.Add(Me.D35_0082001)
    Me.GroupBox14.Controls.Add(Me.D34_0080001)
    Me.GroupBox14.Controls.Add(Me.D33_0079001)
    Me.GroupBox14.Controls.Add(Me.D32_0076001)
    Me.GroupBox14.Controls.Add(Me.D30_0070001)
    Me.GroupBox14.Location = New System.Drawing.Point(3, 14)
    Me.GroupBox14.Name = "GroupBox14"
    Me.GroupBox14.Size = New System.Drawing.Size(666, 146)
    Me.GroupBox14.TabIndex = 4
    Me.GroupBox14.TabStop = False
    Me.GroupBox14.Text = "Infrastructure Manager"
    '
    'Label63
    '
    Me.Label63.AutoSize = True
    Me.Label63.Location = New System.Drawing.Point(564, 96)
    Me.Label63.Name = "Label63"
    Me.Label63.Size = New System.Drawing.Size(76, 13)
    Me.Label63.TabIndex = 18
    Me.Label63.Text = " SBB (008500)"
    '
    'Label62
    '
    Me.Label62.AutoSize = True
    Me.Label62.Location = New System.Drawing.Point(397, 98)
    Me.Label62.Name = "Label62"
    Me.Label62.Size = New System.Drawing.Size(86, 13)
    Me.Label62.TabIndex = 17
    Me.Label62.Text = "ProRail (008400)"
    '
    'Label61
    '
    Me.Label61.AutoSize = True
    Me.Label61.Location = New System.Drawing.Point(226, 98)
    Me.Label61.Name = "Label61"
    Me.Label61.Size = New System.Drawing.Size(69, 13)
    Me.Label61.TabIndex = 16
    Me.Label61.Text = "RFI (008300)"
    '
    'Label60
    '
    Me.Label60.AutoSize = True
    Me.Label60.Location = New System.Drawing.Point(57, 98)
    Me.Label60.Name = "Label60"
    Me.Label60.Size = New System.Drawing.Size(71, 13)
    Me.Label60.TabIndex = 15
    Me.Label60.Text = "CFL (008200)"
    '
    'Label59
    '
    Me.Label59.AutoSize = True
    Me.Label59.Location = New System.Drawing.Point(564, 46)
    Me.Label59.Name = "Label59"
    Me.Label59.Size = New System.Drawing.Size(92, 13)
    Me.Label59.TabIndex = 14
    Me.Label59.Text = "DB Netz (008000)"
    '
    'Label58
    '
    Me.Label58.AutoSize = True
    Me.Label58.Location = New System.Drawing.Point(396, 46)
    Me.Label58.Name = "Label58"
    Me.Label58.Size = New System.Drawing.Size(66, 13)
    Me.Label58.TabIndex = 13
    Me.Label58.Text = "SZ (007900)"
    '
    'Label57
    '
    Me.Label57.AutoSize = True
    Me.Label57.Location = New System.Drawing.Point(228, 46)
    Me.Label57.Name = "Label57"
    Me.Label57.Size = New System.Drawing.Size(104, 13)
    Me.Label57.TabIndex = 12
    Me.Label57.Text = "Bane NOR (007600)"
    '
    'Label48
    '
    Me.Label48.AutoSize = True
    Me.Label48.Location = New System.Drawing.Point(57, 46)
    Me.Label48.Name = "Label48"
    Me.Label48.Size = New System.Drawing.Size(113, 13)
    Me.Label48.TabIndex = 10
    Me.Label48.Text = "Network Rail (007000)"
    '
    'D38_0085001
    '
    Me.D38_0085001.Location = New System.Drawing.Point(518, 82)
    Me.D38_0085001.Maximum = 1
    Me.D38_0085001.Name = "D38_0085001"
    Me.D38_0085001.Size = New System.Drawing.Size(40, 45)
    Me.D38_0085001.SySimTooltip = "D38_008500:BoolSlider"
    Me.D38_0085001.TabIndex = 8
    Me.D38_0085001.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'D37_0084001
    '
    Me.D37_0084001.Location = New System.Drawing.Point(349, 82)
    Me.D37_0084001.Maximum = 1
    Me.D37_0084001.Name = "D37_0084001"
    Me.D37_0084001.Size = New System.Drawing.Size(40, 45)
    Me.D37_0084001.SySimTooltip = "D37_008400:BoolSlider"
    Me.D37_0084001.TabIndex = 7
    Me.D37_0084001.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'D36_0083001
    '
    Me.D36_0083001.Location = New System.Drawing.Point(180, 82)
    Me.D36_0083001.Maximum = 1
    Me.D36_0083001.Name = "D36_0083001"
    Me.D36_0083001.Size = New System.Drawing.Size(40, 45)
    Me.D36_0083001.SySimTooltip = "D36_008300:BoolSlider"
    Me.D36_0083001.TabIndex = 6
    Me.D36_0083001.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'D35_0082001
    '
    Me.D35_0082001.Location = New System.Drawing.Point(11, 82)
    Me.D35_0082001.Maximum = 1
    Me.D35_0082001.Name = "D35_0082001"
    Me.D35_0082001.Size = New System.Drawing.Size(40, 45)
    Me.D35_0082001.SySimTooltip = "D35_008200:BoolSlider"
    Me.D35_0082001.TabIndex = 5
    Me.D35_0082001.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'D34_0080001
    '
    Me.D34_0080001.Location = New System.Drawing.Point(518, 29)
    Me.D34_0080001.Maximum = 1
    Me.D34_0080001.Name = "D34_0080001"
    Me.D34_0080001.Size = New System.Drawing.Size(40, 45)
    Me.D34_0080001.SySimTooltip = "D34_008000:BoolSlider"
    Me.D34_0080001.TabIndex = 4
    Me.D34_0080001.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'D33_0079001
    '
    Me.D33_0079001.Location = New System.Drawing.Point(349, 29)
    Me.D33_0079001.Maximum = 1
    Me.D33_0079001.Name = "D33_0079001"
    Me.D33_0079001.Size = New System.Drawing.Size(40, 45)
    Me.D33_0079001.SySimTooltip = "D33_007900:BoolSlider"
    Me.D33_0079001.TabIndex = 3
    Me.D33_0079001.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'D32_0076001
    '
    Me.D32_0076001.Location = New System.Drawing.Point(180, 29)
    Me.D32_0076001.Maximum = 1
    Me.D32_0076001.Name = "D32_0076001"
    Me.D32_0076001.Size = New System.Drawing.Size(40, 45)
    Me.D32_0076001.SySimTooltip = "D32_007600:BoolSlider"
    Me.D32_0076001.TabIndex = 2
    Me.D32_0076001.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'D30_0070001
    '
    Me.D30_0070001.Location = New System.Drawing.Point(11, 29)
    Me.D30_0070001.Maximum = 1
    Me.D30_0070001.Name = "D30_0070001"
    Me.D30_0070001.Size = New System.Drawing.Size(40, 45)
    Me.D30_0070001.SySimTooltip = "D30_007000:BoolSlider"
    Me.D30_0070001.TabIndex = 0
    Me.D30_0070001.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'TabPage3
    '
    Me.TabPage3.Controls.Add(Me.GroupBox15)
    Me.TabPage3.Controls.Add(Me.GroupBox13)
    Me.TabPage3.Controls.Add(Me.GroupBox12)
    Me.TabPage3.Location = New System.Drawing.Point(4, 22)
    Me.TabPage3.Name = "TabPage3"
    Me.TabPage3.Size = New System.Drawing.Size(672, 683)
    Me.TabPage3.TabIndex = 1
    Me.TabPage3.Text = "SubS P Inputs"
    Me.TabPage3.UseVisualStyleBackColor = True
    '
    'GroupBox15
    '
    Me.GroupBox15.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox15.Controls.Add(Me.GroupBox17)
    Me.GroupBox15.Controls.Add(Me.GroupBox16)
    Me.GroupBox15.Location = New System.Drawing.Point(13, 179)
    Me.GroupBox15.Name = "GroupBox15"
    Me.GroupBox15.Size = New System.Drawing.Size(639, 491)
    Me.GroupBox15.TabIndex = 4
    Me.GroupBox15.TabStop = False
    Me.GroupBox15.Text = "PM (Input / Outputs from Point Machine Interfaces)"
    '
    'GroupBox17
    '
    Me.GroupBox17.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox17.Controls.Add(Me.Label79)
    Me.GroupBox17.Controls.Add(Me.PM2_Position_Out1)
    Me.GroupBox17.Controls.Add(Me.Label74)
    Me.GroupBox17.Controls.Add(Me.PM2_Position1)
    Me.GroupBox17.Controls.Add(Me.PM2_Active1)
    Me.GroupBox17.Controls.Add(Me.Label68)
    Me.GroupBox17.Location = New System.Drawing.Point(19, 117)
    Me.GroupBox17.Name = "GroupBox17"
    Me.GroupBox17.Size = New System.Drawing.Size(604, 74)
    Me.GroupBox17.TabIndex = 1
    Me.GroupBox17.TabStop = False
    Me.GroupBox17.Text = "PM2"
    '
    'Label79
    '
    Me.Label79.AutoSize = True
    Me.Label79.Location = New System.Drawing.Point(460, 34)
    Me.Label79.Name = "Label79"
    Me.Label79.Size = New System.Drawing.Size(91, 13)
    Me.Label79.TabIndex = 8
    Me.Label79.Text = "Position Reported"
    '
    'PM2_Position_Out1
    '
    Me.PM2_Position_Out1.Location = New System.Drawing.Point(354, 30)
    Me.PM2_Position_Out1.Name = "PM2_Position_Out1"
    Me.PM2_Position_Out1.Size = New System.Drawing.Size(100, 20)
    Me.PM2_Position_Out1.SySimTooltip = "PM2_Position_Out:OutputTextBox"
    Me.PM2_Position_Out1.TabIndex = 7
    '
    'Label74
    '
    Me.Label74.AutoSize = True
    Me.Label74.Location = New System.Drawing.Point(278, 33)
    Me.Label74.Name = "Label74"
    Me.Label74.Size = New System.Drawing.Size(44, 13)
    Me.Label74.TabIndex = 6
    Me.Label74.Text = "Position"
    '
    'PM2_Position1
    '
    Me.PM2_Position1.FormattingEnabled = True
    Me.PM2_Position1.Items.AddRange(New Object() {"LEFT", "NO_END_POSITION", "RIGHT", "TRAILED"})
    Me.PM2_Position1.Location = New System.Drawing.Point(151, 30)
    Me.PM2_Position1.Name = "PM2_Position1"
    Me.PM2_Position1.Size = New System.Drawing.Size(121, 21)
    Me.PM2_Position1.SySimTooltip = "PM2_Position:InputComboBox"
    Me.PM2_Position1.TabIndex = 5
    Me.PM2_Position1.Text = "No_End_Position"
    '
    'PM2_Active1
    '
    Me.PM2_Active1.Location = New System.Drawing.Point(12, 19)
    Me.PM2_Active1.Maximum = 1
    Me.PM2_Active1.Name = "PM2_Active1"
    Me.PM2_Active1.Size = New System.Drawing.Size(40, 45)
    Me.PM2_Active1.SySimTooltip = "PM2_Active:BoolSlider"
    Me.PM2_Active1.TabIndex = 4
    Me.PM2_Active1.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'Label68
    '
    Me.Label68.AutoSize = True
    Me.Label68.Location = New System.Drawing.Point(54, 33)
    Me.Label68.Name = "Label68"
    Me.Label68.Size = New System.Drawing.Size(45, 13)
    Me.Label68.TabIndex = 1
    Me.Label68.Text = "ACTIVE"
    '
    'GroupBox16
    '
    Me.GroupBox16.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox16.Controls.Add(Me.Label78)
    Me.GroupBox16.Controls.Add(Me.PM1_Position_Out1)
    Me.GroupBox16.Controls.Add(Me.Label73)
    Me.GroupBox16.Controls.Add(Me.PM1_Position1)
    Me.GroupBox16.Location = New System.Drawing.Point(19, 27)
    Me.GroupBox16.Name = "GroupBox16"
    Me.GroupBox16.Size = New System.Drawing.Size(604, 74)
    Me.GroupBox16.TabIndex = 0
    Me.GroupBox16.TabStop = False
    Me.GroupBox16.Text = "PM1"
    '
    'Label78
    '
    Me.Label78.AutoSize = True
    Me.Label78.Location = New System.Drawing.Point(460, 35)
    Me.Label78.Name = "Label78"
    Me.Label78.Size = New System.Drawing.Size(91, 13)
    Me.Label78.TabIndex = 6
    Me.Label78.Text = "Position Reported"
    '
    'PM1_Position_Out1
    '
    Me.PM1_Position_Out1.Location = New System.Drawing.Point(354, 31)
    Me.PM1_Position_Out1.Name = "PM1_Position_Out1"
    Me.PM1_Position_Out1.Size = New System.Drawing.Size(100, 20)
    Me.PM1_Position_Out1.SySimTooltip = "PM1_Position_Out:OutputTextBox"
    Me.PM1_Position_Out1.TabIndex = 5
    '
    'Label73
    '
    Me.Label73.AutoSize = True
    Me.Label73.Location = New System.Drawing.Point(278, 34)
    Me.Label73.Name = "Label73"
    Me.Label73.Size = New System.Drawing.Size(44, 13)
    Me.Label73.TabIndex = 4
    Me.Label73.Text = "Position"
    '
    'PM1_Position1
    '
    Me.PM1_Position1.FormattingEnabled = True
    Me.PM1_Position1.Items.AddRange(New Object() {"LEFT", "NO_END_POSITION", "RIGHT", "TRAILED"})
    Me.PM1_Position1.Location = New System.Drawing.Point(151, 31)
    Me.PM1_Position1.Name = "PM1_Position1"
    Me.PM1_Position1.Size = New System.Drawing.Size(121, 21)
    Me.PM1_Position1.SySimTooltip = "PM1_Position:InputComboBox"
    Me.PM1_Position1.TabIndex = 3
    Me.PM1_Position1.Text = "No_End_Position"
    '
    'GroupBox13
    '
    Me.GroupBox13.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox13.Controls.Add(Me.D04_Con_tmax_Point_Operation2)
    Me.GroupBox13.Controls.Add(Me.Label43)
    Me.GroupBox13.Location = New System.Drawing.Point(13, 12)
    Me.GroupBox13.Name = "GroupBox13"
    Me.GroupBox13.Size = New System.Drawing.Size(639, 57)
    Me.GroupBox13.TabIndex = 2
    Me.GroupBox13.TabStop = False
    Me.GroupBox13.Text = "Configuration"
    '
    'D04_Con_tmax_Point_Operation2
    '
    Me.D04_Con_tmax_Point_Operation2.Location = New System.Drawing.Point(31, 22)
    Me.D04_Con_tmax_Point_Operation2.Name = "D04_Con_tmax_Point_Operation2"
    Me.D04_Con_tmax_Point_Operation2.Size = New System.Drawing.Size(100, 20)
    Me.D04_Con_tmax_Point_Operation2.SySimTooltip = "D04_Con_tmax_Point_Operation:InputIntegerBox"
    Me.D04_Con_tmax_Point_Operation2.TabIndex = 3
    Me.D04_Con_tmax_Point_Operation2.Text = "12000"
    Me.D04_Con_tmax_Point_Operation2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'Label43
    '
    Me.Label43.AutoSize = True
    Me.Label43.Location = New System.Drawing.Point(167, 25)
    Me.Label43.Name = "Label43"
    Me.Label43.Size = New System.Drawing.Size(156, 13)
    Me.Label43.TabIndex = 2
    Me.Label43.Text = "D4_Con_tmax_Point_Operation"
    '
    'GroupBox12
    '
    Me.GroupBox12.BackColor = System.Drawing.Color.Transparent
    Me.GroupBox12.Controls.Add(Me.DT01_Move_Point_Target2)
    Me.GroupBox12.Controls.Add(Me.T01_Cmd_Move_Point2)
    Me.GroupBox12.Controls.Add(Me.Label45)
    Me.GroupBox12.Controls.Add(Me.Label44)
    Me.GroupBox12.Location = New System.Drawing.Point(13, 75)
    Me.GroupBox12.Name = "GroupBox12"
    Me.GroupBox12.Size = New System.Drawing.Size(639, 98)
    Me.GroupBox12.TabIndex = 0
    Me.GroupBox12.TabStop = False
    Me.GroupBox12.Text = "SCI (Input from Subsytem - Electroinic Interlocking)"
    '
    'DT01_Move_Point_Target2
    '
    Me.DT01_Move_Point_Target2.FormattingEnabled = True
    Me.DT01_Move_Point_Target2.Items.AddRange(New Object() {"LEFT", "RIGHT"})
    Me.DT01_Move_Point_Target2.Location = New System.Drawing.Point(31, 53)
    Me.DT01_Move_Point_Target2.Name = "DT01_Move_Point_Target2"
    Me.DT01_Move_Point_Target2.Size = New System.Drawing.Size(121, 21)
    Me.DT01_Move_Point_Target2.SySimTooltip = "DT01_Move_Point_Target:InputComboBox"
    Me.DT01_Move_Point_Target2.TabIndex = 5
    Me.DT01_Move_Point_Target2.Text = "Left"
    '
    'T01_Cmd_Move_Point2
    '
    Me.T01_Cmd_Move_Point2.Location = New System.Drawing.Point(31, 23)
    Me.T01_Cmd_Move_Point2.Name = "T01_Cmd_Move_Point2"
    Me.T01_Cmd_Move_Point2.Size = New System.Drawing.Size(50, 23)
    Me.T01_Cmd_Move_Point2.SySimTooltip = "T01_Cmd_Move_Point:PulseButton"
    Me.T01_Cmd_Move_Point2.TabIndex = 4
    Me.T01_Cmd_Move_Point2.Text = "T1"
    Me.T01_Cmd_Move_Point2.UseVisualStyleBackColor = True
    '
    'Label45
    '
    Me.Label45.AutoSize = True
    Me.Label45.Location = New System.Drawing.Point(167, 58)
    Me.Label45.Name = "Label45"
    Me.Label45.Size = New System.Drawing.Size(128, 13)
    Me.Label45.TabIndex = 3
    Me.Label45.Text = "DT1_Move_Point_Target"
    '
    'Label44
    '
    Me.Label44.AutoSize = True
    Me.Label44.Location = New System.Drawing.Point(167, 28)
    Me.Label44.Name = "Label44"
    Me.Label44.Size = New System.Drawing.Size(110, 13)
    Me.Label44.TabIndex = 2
    Me.Label44.Text = "T1_Cmd_Move_Point"
    '
    'TabControl1
    '
    Me.TabControl1.Controls.Add(Me.TabPage4)
    Me.TabControl1.Controls.Add(Me.TabPage5)
    Me.TabControl1.Controls.Add(Me.TabPage8)
    Me.TabControl1.Controls.Add(Me.TabPage3)
    Me.TabControl1.ImeMode = System.Windows.Forms.ImeMode.[On]
    Me.TabControl1.Location = New System.Drawing.Point(31, 7)
    Me.TabControl1.Name = "TabControl1"
    Me.TabControl1.SelectedIndex = 0
    Me.TabControl1.Size = New System.Drawing.Size(680, 709)
    Me.TabControl1.TabIndex = 1
    '
    'TabPage5
    '
    Me.TabPage5.Controls.Add(Me.GroupBox7)
    Me.TabPage5.Controls.Add(Me.GroupBox2)
    Me.TabPage5.Location = New System.Drawing.Point(4, 22)
    Me.TabPage5.Name = "TabPage5"
    Me.TabPage5.Size = New System.Drawing.Size(672, 683)
    Me.TabPage5.TabIndex = 3
    Me.TabPage5.Text = "Input SMI Field Element"
    Me.TabPage5.UseVisualStyleBackColor = True
    '
    'GroupBox7
    '
    Me.GroupBox7.Controls.Add(Me.Label14)
    Me.GroupBox7.Controls.Add(Me.Label13)
    Me.GroupBox7.Controls.Add(Me.Label12)
    Me.GroupBox7.Controls.Add(Me.Label11)
    Me.GroupBox7.Controls.Add(Me.Label10)
    Me.GroupBox7.Controls.Add(Me.T12_Data_Installation_Successfully1)
    Me.GroupBox7.Controls.Add(Me.T6_Data_Up_To_Date1)
    Me.GroupBox7.Controls.Add(Me.T11_Data_Invalid1)
    Me.GroupBox7.Controls.Add(Me.Label9)
    Me.GroupBox7.Controls.Add(Me.T7_Data_Not_Up_To_Date1)
    Me.GroupBox7.Controls.Add(Me.T10_Data_Valid1)
    Me.GroupBox7.Controls.Add(Me.T8_Data1)
    Me.GroupBox7.Controls.Add(Me.Label8)
    Me.GroupBox7.Controls.Add(Me.T9_Transmission_Complete1)
    Me.GroupBox7.Location = New System.Drawing.Point(3, 216)
    Me.GroupBox7.Name = "GroupBox7"
    Me.GroupBox7.Size = New System.Drawing.Size(666, 226)
    Me.GroupBox7.TabIndex = 0
    Me.GroupBox7.TabStop = False
    Me.GroupBox7.Text = "Internal Events - SubS_MDM (SMI)"
    '
    'Label14
    '
    Me.Label14.AutoSize = True
    Me.Label14.Location = New System.Drawing.Point(118, 198)
    Me.Label14.Name = "Label14"
    Me.Label14.Size = New System.Drawing.Size(176, 13)
    Me.Label14.TabIndex = 27
    Me.Label14.Text = "T12_Data_Installation_Successfully"
    '
    'Label13
    '
    Me.Label13.AutoSize = True
    Me.Label13.Location = New System.Drawing.Point(119, 169)
    Me.Label13.Name = "Label13"
    Me.Label13.Size = New System.Drawing.Size(92, 13)
    Me.Label13.TabIndex = 26
    Me.Label13.Text = "T11_Data_Invalid"
    '
    'Label12
    '
    Me.Label12.AutoSize = True
    Me.Label12.Location = New System.Drawing.Point(118, 140)
    Me.Label12.Name = "Label12"
    Me.Label12.Size = New System.Drawing.Size(84, 13)
    Me.Label12.TabIndex = 25
    Me.Label12.Text = "T10_Data_Valid"
    '
    'Label11
    '
    Me.Label11.AutoSize = True
    Me.Label11.Location = New System.Drawing.Point(119, 111)
    Me.Label11.Name = "Label11"
    Me.Label11.Size = New System.Drawing.Size(137, 13)
    Me.Label11.TabIndex = 24
    Me.Label11.Text = "T9_Transmission_Complete"
    '
    'Label10
    '
    Me.Label10.AutoSize = True
    Me.Label10.Location = New System.Drawing.Point(119, 82)
    Me.Label10.Name = "Label10"
    Me.Label10.Size = New System.Drawing.Size(49, 13)
    Me.Label10.TabIndex = 23
    Me.Label10.Text = "T8_Data"
    '
    'T12_Data_Installation_Successfully1
    '
    Me.T12_Data_Installation_Successfully1.Location = New System.Drawing.Point(6, 193)
    Me.T12_Data_Installation_Successfully1.Name = "T12_Data_Installation_Successfully1"
    Me.T12_Data_Installation_Successfully1.Size = New System.Drawing.Size(50, 23)
    Me.T12_Data_Installation_Successfully1.SySimTooltip = "T12_Data_Installation_Successfully:PulseButton"
    Me.T12_Data_Installation_Successfully1.TabIndex = 20
    Me.T12_Data_Installation_Successfully1.Text = "T12"
    Me.T12_Data_Installation_Successfully1.UseVisualStyleBackColor = True
    '
    'T6_Data_Up_To_Date1
    '
    Me.T6_Data_Up_To_Date1.Location = New System.Drawing.Point(6, 19)
    Me.T6_Data_Up_To_Date1.Name = "T6_Data_Up_To_Date1"
    Me.T6_Data_Up_To_Date1.Size = New System.Drawing.Size(50, 23)
    Me.T6_Data_Up_To_Date1.SySimTooltip = "T6_Data_Up_To_Date:PulseButton"
    Me.T6_Data_Up_To_Date1.TabIndex = 14
    Me.T6_Data_Up_To_Date1.Text = "T6"
    Me.T6_Data_Up_To_Date1.UseVisualStyleBackColor = True
    '
    'T11_Data_Invalid1
    '
    Me.T11_Data_Invalid1.Location = New System.Drawing.Point(6, 164)
    Me.T11_Data_Invalid1.Name = "T11_Data_Invalid1"
    Me.T11_Data_Invalid1.Size = New System.Drawing.Size(50, 23)
    Me.T11_Data_Invalid1.SySimTooltip = "T11_Data_Invalid:PulseButton"
    Me.T11_Data_Invalid1.TabIndex = 19
    Me.T11_Data_Invalid1.Text = "T11"
    Me.T11_Data_Invalid1.UseVisualStyleBackColor = True
    '
    'Label9
    '
    Me.Label9.AutoSize = True
    Me.Label9.Location = New System.Drawing.Point(118, 53)
    Me.Label9.Name = "Label9"
    Me.Label9.Size = New System.Drawing.Size(140, 13)
    Me.Label9.TabIndex = 22
    Me.Label9.Text = "T7_Data_Not_Up_To_Date"
    '
    'T7_Data_Not_Up_To_Date1
    '
    Me.T7_Data_Not_Up_To_Date1.Location = New System.Drawing.Point(6, 48)
    Me.T7_Data_Not_Up_To_Date1.Name = "T7_Data_Not_Up_To_Date1"
    Me.T7_Data_Not_Up_To_Date1.Size = New System.Drawing.Size(50, 23)
    Me.T7_Data_Not_Up_To_Date1.SySimTooltip = "T7_Data_Not_Up_To_Date:PulseButton"
    Me.T7_Data_Not_Up_To_Date1.TabIndex = 15
    Me.T7_Data_Not_Up_To_Date1.Text = "T7"
    Me.T7_Data_Not_Up_To_Date1.UseVisualStyleBackColor = True
    '
    'T10_Data_Valid1
    '
    Me.T10_Data_Valid1.Location = New System.Drawing.Point(6, 135)
    Me.T10_Data_Valid1.Name = "T10_Data_Valid1"
    Me.T10_Data_Valid1.Size = New System.Drawing.Size(50, 23)
    Me.T10_Data_Valid1.SySimTooltip = "T10_Data_Valid:PulseButton"
    Me.T10_Data_Valid1.TabIndex = 18
    Me.T10_Data_Valid1.Text = "T10"
    Me.T10_Data_Valid1.UseVisualStyleBackColor = True
    '
    'T8_Data1
    '
    Me.T8_Data1.Location = New System.Drawing.Point(6, 77)
    Me.T8_Data1.Name = "T8_Data1"
    Me.T8_Data1.Size = New System.Drawing.Size(50, 23)
    Me.T8_Data1.SySimTooltip = "T8_Data:PulseButton"
    Me.T8_Data1.TabIndex = 16
    Me.T8_Data1.Text = "T8"
    Me.T8_Data1.UseVisualStyleBackColor = True
    '
    'Label8
    '
    Me.Label8.AutoSize = True
    Me.Label8.Location = New System.Drawing.Point(119, 24)
    Me.Label8.Name = "Label8"
    Me.Label8.Size = New System.Drawing.Size(117, 13)
    Me.Label8.TabIndex = 21
    Me.Label8.Text = "T6_Data_Up_To_Date"
    '
    'T9_Transmission_Complete1
    '
    Me.T9_Transmission_Complete1.Location = New System.Drawing.Point(6, 106)
    Me.T9_Transmission_Complete1.Name = "T9_Transmission_Complete1"
    Me.T9_Transmission_Complete1.Size = New System.Drawing.Size(50, 23)
    Me.T9_Transmission_Complete1.SySimTooltip = "T9_Transmission_Complete:PulseButton"
    Me.T9_Transmission_Complete1.TabIndex = 17
    Me.T9_Transmission_Complete1.Text = "T9"
    Me.T9_Transmission_Complete1.UseVisualStyleBackColor = True
    '
    'GroupBox2
    '
    Me.GroupBox2.Controls.Add(Me.D5_Con_tmax_DataTransmission1)
    Me.GroupBox2.Controls.Add(Me.Label5)
    Me.GroupBox2.Controls.Add(Me.Label4)
    Me.GroupBox2.Controls.Add(Me.Label3)
    Me.GroupBox2.Controls.Add(Me.Label2)
    Me.GroupBox2.Controls.Add(Me.Label1)
    Me.GroupBox2.Controls.Add(Me.D4_Con_tmax_Response_MDM1)
    Me.GroupBox2.Controls.Add(Me.D3_Con_t_Ini_Max1)
    Me.GroupBox2.Controls.Add(Me.D2_Con_t_Ini_Step1)
    Me.GroupBox2.Controls.Add(Me.D1_Con_t_Ini_Def_Delay1)
    Me.GroupBox2.Controls.Add(Me.Lable1)
    Me.GroupBox2.Controls.Add(Me.D20_Con_MDM_Used1)
    Me.GroupBox2.Location = New System.Drawing.Point(3, 6)
    Me.GroupBox2.Name = "GroupBox2"
    Me.GroupBox2.Size = New System.Drawing.Size(666, 204)
    Me.GroupBox2.TabIndex = 0
    Me.GroupBox2.TabStop = False
    Me.GroupBox2.Text = "Configuration - SubS_MDM (SMI)"
    '
    'D5_Con_tmax_DataTransmission1
    '
    Me.D5_Con_tmax_DataTransmission1.Location = New System.Drawing.Point(6, 175)
    Me.D5_Con_tmax_DataTransmission1.Name = "D5_Con_tmax_DataTransmission1"
    Me.D5_Con_tmax_DataTransmission1.Size = New System.Drawing.Size(100, 20)
    Me.D5_Con_tmax_DataTransmission1.SySimTooltip = "D5_Con_tmax_DataTransmission:InputIntegerBox"
    Me.D5_Con_tmax_DataTransmission1.TabIndex = 24
    Me.D5_Con_tmax_DataTransmission1.Text = "1000"
    Me.D5_Con_tmax_DataTransmission1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'Label5
    '
    Me.Label5.AutoSize = True
    Me.Label5.Location = New System.Drawing.Point(119, 179)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(164, 13)
    Me.Label5.TabIndex = 23
    Me.Label5.Text = "D5_Con_tmax_DataTransmission"
    '
    'Label4
    '
    Me.Label4.AutoSize = True
    Me.Label4.Location = New System.Drawing.Point(119, 153)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(160, 13)
    Me.Label4.TabIndex = 22
    Me.Label4.Text = "D4_Con_tmax_Response_MDM"
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(119, 127)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(98, 13)
    Me.Label3.TabIndex = 21
    Me.Label3.Text = "D3_Con_t_Ini_Max"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(119, 101)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(100, 13)
    Me.Label2.TabIndex = 20
    Me.Label2.Text = "D2_Con_t_Ini_Step" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(119, 74)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(128, 13)
    Me.Label1.TabIndex = 19
    Me.Label1.Text = "D1_Con_t_Ini_Def_Delay"
    '
    'D4_Con_tmax_Response_MDM1
    '
    Me.D4_Con_tmax_Response_MDM1.Location = New System.Drawing.Point(6, 149)
    Me.D4_Con_tmax_Response_MDM1.Name = "D4_Con_tmax_Response_MDM1"
    Me.D4_Con_tmax_Response_MDM1.Size = New System.Drawing.Size(100, 20)
    Me.D4_Con_tmax_Response_MDM1.SySimTooltip = "D4_Con_tmax_Response_MDM:InputIntegerBox"
    Me.D4_Con_tmax_Response_MDM1.TabIndex = 18
    Me.D4_Con_tmax_Response_MDM1.Text = "1000"
    Me.D4_Con_tmax_Response_MDM1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'D3_Con_t_Ini_Max1
    '
    Me.D3_Con_t_Ini_Max1.Location = New System.Drawing.Point(6, 123)
    Me.D3_Con_t_Ini_Max1.Name = "D3_Con_t_Ini_Max1"
    Me.D3_Con_t_Ini_Max1.Size = New System.Drawing.Size(100, 20)
    Me.D3_Con_t_Ini_Max1.SySimTooltip = "D3_Con_t_Ini_Max:InputIntegerBox"
    Me.D3_Con_t_Ini_Max1.TabIndex = 17
    Me.D3_Con_t_Ini_Max1.Text = "600000"
    Me.D3_Con_t_Ini_Max1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'D2_Con_t_Ini_Step1
    '
    Me.D2_Con_t_Ini_Step1.Location = New System.Drawing.Point(6, 97)
    Me.D2_Con_t_Ini_Step1.Name = "D2_Con_t_Ini_Step1"
    Me.D2_Con_t_Ini_Step1.Size = New System.Drawing.Size(100, 20)
    Me.D2_Con_t_Ini_Step1.SySimTooltip = "D2_Con_t_Ini_Step:InputIntegerBox"
    Me.D2_Con_t_Ini_Step1.TabIndex = 16
    Me.D2_Con_t_Ini_Step1.Text = "10000"
    Me.D2_Con_t_Ini_Step1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'D1_Con_t_Ini_Def_Delay1
    '
    Me.D1_Con_t_Ini_Def_Delay1.Location = New System.Drawing.Point(6, 70)
    Me.D1_Con_t_Ini_Def_Delay1.Name = "D1_Con_t_Ini_Def_Delay1"
    Me.D1_Con_t_Ini_Def_Delay1.Size = New System.Drawing.Size(100, 20)
    Me.D1_Con_t_Ini_Def_Delay1.SySimTooltip = "D1_Con_t_Ini_Def_Delay:InputIntegerBox"
    Me.D1_Con_t_Ini_Def_Delay1.TabIndex = 15
    Me.D1_Con_t_Ini_Def_Delay1.Text = "10000"
    Me.D1_Con_t_Ini_Def_Delay1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'Lable1
    '
    Me.Lable1.AutoSize = True
    Me.Lable1.Location = New System.Drawing.Point(88, 35)
    Me.Lable1.Name = "Lable1"
    Me.Lable1.Size = New System.Drawing.Size(115, 13)
    Me.Lable1.TabIndex = 3
    Me.Lable1.Text = "D20_Con_MDM_Used"
    '
    'D20_Con_MDM_Used1
    '
    Me.D20_Con_MDM_Used1.Location = New System.Drawing.Point(6, 19)
    Me.D20_Con_MDM_Used1.Maximum = 1
    Me.D20_Con_MDM_Used1.Name = "D20_Con_MDM_Used1"
    Me.D20_Con_MDM_Used1.Size = New System.Drawing.Size(35, 45)
    Me.D20_Con_MDM_Used1.SySimTooltip = "D20_Con_MDM_Used:BoolSlider"
    Me.D20_Con_MDM_Used1.TabIndex = 2
    Me.D20_Con_MDM_Used1.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'TabPage8
    '
    Me.TabPage8.Controls.Add(Me.GroupBox20)
    Me.TabPage8.Controls.Add(Me.GroupBox19)
    Me.TabPage8.Controls.Add(Me.GroupBox18)
    Me.TabPage8.Controls.Add(Me.GroupBox8)
    Me.TabPage8.Location = New System.Drawing.Point(4, 22)
    Me.TabPage8.Name = "TabPage8"
    Me.TabPage8.Size = New System.Drawing.Size(672, 683)
    Me.TabPage8.TabIndex = 4
    Me.TabPage8.Text = "Input EST Field Element | Input SCI"
    Me.TabPage8.UseVisualStyleBackColor = True
    '
    'GroupBox20
    '
    Me.GroupBox20.Controls.Add(Me.GroupBox26)
    Me.GroupBox20.Controls.Add(Me.GroupBox27)
    Me.GroupBox20.Location = New System.Drawing.Point(340, 296)
    Me.GroupBox20.Name = "GroupBox20"
    Me.GroupBox20.Size = New System.Drawing.Size(329, 306)
    Me.GroupBox20.TabIndex = 3
    Me.GroupBox20.TabStop = False
    Me.GroupBox20.Text = "SubS_P"
    '
    'GroupBox26
    '
    Me.GroupBox26.Controls.Add(Me.Label46)
    Me.GroupBox26.Controls.Add(Me.Label33)
    Me.GroupBox26.Controls.Add(Me.T20_Protocol_Error1)
    Me.GroupBox26.Controls.Add(Me.Label27)
    Me.GroupBox26.Controls.Add(Me.T21_Formal_Telegram_Error1)
    Me.GroupBox26.Controls.Add(Me.T22_Content_Telegram_Error1)
    Me.GroupBox26.Location = New System.Drawing.Point(6, 178)
    Me.GroupBox26.Name = "GroupBox26"
    Me.GroupBox26.Size = New System.Drawing.Size(319, 116)
    Me.GroupBox26.TabIndex = 3
    Me.GroupBox26.TabStop = False
    Me.GroupBox26.Text = "Internal Error Events"
    '
    'Label46
    '
    Me.Label46.AutoSize = True
    Me.Label46.Location = New System.Drawing.Point(112, 87)
    Me.Label46.Name = "Label46"
    Me.Label46.Size = New System.Drawing.Size(141, 13)
    Me.Label46.TabIndex = 21
    Me.Label46.Text = "T22_Content_Telegrm_Error"
    '
    'Label33
    '
    Me.Label33.AutoSize = True
    Me.Label33.Location = New System.Drawing.Point(112, 56)
    Me.Label33.Name = "Label33"
    Me.Label33.Size = New System.Drawing.Size(141, 13)
    Me.Label33.TabIndex = 20
    Me.Label33.Text = "T21_Formal_Telegram_Error"
    '
    'T20_Protocol_Error1
    '
    Me.T20_Protocol_Error1.Location = New System.Drawing.Point(6, 19)
    Me.T20_Protocol_Error1.Name = "T20_Protocol_Error1"
    Me.T20_Protocol_Error1.Size = New System.Drawing.Size(50, 23)
    Me.T20_Protocol_Error1.SySimTooltip = "T20_Protocol_Error:PulseButton"
    Me.T20_Protocol_Error1.TabIndex = 16
    Me.T20_Protocol_Error1.Text = "T20"
    Me.T20_Protocol_Error1.UseVisualStyleBackColor = True
    '
    'Label27
    '
    Me.Label27.AutoSize = True
    Me.Label27.Location = New System.Drawing.Point(112, 24)
    Me.Label27.Name = "Label27"
    Me.Label27.Size = New System.Drawing.Size(99, 13)
    Me.Label27.TabIndex = 19
    Me.Label27.Text = "T20_Protocol_Error"
    '
    'T21_Formal_Telegram_Error1
    '
    Me.T21_Formal_Telegram_Error1.Location = New System.Drawing.Point(6, 51)
    Me.T21_Formal_Telegram_Error1.Name = "T21_Formal_Telegram_Error1"
    Me.T21_Formal_Telegram_Error1.Size = New System.Drawing.Size(50, 23)
    Me.T21_Formal_Telegram_Error1.SySimTooltip = "T21_Formal_Telegram_Error:PulseButton"
    Me.T21_Formal_Telegram_Error1.TabIndex = 17
    Me.T21_Formal_Telegram_Error1.Text = "T21"
    Me.T21_Formal_Telegram_Error1.UseVisualStyleBackColor = True
    '
    'T22_Content_Telegram_Error1
    '
    Me.T22_Content_Telegram_Error1.Location = New System.Drawing.Point(6, 82)
    Me.T22_Content_Telegram_Error1.Name = "T22_Content_Telegram_Error1"
    Me.T22_Content_Telegram_Error1.Size = New System.Drawing.Size(50, 23)
    Me.T22_Content_Telegram_Error1.SySimTooltip = "T22_Content_Telegram_Error:PulseButton"
    Me.T22_Content_Telegram_Error1.TabIndex = 18
    Me.T22_Content_Telegram_Error1.Text = "T22"
    Me.T22_Content_Telegram_Error1.UseVisualStyleBackColor = True
    '
    'GroupBox27
    '
    Me.GroupBox27.Controls.Add(Me.Label92)
    Me.GroupBox27.Controls.Add(Me.D23_Con_Checksum_Data_Used1)
    Me.GroupBox27.Controls.Add(Me.Label22)
    Me.GroupBox27.Controls.Add(Me.Label21)
    Me.GroupBox27.Controls.Add(Me.D4_Checksum_Data1)
    Me.GroupBox27.Controls.Add(Me.D3_Con_PDI_Version1)
    Me.GroupBox27.Location = New System.Drawing.Point(6, 19)
    Me.GroupBox27.Name = "GroupBox27"
    Me.GroupBox27.Size = New System.Drawing.Size(319, 153)
    Me.GroupBox27.TabIndex = 2
    Me.GroupBox27.TabStop = False
    Me.GroupBox27.Text = "Configuration related to SCI"
    '
    'Label92
    '
    Me.Label92.AutoSize = True
    Me.Label92.Location = New System.Drawing.Point(112, 120)
    Me.Label92.Name = "Label92"
    Me.Label92.Size = New System.Drawing.Size(168, 13)
    Me.Label92.TabIndex = 24
    Me.Label92.Text = "D23_Con_Checksum_Data_Used"
    '
    'D23_Con_Checksum_Data_Used1
    '
    Me.D23_Con_Checksum_Data_Used1.Location = New System.Drawing.Point(6, 105)
    Me.D23_Con_Checksum_Data_Used1.Maximum = 1
    Me.D23_Con_Checksum_Data_Used1.Name = "D23_Con_Checksum_Data_Used1"
    Me.D23_Con_Checksum_Data_Used1.Size = New System.Drawing.Size(35, 45)
    Me.D23_Con_Checksum_Data_Used1.SySimTooltip = "D23_Con_Checksum_Data_Used:BoolSlider"
    Me.D23_Con_Checksum_Data_Used1.TabIndex = 23
    Me.D23_Con_Checksum_Data_Used1.TickStyle = System.Windows.Forms.TickStyle.Both
    '
    'Label22
    '
    Me.Label22.AutoSize = True
    Me.Label22.Location = New System.Drawing.Point(112, 82)
    Me.Label22.Name = "Label22"
    Me.Label22.Size = New System.Drawing.Size(106, 13)
    Me.Label22.TabIndex = 7
    Me.Label22.Text = "D4_Checksum_Data"
    '
    'Label21
    '
    Me.Label21.AutoSize = True
    Me.Label21.Location = New System.Drawing.Point(112, 53)
    Me.Label21.Name = "Label21"
    Me.Label21.Size = New System.Drawing.Size(111, 13)
    Me.Label21.TabIndex = 6
    Me.Label21.Text = "D3_Con_PDI_Version"
    '
    'D4_Checksum_Data1
    '
    Me.D4_Checksum_Data1.Location = New System.Drawing.Point(6, 79)
    Me.D4_Checksum_Data1.Name = "D4_Checksum_Data1"
    Me.D4_Checksum_Data1.Size = New System.Drawing.Size(100, 20)
    Me.D4_Checksum_Data1.SySimTooltip = "D4_Checksum_Data:InputTextBox"
    Me.D4_Checksum_Data1.TabIndex = 5
    Me.D4_Checksum_Data1.Text = "12491"
    Me.D4_Checksum_Data1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'D3_Con_PDI_Version1
    '
    Me.D3_Con_PDI_Version1.Location = New System.Drawing.Point(6, 50)
    Me.D3_Con_PDI_Version1.Name = "D3_Con_PDI_Version1"
    Me.D3_Con_PDI_Version1.Size = New System.Drawing.Size(100, 20)
    Me.D3_Con_PDI_Version1.SySimTooltip = "D3_Con_PDI_Version:InputTextBox"
    Me.D3_Con_PDI_Version1.TabIndex = 4
    Me.D3_Con_PDI_Version1.Text = "1"
    Me.D3_Con_PDI_Version1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'GroupBox19
    '
    Me.GroupBox19.Controls.Add(Me.GroupBox25)
    Me.GroupBox19.Controls.Add(Me.GroupBox24)
    Me.GroupBox19.Location = New System.Drawing.Point(3, 296)
    Me.GroupBox19.Name = "GroupBox19"
    Me.GroupBox19.Size = New System.Drawing.Size(331, 306)
    Me.GroupBox19.TabIndex = 2
    Me.GroupBox19.TabStop = False
    Me.GroupBox19.Text = "SubS_EIL"
    '
    'GroupBox25
    '
    Me.GroupBox25.Controls.Add(Me.T22_Content_Telegram_Error_I1)
    Me.GroupBox25.Controls.Add(Me.T21_Formal_Telegram_Error_I1)
    Me.GroupBox25.Controls.Add(Me.T20_Protocol_Error_I1)
    Me.GroupBox25.Controls.Add(Me.Label90)
    Me.GroupBox25.Controls.Add(Me.Label89)
    Me.GroupBox25.Controls.Add(Me.Label88)
    Me.GroupBox25.Location = New System.Drawing.Point(6, 178)
    Me.GroupBox25.Name = "GroupBox25"
    Me.GroupBox25.Size = New System.Drawing.Size(319, 116)
    Me.GroupBox25.TabIndex = 1
    Me.GroupBox25.TabStop = False
    Me.GroupBox25.Text = "Internal Error Events"
    '
    'T22_Content_Telegram_Error_I1
    '
    Me.T22_Content_Telegram_Error_I1.Location = New System.Drawing.Point(0, 82)
    Me.T22_Content_Telegram_Error_I1.Name = "T22_Content_Telegram_Error_I1"
    Me.T22_Content_Telegram_Error_I1.Size = New System.Drawing.Size(50, 23)
    Me.T22_Content_Telegram_Error_I1.SySimTooltip = "T22_Content_Telegram_Error_I:PulseButton"
    Me.T22_Content_Telegram_Error_I1.TabIndex = 17
    Me.T22_Content_Telegram_Error_I1.Text = "T22"
    Me.T22_Content_Telegram_Error_I1.UseVisualStyleBackColor = True
    '
    'T21_Formal_Telegram_Error_I1
    '
    Me.T21_Formal_Telegram_Error_I1.Location = New System.Drawing.Point(0, 51)
    Me.T21_Formal_Telegram_Error_I1.Name = "T21_Formal_Telegram_Error_I1"
    Me.T21_Formal_Telegram_Error_I1.Size = New System.Drawing.Size(50, 23)
    Me.T21_Formal_Telegram_Error_I1.SySimTooltip = "T21_Formal_Telegram_Error_I:PulseButton"
    Me.T21_Formal_Telegram_Error_I1.TabIndex = 16
    Me.T21_Formal_Telegram_Error_I1.Text = "T21"
    Me.T21_Formal_Telegram_Error_I1.UseVisualStyleBackColor = True
    '
    'T20_Protocol_Error_I1
    '
    Me.T20_Protocol_Error_I1.Location = New System.Drawing.Point(0, 19)
    Me.T20_Protocol_Error_I1.Name = "T20_Protocol_Error_I1"
    Me.T20_Protocol_Error_I1.Size = New System.Drawing.Size(50, 23)
    Me.T20_Protocol_Error_I1.SySimTooltip = "T20_Protocol_Error_I:PulseButton"
    Me.T20_Protocol_Error_I1.TabIndex = 15
    Me.T20_Protocol_Error_I1.Text = "T20"
    Me.T20_Protocol_Error_I1.UseVisualStyleBackColor = True
    '
    'Label90
    '
    Me.Label90.AutoSize = True
    Me.Label90.Location = New System.Drawing.Point(106, 87)
    Me.Label90.Name = "Label90"
    Me.Label90.Size = New System.Drawing.Size(141, 13)
    Me.Label90.TabIndex = 14
    Me.Label90.Text = "T22_Content_Telegrm_Error"
    '
    'Label89
    '
    Me.Label89.AutoSize = True
    Me.Label89.Location = New System.Drawing.Point(106, 56)
    Me.Label89.Name = "Label89"
    Me.Label89.Size = New System.Drawing.Size(141, 13)
    Me.Label89.TabIndex = 13
    Me.Label89.Text = "T21_Formal_Telegram_Error"
    '
    'Label88
    '
    Me.Label88.AutoSize = True
    Me.Label88.Location = New System.Drawing.Point(106, 24)
    Me.Label88.Name = "Label88"
    Me.Label88.Size = New System.Drawing.Size(99, 13)
    Me.Label88.TabIndex = 12
    Me.Label88.Text = "T20_Protocol_Error"
    '
    'GroupBox24
    '
    Me.GroupBox24.Controls.Add(Me.D4_Con_Checksum_Data_I1)
    Me.GroupBox24.Controls.Add(Me.D3_Con_PDI_Version_I1)
    Me.GroupBox24.Controls.Add(Me.Label87)
    Me.GroupBox24.Controls.Add(Me.Label86)
    Me.GroupBox24.Controls.Add(Me.Label85)
    Me.GroupBox24.Controls.Add(Me.D2_Con_tmax_PDI_Connection_I1)
    Me.GroupBox24.Location = New System.Drawing.Point(6, 19)
    Me.GroupBox24.Name = "GroupBox24"
    Me.GroupBox24.Size = New System.Drawing.Size(319, 153)
    Me.GroupBox24.TabIndex = 0
    Me.GroupBox24.TabStop = False
    Me.GroupBox24.Text = "Configuration - SAP_SubS_P"
    '
    'D4_Con_Checksum_Data_I1
    '
    Me.D4_Con_Checksum_Data_I1.Location = New System.Drawing.Point(0, 75)
    Me.D4_Con_Checksum_Data_I1.Name = "D4_Con_Checksum_Data_I1"
    Me.D4_Con_Checksum_Data_I1.Size = New System.Drawing.Size(100, 20)
    Me.D4_Con_Checksum_Data_I1.SySimTooltip = "D4_Con_Checksum_Data_I:InputTextBox"
    Me.D4_Con_Checksum_Data_I1.TabIndex = 14
    Me.D4_Con_Checksum_Data_I1.Text = "12491"
    Me.D4_Con_Checksum_Data_I1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'D3_Con_PDI_Version_I1
    '
    Me.D3_Con_PDI_Version_I1.Location = New System.Drawing.Point(0, 47)
    Me.D3_Con_PDI_Version_I1.Name = "D3_Con_PDI_Version_I1"
    Me.D3_Con_PDI_Version_I1.Size = New System.Drawing.Size(100, 20)
    Me.D3_Con_PDI_Version_I1.SySimTooltip = "D3_Con_PDI_Version_I:InputTextBox"
    Me.D3_Con_PDI_Version_I1.TabIndex = 13
    Me.D3_Con_PDI_Version_I1.Text = "1"
    Me.D3_Con_PDI_Version_I1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'Label87
    '
    Me.Label87.AutoSize = True
    Me.Label87.Location = New System.Drawing.Point(106, 78)
    Me.Label87.Name = "Label87"
    Me.Label87.Size = New System.Drawing.Size(131, 13)
    Me.Label87.TabIndex = 12
    Me.Label87.Text = "D4_Con_Checksum_Data"
    '
    'Label86
    '
    Me.Label86.AutoSize = True
    Me.Label86.Location = New System.Drawing.Point(106, 50)
    Me.Label86.Name = "Label86"
    Me.Label86.Size = New System.Drawing.Size(111, 13)
    Me.Label86.TabIndex = 11
    Me.Label86.Text = "D3_Con_PDI_Version"
    '
    'Label85
    '
    Me.Label85.AutoSize = True
    Me.Label85.Location = New System.Drawing.Point(106, 22)
    Me.Label85.Name = "Label85"
    Me.Label85.Size = New System.Drawing.Size(158, 13)
    Me.Label85.TabIndex = 10
    Me.Label85.Text = "D2_Con_tmax_PDI_Connection"
    '
    'D2_Con_tmax_PDI_Connection_I1
    '
    Me.D2_Con_tmax_PDI_Connection_I1.Location = New System.Drawing.Point(0, 19)
    Me.D2_Con_tmax_PDI_Connection_I1.Name = "D2_Con_tmax_PDI_Connection_I1"
    Me.D2_Con_tmax_PDI_Connection_I1.Size = New System.Drawing.Size(100, 20)
    Me.D2_Con_tmax_PDI_Connection_I1.SySimTooltip = "D2_Con_tmax_PDI_Connection_I:InputIntegerBox"
    Me.D2_Con_tmax_PDI_Connection_I1.TabIndex = 9
    Me.D2_Con_tmax_PDI_Connection_I1.Text = "20000"
    Me.D2_Con_tmax_PDI_Connection_I1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'GroupBox18
    '
    Me.GroupBox18.Controls.Add(Me.Label91)
    Me.GroupBox18.Controls.Add(Me.T10_SCP_Connection_Terminated1)
    Me.GroupBox18.Controls.Add(Me.T5_SCP_Connection1)
    Me.GroupBox18.Controls.Add(Me.Label23)
    Me.GroupBox18.Location = New System.Drawing.Point(3, 212)
    Me.GroupBox18.Name = "GroupBox18"
    Me.GroupBox18.Size = New System.Drawing.Size(666, 78)
    Me.GroupBox18.TabIndex = 1
    Me.GroupBox18.TabStop = False
    Me.GroupBox18.Text = "SCP"
    '
    'Label91
    '
    Me.Label91.AutoSize = True
    Me.Label91.Location = New System.Drawing.Point(61, 53)
    Me.Label91.Name = "Label91"
    Me.Label91.Size = New System.Drawing.Size(172, 13)
    Me.Label91.TabIndex = 25
    Me.Label91.Text = "T10_SCP_Connection_Terminated"
    '
    'T10_SCP_Connection_Terminated1
    '
    Me.T10_SCP_Connection_Terminated1.Location = New System.Drawing.Point(6, 48)
    Me.T10_SCP_Connection_Terminated1.Name = "T10_SCP_Connection_Terminated1"
    Me.T10_SCP_Connection_Terminated1.Size = New System.Drawing.Size(50, 23)
    Me.T10_SCP_Connection_Terminated1.SySimTooltip = "T10_SCP_Connection_Terminated:PulseButton"
    Me.T10_SCP_Connection_Terminated1.TabIndex = 24
    Me.T10_SCP_Connection_Terminated1.Text = "T10"
    Me.T10_SCP_Connection_Terminated1.UseVisualStyleBackColor = True
    '
    'T5_SCP_Connection1
    '
    Me.T5_SCP_Connection1.Location = New System.Drawing.Point(6, 19)
    Me.T5_SCP_Connection1.Name = "T5_SCP_Connection1"
    Me.T5_SCP_Connection1.Size = New System.Drawing.Size(50, 23)
    Me.T5_SCP_Connection1.SySimTooltip = "T5_SCP_Connection:PulseButton"
    Me.T5_SCP_Connection1.TabIndex = 23
    Me.T5_SCP_Connection1.Text = "T5"
    Me.T5_SCP_Connection1.UseVisualStyleBackColor = True
    '
    'Label23
    '
    Me.Label23.AutoSize = True
    Me.Label23.Location = New System.Drawing.Point(61, 24)
    Me.Label23.Name = "Label23"
    Me.Label23.Size = New System.Drawing.Size(107, 13)
    Me.Label23.TabIndex = 22
    Me.Label23.Text = "T5_SCP_Connection"
    '
    'GroupBox8
    '
    Me.GroupBox8.Controls.Add(Me.T5_SIL_Not_Fulfilled1)
    Me.GroupBox8.Controls.Add(Me.Label97)
    Me.GroupBox8.Controls.Add(Me.D44_Con_tmax_Booting1)
    Me.GroupBox8.Controls.Add(Me.Label47)
    Me.GroupBox8.Controls.Add(Me.Label20)
    Me.GroupBox8.Controls.Add(Me.Label18)
    Me.GroupBox8.Controls.Add(Me.Label17)
    Me.GroupBox8.Controls.Add(Me.Label16)
    Me.GroupBox8.Controls.Add(Me.Label15)
    Me.GroupBox8.Controls.Add(Me.T7_Invalid_Or_Missing_Basic_Data1)
    Me.GroupBox8.Controls.Add(Me.T4_Booted1)
    Me.GroupBox8.Controls.Add(Me.T3_Reset1)
    Me.GroupBox8.Controls.Add(Me.T2_Power_Off_Detected1)
    Me.GroupBox8.Controls.Add(Me.T1_Power_On_Detected1)
    Me.GroupBox8.Location = New System.Drawing.Point(3, 6)
    Me.GroupBox8.Name = "GroupBox8"
    Me.GroupBox8.Size = New System.Drawing.Size(666, 204)
    Me.GroupBox8.TabIndex = 0
    Me.GroupBox8.TabStop = False
    Me.GroupBox8.Text = "Internal Events - EST_ EfeS"
    '
    'T5_SIL_Not_Fulfilled1
    '
    Me.T5_SIL_Not_Fulfilled1.Location = New System.Drawing.Point(6, 135)
    Me.T5_SIL_Not_Fulfilled1.Name = "T5_SIL_Not_Fulfilled1"
    Me.T5_SIL_Not_Fulfilled1.Size = New System.Drawing.Size(50, 23)
    Me.T5_SIL_Not_Fulfilled1.SySimTooltip = "T5_SIL_Not_Fulfilled:PulseButton"
    Me.T5_SIL_Not_Fulfilled1.TabIndex = 25
    Me.T5_SIL_Not_Fulfilled1.Text = "T5"
    Me.T5_SIL_Not_Fulfilled1.UseVisualStyleBackColor = True
    '
    'Label97
    '
    Me.Label97.AutoSize = True
    Me.Label97.Location = New System.Drawing.Point(461, 25)
    Me.Label97.Name = "Label97"
    Me.Label97.Size = New System.Drawing.Size(122, 13)
    Me.Label97.TabIndex = 24
    Me.Label97.Text = "D44_Con_tmax_Booting"
    '
    'D44_Con_tmax_Booting1
    '
    Me.D44_Con_tmax_Booting1.Location = New System.Drawing.Point(349, 22)
    Me.D44_Con_tmax_Booting1.Name = "D44_Con_tmax_Booting1"
    Me.D44_Con_tmax_Booting1.Size = New System.Drawing.Size(100, 20)
    Me.D44_Con_tmax_Booting1.SySimTooltip = "D44_Con_tmax_Booting:InputIntegerBox"
    Me.D44_Con_tmax_Booting1.TabIndex = 23
    Me.D44_Con_tmax_Booting1.Text = "120000"
    Me.D44_Con_tmax_Booting1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'Label47
    '
    Me.Label47.AutoSize = True
    Me.Label47.Location = New System.Drawing.Point(62, 140)
    Me.Label47.Name = "Label47"
    Me.Label47.Size = New System.Drawing.Size(108, 13)
    Me.Label47.TabIndex = 22
    Me.Label47.Text = "T5_SIL_Not_Fullfilled"
    '
    'Label20
    '
    Me.Label20.AutoSize = True
    Me.Label20.Location = New System.Drawing.Point(62, 169)
    Me.Label20.Name = "Label20"
    Me.Label20.Size = New System.Drawing.Size(176, 13)
    Me.Label20.TabIndex = 21
    Me.Label20.Text = "T7_Invalid_Or_Missing_Basic_Data"
    '
    'Label18
    '
    Me.Label18.AutoSize = True
    Me.Label18.Location = New System.Drawing.Point(62, 111)
    Me.Label18.Name = "Label18"
    Me.Label18.Size = New System.Drawing.Size(60, 13)
    Me.Label18.TabIndex = 20
    Me.Label18.Text = "T4_Booted"
    '
    'Label17
    '
    Me.Label17.AutoSize = True
    Me.Label17.Location = New System.Drawing.Point(62, 82)
    Me.Label17.Name = "Label17"
    Me.Label17.Size = New System.Drawing.Size(54, 13)
    Me.Label17.TabIndex = 19
    Me.Label17.Text = "T3_Reset"
    '
    'Label16
    '
    Me.Label16.AutoSize = True
    Me.Label16.Location = New System.Drawing.Point(61, 53)
    Me.Label16.Name = "Label16"
    Me.Label16.Size = New System.Drawing.Size(126, 13)
    Me.Label16.TabIndex = 18
    Me.Label16.Text = "T2_Power_Off_Detected"
    '
    'Label15
    '
    Me.Label15.AutoSize = True
    Me.Label15.Location = New System.Drawing.Point(61, 24)
    Me.Label15.Name = "Label15"
    Me.Label15.Size = New System.Drawing.Size(126, 13)
    Me.Label15.TabIndex = 17
    Me.Label15.Text = "T1_Power_On_Detected"
    '
    'T7_Invalid_Or_Missing_Basic_Data1
    '
    Me.T7_Invalid_Or_Missing_Basic_Data1.Location = New System.Drawing.Point(6, 164)
    Me.T7_Invalid_Or_Missing_Basic_Data1.Name = "T7_Invalid_Or_Missing_Basic_Data1"
    Me.T7_Invalid_Or_Missing_Basic_Data1.Size = New System.Drawing.Size(50, 23)
    Me.T7_Invalid_Or_Missing_Basic_Data1.SySimTooltip = "T7_Invalid_Or_Missing_Basic_Data:PulseButton"
    Me.T7_Invalid_Or_Missing_Basic_Data1.TabIndex = 16
    Me.T7_Invalid_Or_Missing_Basic_Data1.Text = "T7"
    Me.T7_Invalid_Or_Missing_Basic_Data1.UseVisualStyleBackColor = True
    '
    'T4_Booted1
    '
    Me.T4_Booted1.Location = New System.Drawing.Point(6, 106)
    Me.T4_Booted1.Name = "T4_Booted1"
    Me.T4_Booted1.Size = New System.Drawing.Size(50, 23)
    Me.T4_Booted1.SySimTooltip = "T4_Booted:PulseButton"
    Me.T4_Booted1.TabIndex = 15
    Me.T4_Booted1.Text = "T4"
    Me.T4_Booted1.UseVisualStyleBackColor = True
    '
    'T3_Reset1
    '
    Me.T3_Reset1.Location = New System.Drawing.Point(6, 77)
    Me.T3_Reset1.Name = "T3_Reset1"
    Me.T3_Reset1.Size = New System.Drawing.Size(50, 23)
    Me.T3_Reset1.SySimTooltip = "T3_Reset:PulseButton"
    Me.T3_Reset1.TabIndex = 14
    Me.T3_Reset1.Text = "T3"
    Me.T3_Reset1.UseVisualStyleBackColor = True
    '
    'T2_Power_Off_Detected1
    '
    Me.T2_Power_Off_Detected1.Location = New System.Drawing.Point(6, 48)
    Me.T2_Power_Off_Detected1.Name = "T2_Power_Off_Detected1"
    Me.T2_Power_Off_Detected1.Size = New System.Drawing.Size(50, 23)
    Me.T2_Power_Off_Detected1.SySimTooltip = "T2_Power_Off_Detected:PulseButton"
    Me.T2_Power_Off_Detected1.TabIndex = 13
    Me.T2_Power_Off_Detected1.Text = "T2"
    Me.T2_Power_Off_Detected1.UseVisualStyleBackColor = True
    '
    'T1_Power_On_Detected1
    '
    Me.T1_Power_On_Detected1.Location = New System.Drawing.Point(6, 19)
    Me.T1_Power_On_Detected1.Name = "T1_Power_On_Detected1"
    Me.T1_Power_On_Detected1.Size = New System.Drawing.Size(50, 23)
    Me.T1_Power_On_Detected1.SySimTooltip = "T1_Power_On_Detected:PulseButton"
    Me.T1_Power_On_Detected1.TabIndex = 12
    Me.T1_Power_On_Detected1.Text = "T1"
    Me.T1_Power_On_Detected1.UseVisualStyleBackColor = True
    '
    'SySimControlBar_SubS_P_SR1
    '
    Me.SySimControlBar_SubS_P_SR1.BackColor = System.Drawing.SystemColors.ControlText
    Me.SySimControlBar_SubS_P_SR1.Location = New System.Drawing.Point(580, 722)
    Me.SySimControlBar_SubS_P_SR1.Name = "SySimControlBar_SubS_P_SR1"
    Me.SySimControlBar_SubS_P_SR1.Size = New System.Drawing.Size(295, 42)
    Me.SySimControlBar_SubS_P_SR1.TabIndex = 2
    '
    'DT4_End_Position1
    '
    Me.DT4_End_Position1.Location = New System.Drawing.Point(367, 115)
    Me.DT4_End_Position1.Name = "DT4_End_Position1"
    Me.DT4_End_Position1.Size = New System.Drawing.Size(100, 20)
    Me.DT4_End_Position1.SySimTooltip = "DT4_End_Position:OutputTextBox"
    Me.DT4_End_Position1.TabIndex = 6
    '
    'T3_Information_No_End_Position1
    '
    Me.T3_Information_No_End_Position1.BackColor = System.Drawing.Color.DarkGray
    Me.T3_Information_No_End_Position1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T3_Information_No_End_Position1.Location = New System.Drawing.Point(28, 66)
    Me.T3_Information_No_End_Position1.Name = "T3_Information_No_End_Position1"
    Me.T3_Information_No_End_Position1.Size = New System.Drawing.Size(30, 30)
    Me.T3_Information_No_End_Position1.SySimTooltip = "T3_Information_No_End_Position:PulseIndicator"
    Me.T3_Information_No_End_Position1.TabIndex = 4
    Me.T3_Information_No_End_Position1.TabStop = False
    '
    'D10_Drive_State1
    '
    Me.D10_Drive_State1.Location = New System.Drawing.Point(361, 109)
    Me.D10_Drive_State1.Name = "D10_Drive_State1"
    Me.D10_Drive_State1.Size = New System.Drawing.Size(100, 20)
    Me.D10_Drive_State1.SySimTooltip = "D10_Drive_State:OutputTextBox"
    Me.D10_Drive_State1.TabIndex = 10
    '
    'DT2_Point_Position1
    '
    Me.DT2_Point_Position1.Location = New System.Drawing.Point(361, 24)
    Me.DT2_Point_Position1.Name = "DT2_Point_Position1"
    Me.DT2_Point_Position1.Size = New System.Drawing.Size(100, 20)
    Me.DT2_Point_Position1.SySimTooltip = "DT2_Point_Position:OutputTextBox"
    Me.DT2_Point_Position1.TabIndex = 1
    '
    'T2_Msg_Point_Position1
    '
    Me.T2_Msg_Point_Position1.BackColor = System.Drawing.Color.DarkGray
    Me.T2_Msg_Point_Position1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T2_Msg_Point_Position1.Location = New System.Drawing.Point(22, 20)
    Me.T2_Msg_Point_Position1.Name = "T2_Msg_Point_Position1"
    Me.T2_Msg_Point_Position1.Size = New System.Drawing.Size(30, 30)
    Me.T2_Msg_Point_Position1.SySimTooltip = "T2_Msg_Point_Position:PulseIndicator"
    Me.T2_Msg_Point_Position1.TabIndex = 0
    Me.T2_Msg_Point_Position1.TabStop = False
    '
    'T10_SIL_Not_Fulfilled1
    '
    Me.T10_SIL_Not_Fulfilled1.BackColor = System.Drawing.Color.DarkGray
    Me.T10_SIL_Not_Fulfilled1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    Me.T10_SIL_Not_Fulfilled1.Location = New System.Drawing.Point(361, 104)
    Me.T10_SIL_Not_Fulfilled1.Name = "T10_SIL_Not_Fulfilled1"
    Me.T10_SIL_Not_Fulfilled1.Size = New System.Drawing.Size(30, 30)
    Me.T10_SIL_Not_Fulfilled1.SySimTooltip = "T10_SIL_Not_Fulfilled:PulseIndicator"
    Me.T10_SIL_Not_Fulfilled1.TabIndex = 17
    Me.T10_SIL_Not_Fulfilled1.TabStop = False
    '
    'T3_Msg_Timeout1
    '
    '' Me.T3_Msg_Timeout1.BackColor = System.Drawing.Color.DarkGray
    '' Me.T3_Msg_Timeout1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
    '' Me.T3_Msg_Timeout1.Location = New System.Drawing.Point(22, 57)
    '' Me.T3_Msg_Timeout1.Name = "T3_Msg_Timeout1"
    '' Me.T3_Msg_Timeout1.Size = New System.Drawing.Size(30, 30)
    '' Me.T3_Msg_Timeout1.SySimTooltip = "T3_Msg_Timeout:PulsedPortStatusBox"
    '' Me.T3_Msg_Timeout1.TabIndex = 25
    '' Me.T3_Msg_Timeout1.TabStop = False
    '
    'SubS_P_SRForm
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.BackColor = System.Drawing.SystemColors.ControlText
    Me.ClientSize = New System.Drawing.Size(1484, 761)
    Me.Controls.Add(Me.TabControl2)
    Me.Controls.Add(Me.SySimControlBar_SubS_P_SR1)
    Me.Controls.Add(Me.TabControl1)
    Me.Name = "SubS_P_SRForm"
    Me.Text = "SubS_P_SR by PTC Integrity Modeler SySim"
    Me.TabPage2.ResumeLayout(False)
    Me.GroupBox22.ResumeLayout(False)
    Me.GroupBox22.PerformLayout()
    CType(Me.T15_Msg_Initialisation_Completed1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T18_Start_Status_Report1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T14_Msg_Start_Initialisation1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T12_Disconnect_SCP1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T13_Msg_PDI_Version_Check1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.GroupBox21.ResumeLayout(False)
    Me.GroupBox21.PerformLayout()
    CType(Me.T8_Cd_Initialisation_Request12, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T12_Terminate_SCP_Connection_I1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T7_Cd_PDI_Version_Check11, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T6_Establish_SCP_Connection_I1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.GroupBox10.ResumeLayout(False)
    Me.GroupBox10.PerformLayout()
    CType(Me.T21_Data_Update_Finished1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T20_Ready_For_Update_Of_Data1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T19_Validate_Data1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.TabControl2.ResumeLayout(False)
    Me.TabPage6.ResumeLayout(False)
    Me.GroupBox9.ResumeLayout(False)
    Me.GroupBox9.PerformLayout()
    CType(Me.T02_Msg_Point_Position1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.GroupBox11.ResumeLayout(False)
    Me.GroupBox11.PerformLayout()
    CType(Me.T5_Info_End_Position_Arrived1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D25_Redrive1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T12_Reset_PMs1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T07_Information_Out_Of_Sequence1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T06_Information_Trailed_Point1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T04_Information_No_End_Position1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D6_Move_Right1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D5_Move_Left1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.TabPage7.ResumeLayout(False)
    Me.TabPage4.ResumeLayout(False)
    Me.GroupBox14.ResumeLayout(False)
    Me.GroupBox14.PerformLayout()
    CType(Me.D38_0085001, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D37_0084001, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D36_0083001, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D35_0082001, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D34_0080001, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D33_0079001, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D32_0076001, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.D30_0070001, System.ComponentModel.ISupportInitialize).EndInit()
    Me.TabPage3.ResumeLayout(False)
    Me.GroupBox15.ResumeLayout(False)
    Me.GroupBox17.ResumeLayout(False)
    Me.GroupBox17.PerformLayout()
    CType(Me.PM2_Active1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.GroupBox16.ResumeLayout(False)
    Me.GroupBox16.PerformLayout()
    Me.GroupBox13.ResumeLayout(False)
    Me.GroupBox13.PerformLayout()
    Me.GroupBox12.ResumeLayout(False)
    Me.GroupBox12.PerformLayout()
    Me.TabControl1.ResumeLayout(False)
    Me.TabPage5.ResumeLayout(False)
    Me.GroupBox7.ResumeLayout(False)
    Me.GroupBox7.PerformLayout()
    Me.GroupBox2.ResumeLayout(False)
    Me.GroupBox2.PerformLayout()
    CType(Me.D20_Con_MDM_Used1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.TabPage8.ResumeLayout(False)
    Me.GroupBox20.ResumeLayout(False)
    Me.GroupBox26.ResumeLayout(False)
    Me.GroupBox26.PerformLayout()
    Me.GroupBox27.ResumeLayout(False)
    Me.GroupBox27.PerformLayout()
    CType(Me.D23_Con_Checksum_Data_Used1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.GroupBox19.ResumeLayout(False)
    Me.GroupBox25.ResumeLayout(False)
    Me.GroupBox25.PerformLayout()
    Me.GroupBox24.ResumeLayout(False)
    Me.GroupBox24.PerformLayout()
    Me.GroupBox18.ResumeLayout(False)
    Me.GroupBox18.PerformLayout()
    Me.GroupBox8.ResumeLayout(False)
    Me.GroupBox8.PerformLayout()
    CType(Me.T3_Information_No_End_Position1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T2_Msg_Point_Position1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T10_SIL_Not_Fulfilled1, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.T3_Msg_Timeout1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    
    End Sub
    Friend WithEvents SySimControlBar_SubS_P_SR1 As SySimControlBar_SubS_P_SR
    Friend WithEvents Label25 As Label
    Friend WithEvents Label24 As Label
    '' Friend WithEvents DT7_PDI_Version1 As DT7_PDI_Version
    '' Friend WithEvents T7_Cd_PDI_Version_Check1 As T7_Cd_PDI_Version_Check
    '' Friend WithEvents T8_Cd_Initialisation_Request1 As T8_Cd_Initialisation_Request
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents DT13_Result1 As DT13_Result
    Friend WithEvents DT13_Checksum_data1 As DT13_Checksum_data
    Friend WithEvents T13_Msg_PDI_Version_Check1 As T13_Msg_PDI_Version_Check
    Friend WithEvents Label31 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents T15_Msg_Initialisation_Completed1 As T15_Msg_Initialisation_Completed
    Friend WithEvents T14_Msg_Start_Initialisation1 As T14_Msg_Start_Initialisation
    Friend WithEvents Label35 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents DT2_Point_Position1 As SIMULATOR.SubS_P_SRPackage.DT2_Point_Position
    Friend WithEvents T2_Msg_Point_Position1 As SIMULATOR.SubS_P_SRPackage.T2_Msg_Point_Position
    Friend WithEvents GroupBox10 As GroupBox
    Friend WithEvents Label39 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents T20_Ready_For_Update_Of_Data1 As T20_Ready_For_Update_Of_Data
    Friend WithEvents T19_Validate_Data1 As T19_Validate_Data
    Friend WithEvents D04_Con_tmax_Point_Operation1 As SIMULATOR.SubS_P_SRPackage.D4_Con_tmax_Point_Operation
    Friend WithEvents DT01_Move_Point_Target1 As SIMULATOR.SubS_P_SRPackage.DT1_Move_Point_Target
    Friend WithEvents T01_Cmd_Move_Point1 As SIMULATOR.SubS_P_SRPackage.T1_Move_Point
    '' Friend WithEvents T8_Msg_Timeout1 As SIMULATOR.SubS_P_SRPackage.T3_OUT_Msg_Timeout
    Friend WithEvents Label50 As Label
    Friend WithEvents D10_Drive_State1 As SIMULATOR.SubS_P_SRPackage.D5_Drive_State
    Friend WithEvents DT4_End_Position1 As SIMULATOR.SubS_P_SRPackage.DT20_Position
    '' Friend WithEvents T4_Information_End_Position_Arrived1 As T05_Information_End_Position_Arrived
    Friend WithEvents T3_Information_No_End_Position1 As SIMULATOR.SubS_P_SRPackage.T4_Information_No_End_Position
    Friend WithEvents D51_F_EST_EfeS_Gen_SR_state1 As D51_F_EST_EfeS_Gen_SR_state
    Friend WithEvents T12_Disconnect_SCP1 As T12_Disconnect_SCP
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents T10_SIL_Not_Fulfilled1 As T23_SIL_Not_Fulfilled
    Friend WithEvents DT7_PDI_Version11 As DT7_PDI_Version1
    Friend WithEvents T7_Cd_PDI_Version_Check11 As T7_Cd_PDI_Version_Check1
    Friend WithEvents GroupBox21 As GroupBox
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents GroupBox11 As GroupBox
    Friend WithEvents Label84 As Label
    Friend WithEvents T12_Reset_PMs1 As T12_Reset_PMs
    '' Friend WithEvents T12_Reset_P31 As T12_Reset_P3
    Friend WithEvents Label71 As Label
    Friend WithEvents T07_Information_Out_Of_Sequence1 As SIMULATOR.SubS_P_SRPackage.T7_Information_Out_Of_Sequence
    Friend WithEvents T06_Information_Trailed_Point1 As SIMULATOR.SubS_P_SRPackage.T6_Information_Trailed_Point
    '' Friend WithEvents T05_Information_End_Position_Arrived1 As T05_Information_End_Position_Arrived
    Friend WithEvents T04_Information_No_End_Position1 As SIMULATOR.SubS_P_SRPackage.T4_Information_No_End_Position
    Friend WithEvents Label19 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents D6_Move_Right1 As D6_Move_Right
    Friend WithEvents D5_Move_Left1 As D5_Move_Left
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents Label67 As Label
    Friend WithEvents D06_Detection_State1 As SIMULATOR.SubS_P_SRPackage.D6_Detection_State
    Friend WithEvents D05_Drive_State1 As SIMULATOR.SubS_P_SRPackage.D5_Drive_State
    '' Friend WithEvents T03_Msg_Timeout1 As SIMULATOR.SubS_P_SRPackage.T3_OUT_Msg_Timeout
    Friend WithEvents T02_Msg_Point_Position1 As SIMULATOR.SubS_P_SRPackage.T2_Msg_Point_Position
    Friend WithEvents Label51 As Label
    '' Friend WithEvents T7_Sending_Status_Report_Completed1 As T7_Sending_Status_Report_Completed
    Friend WithEvents Label42 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents GroupBox22 As GroupBox
    Friend WithEvents D50_PDI_Connection_State1 As D50_PDI_Connection_State
    Friend WithEvents Label95 As Label
    Friend WithEvents D50_PDI_Connection_State_S1 As D50_PDI_Connection_State_S
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    Friend WithEvents T18_Start_Status_Report1 As T18_Start_Status_Report
    Friend WithEvents Label96 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents T8_Cd_Initialisation_Request12 As T8_Cd_Initialisation_Request1
    Friend WithEvents Label99 As Label
    Friend WithEvents Label98 As Label
    Friend WithEvents T12_Terminate_SCP_Connection_I1 As T12_Terminate_SCP_Connection_I
    Friend WithEvents T6_Establish_SCP_Connection_I1 As T6_Establish_SCP_Connection_I
    Friend WithEvents Label101 As Label
    Friend WithEvents D25_Redrive1 As D25_Redrive
    Friend WithEvents T5_Info_End_Position_Arrived1 As T5_Info_End_Position_Arrived
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents GroupBox14 As GroupBox
    Friend WithEvents Label63 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents D38_0085001 As SIMULATOR.SubS_P_SRPackage.D38_Con_008500
    Friend WithEvents D37_0084001 As SIMULATOR.SubS_P_SRPackage.D37_Con_008400
    Friend WithEvents D36_0083001 As SIMULATOR.SubS_P_SRPackage.D36_Con_008300
    Friend WithEvents D35_0082001 As SIMULATOR.SubS_P_SRPackage.D35_Con_008200
    Friend WithEvents D34_0080001 As SIMULATOR.SubS_P_SRPackage.D34_Con_008000
    Friend WithEvents D33_0079001 As SIMULATOR.SubS_P_SRPackage.D33_Con_007900
    Friend WithEvents D32_0076001 As SIMULATOR.SubS_P_SRPackage.D32_Con_007600
    Friend WithEvents D30_0070001 As SIMULATOR.SubS_P_SRPackage.D30_Con_007000
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents GroupBox15 As GroupBox
    Friend WithEvents GroupBox17 As GroupBox
    Friend WithEvents Label79 As Label
    Friend WithEvents PM2_Position_Out1 As PM2_Position_Out
    Friend WithEvents Label74 As Label
    Friend WithEvents PM2_Position1 As PM2_Position
    Friend WithEvents PM2_Active1 As PM2_Active
    Friend WithEvents Label68 As Label
    Friend WithEvents GroupBox16 As GroupBox
    Friend WithEvents Label78 As Label
    Friend WithEvents PM1_Position_Out1 As PM1_Position_Out
    Friend WithEvents Label73 As Label
    Friend WithEvents PM1_Position1 As PM1_Position
    Friend WithEvents GroupBox13 As GroupBox
    Friend WithEvents D04_Con_tmax_Point_Operation2 As SIMULATOR.SubS_P_SRPackage.D4_Con_tmax_Point_Operation
    Friend WithEvents Label43 As Label
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents DT01_Move_Point_Target2 As SIMULATOR.SubS_P_SRPackage.DT1_Move_Point_Target
    Friend WithEvents T01_Cmd_Move_Point2 As SIMULATOR.SubS_P_SRPackage.T1_Move_Point
    Friend WithEvents Label45 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents T12_Data_Installation_Successfully1 As T12_Data_Installation_Successfully
    Friend WithEvents T6_Data_Up_To_Date1 As T6_Data_Up_To_Date
    Friend WithEvents T11_Data_Invalid1 As T11_Data_Invalid
    Friend WithEvents Label9 As Label
    Friend WithEvents T7_Data_Not_Up_To_Date1 As T7_Data_Not_Up_To_Date
    Friend WithEvents T10_Data_Valid1 As T10_Data_Valid
    Friend WithEvents T8_Data1 As T8_Data
    Friend WithEvents Label8 As Label
    Friend WithEvents T9_Transmission_Complete1 As T9_Transmission_Complete
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents D4_Con_tmax_Response_MDM1 As D4_Con_tmax_Response_MDM
    Friend WithEvents D3_Con_t_Ini_Max1 As D3_Con_t_Ini_Max
    Friend WithEvents D2_Con_t_Ini_Step1 As D2_Con_t_Ini_Step
    Friend WithEvents D1_Con_t_Ini_Def_Delay1 As D1_Con_t_Ini_Def_Delay
    Friend WithEvents Lable1 As Label
    Friend WithEvents D20_Con_MDM_Used1 As D20_Con_MDM_Used
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents GroupBox20 As GroupBox
    Friend WithEvents GroupBox26 As GroupBox
    Friend WithEvents Label46 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents T20_Protocol_Error1 As T20_Protocol_Error
    Friend WithEvents Label27 As Label
    Friend WithEvents T21_Formal_Telegram_Error1 As T21_Formal_Telegram_Error
    Friend WithEvents T22_Content_Telegram_Error1 As T22_Content_Telegram_Error
    Friend WithEvents GroupBox27 As GroupBox
    Friend WithEvents Label92 As Label
    Friend WithEvents D23_Con_Checksum_Data_Used1 As D23_Con_Checksum_Data_Used
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents D4_Checksum_Data1 As D4_Checksum_Data
    Friend WithEvents D3_Con_PDI_Version1 As D3_Con_PDI_Version
    Friend WithEvents GroupBox19 As GroupBox
    Friend WithEvents GroupBox25 As GroupBox
    Friend WithEvents T22_Content_Telegram_Error_I1 As T22_Content_Telegram_Error_I
    Friend WithEvents T21_Formal_Telegram_Error_I1 As T21_Formal_Telegram_Error_I
    Friend WithEvents T20_Protocol_Error_I1 As T20_Protocol_Error_I
    Friend WithEvents Label90 As Label
    Friend WithEvents Label89 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents GroupBox24 As GroupBox
    Friend WithEvents D4_Con_Checksum_Data_I1 As D4_Con_Checksum_Data_I
    Friend WithEvents D3_Con_PDI_Version_I1 As D3_Con_PDI_Version_I
    Friend WithEvents Label87 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents D2_Con_tmax_PDI_Connection_I1 As D2_Con_tmax_PDI_Connection_I
    Friend WithEvents GroupBox18 As GroupBox
    Friend WithEvents Label91 As Label
    Friend WithEvents T10_SCP_Connection_Terminated1 As T10_SCP_Connection_Terminated
    Friend WithEvents T5_SCP_Connection1 As T5_SCP_Connection
    Friend WithEvents Label23 As Label
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents T7_Invalid_Or_Missing_Basic_Data1 As T7_Invalid_Or_Missing_Basic_Data
    Friend WithEvents T4_Booted1 As T4_Booted
    Friend WithEvents T3_Reset1 As T3_Reset
    Friend WithEvents T2_Power_Off_Detected1 As T2_Power_Off_Detected
    Friend WithEvents T1_Power_On_Detected1 As T1_Power_On_Detected
    Friend WithEvents Label69 As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents D44_Con_tmax_Booting1 As D44_Con_tmax_Booting
    Friend WithEvents Label47 As Label
    Friend WithEvents DT20_Position1 As DT20_Position
    Friend WithEvents T21_Data_Update_Finished1 As T21_Data_Update_Finished
    Friend WithEvents T5_SIL_Not_Fulfilled1 As T5_SIL_Not_Fulfilled
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents T3_Msg_Timeout1 As T3_Msg_Timeout
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    '' Friend WithEvents D5_Con_tmax_DataTransmission1 As D5_Con_tmax_DataTransmission
    
    ' ## Designer End 
    
    ' ## DesignerHistory [68b91994-3af0-42ba-a5b4-932ddb0cf7e9] 
    ' SIMULATOR.SubS_P_SRPackage.D33_Con_007900|16ca70af-68ad-4354-9b8b-e1d3d4cd6e9a
    ' SIMULATOR.SubS_P_SRPackage.D41_Con_310900|262236cc-bb25-4ddb-aa60-93f91692af47
    ' SIMULATOR.SubS_P_SRPackage.D36_Con_008300|39e192f5-a10f-49ee-bdfc-4d13afb419da
    ' SIMULATOR.SubS_P_SRPackage.D30_Con_007000|489527f8-8507-4c2d-b7d7-3161e341ce9a
    ' SIMULATOR.SubS_P_SRPackage.D39_Con_008700|4a607d26-380a-4494-938b-912390c22d34
    ' SIMULATOR.SubS_P_SRPackage.D31_Con_007400|5c05e515-a754-442e-8203-f3e4198184a1
    ' SIMULATOR.SubS_P_SRPackage.D37_Con_008400|70cb123d-464e-47ed-b57d-67047dd0e93d
    ' SIMULATOR.SubS_P_SRPackage.D34_Con_008000|971e1249-f1eb-43e3-bed6-24cc0c1ea23c
    ' SIMULATOR.SubS_P_SRPackage.D35_Con_008200|b57ad268-f19d-4d12-aaac-4e1b6b109e96
    ' SIMULATOR.SubS_P_SRPackage.D32_Con_007600|c3738771-9284-4ca1-a4be-c3707aa8c19d
    ' SIMULATOR.SubS_P_SRPackage.D40_Con_008800|cc474bdb-cc6c-4494-b5d6-87f301f4b901
    ' SIMULATOR.SubS_P_SRPackage.D38_Con_008500|eb6e1218-adbb-4e0d-9e59-761b03c8d44f
    ' SIMULATOR.SubS_P_SRPackage.CF_SCI_EfeS_Sec_SR|57393a87-7693-43f1-bd89-77ad42344272
    ' SIMULATOR.SubS_P_SRPackage.CF_SCI_P_SR|c1ca24c2-c731-4e72-b85c-41dffda77dc9
    ' SIMULATOR.SubS_P_SRPackage.CF_SCI_EfeS_Sec_SR|454b303f-7824-43bf-89ab-2bce12ad9ea1
    ' SIMULATOR.SubS_P_SRPackage.CF_SCI_EfeS_Sec_SR|5413f469-faf3-4dc6-9bb8-6d31253cbd40
    ' SIMULATOR.SubS_P_SRPackage.CF_SCI_P_SR|83db39d0-23d9-40c7-a878-9256a8d268e4
    ' SIMULATOR.SubS_P_SRPackage.CF_SMI_EfeS_SR|a295b985-b7cc-4d95-9eba-2347505aecbe
    ' SIMULATOR.SubS_P_SRPackage.CF_EST_EfeS_SR|cb4e2275-a7a9-4b50-bb81-c1eb5a318d5c
    ' SIMULATOR.SubS_P_SRPackage.T3_OUT_Msg_Timeout|6facde13-db44-425a-9940-0d4f81905d52
    ' SIMULATOR.SubS_P_SRPackage.T3_OUT_Msg_Timeout|fbf8ca67-602e-4ff5-b4f7-9006c3e7230d
    ' SIMULATOR.SubS_P_SRPackage.T3_Msg_Timeout|fbf8ca67-602e-4ff5-b4f7-9006c3e7230d
    ' SIMULATOR.SubS_P_SRPackage.DT1_Move_Point_Target|2c94aa31-7f56-466b-96ef-7dc0b02fc596
    ' SIMULATOR.SubS_P_SRPackage.T2_OUT_Point_Position|11e72911-4654-458e-8b78-712d89204679
    ' SIMULATOR.SubS_P_SRPackage.T1_OUT_Move_Point|1b365fd2-9c75-4d10-b058-e32fbfc299a3
    ' SIMULATOR.SubS_P_SRPackage.DT1_OUT_Move_Point_Target|3235f2c6-a495-429f-8fd9-3b73274b9a8b
    ' SIMULATOR.SubS_P_SRPackage.DT2_OUT_Point_Position|942bb28b-759c-4e2c-b0a5-993bfee00e4f
    ' SIMULATOR.SubS_P_SRPackage.F_SCI_P|9daea24a-bab2-4435-bfc3-a3289cc4bdfc
    ' SIMULATOR.SubS_P_SRPackage.T1_Move_Point|ad45c170-de5d-4dc3-afb4-83a7c3a3c4fd
    ' SIMULATOR.SubS_P_SRPackage.S_SCI_P|ff41514d-09a5-4f9b-9bff-c6e87e019569
    ' SIMULATOR.SubS_P_SRPackage.T5_SIL_Not_Fulfilled|1c174014-d085-485b-acea-81046b3d3d35
    ' SIMULATOR.SubS_P_SRPackage.D5_Drive_State|0036427f-8115-4897-8a48-df30569300a4
    ' SIMULATOR.SubS_P_SRPackage.D6_Detection_State|07fc1412-f0f6-4d75-9cad-af10141818f4
    ' SIMULATOR.SubS_P_SRPackage.T21_Data_Update_Finished|353beb12-a298-4ecc-9cd5-9726cbdc894f
    ' SIMULATOR.SubS_P_SRPackage.D4_Con_tmax_Point_Operation|d0b98b71-552e-400b-88ee-d3bba4216f54
    ' SIMULATOR.SubS_P_SRPackage.DT20_Position|05b2e605-bbee-4d8a-9b82-8e4dc32d2056
    ' SIMULATOR.SubS_P_SRPackage.T2_Msg_Point_Position|1828683d-ba24-46f4-97bf-02265a1da617
    ' SIMULATOR.SubS_P_SRPackage.T7_Information_Out_Of_Sequence|6e4b0b69-f4b3-46ff-9545-b0809060a3f1
    ' SIMULATOR.SubS_P_SRPackage.DT2_Point_Position|78689fd8-0b2e-4bd4-ab99-ee763b9adc21
    ' SIMULATOR.SubS_P_SRPackage.T1_Cmd_Move_Point|ad45c170-de5d-4dc3-afb4-83a7c3a3c4fd
    ' SIMULATOR.SubS_P_SRPackage.T6_Information_Trailed_Point|bdcebe1a-f031-4c94-90fa-a8d930da0076
    ' SIMULATOR.SubS_P_SRPackage.T3_Msg_Timeout|ea5b82db-236d-4c13-a513-2323168f233c
    ' SIMULATOR.SubS_P_SRPackage.D05_Drive_State|0036427f-8115-4897-8a48-df30569300a4
    ' SIMULATOR.SubS_P_SRPackage.DT05_Position|05b2e605-bbee-4d8a-9b82-8e4dc32d2056
    ' SIMULATOR.SubS_P_SRPackage.D06_Detection_State|07fc1412-f0f6-4d75-9cad-af10141818f4
    ' SIMULATOR.SubS_P_SRPackage.T3_Reset|0b021f03-950b-4b0c-83b3-4f1b76c00656
    ' SIMULATOR.SubS_P_SRPackage.D2_Con_t_Ini_Step|14cf4c52-cbbe-4704-a26d-f696c563f1b5
    ' SIMULATOR.SubS_P_SRPackage.D33_007900|16ca70af-68ad-4354-9b8b-e1d3d4cd6e9a
    ' SIMULATOR.SubS_P_SRPackage.T02_Msg_Point_Position|1828683d-ba24-46f4-97bf-02265a1da617
    ' SIMULATOR.SubS_P_SRPackage.PM1_Position|18f59227-b672-4ae3-9de3-6af56053cb0a
    ' SIMULATOR.SubS_P_SRPackage.SCI_Sec|1afedb6d-ed4a-4e8b-bf09-3163061920ed
    ' SIMULATOR.SubS_P_SRPackage.D4_Checksum_Data|1fc630db-0ac8-4220-ae4e-9bc90575bf28
    ' SIMULATOR.SubS_P_SRPackage.T14_Msg_Start_Initialisation|209d65bf-3811-4886-964a-ab472decc3b0
    ' SIMULATOR.SubS_P_SRPackage.D4_Con_Checksum_Data_I|2379f88b-0b28-401b-aa43-9f856cba0fda
    ' SIMULATOR.SubS_P_SRPackage.PM2_Position|2491f9ec-256a-4f9e-a8ae-b8cf622b748c
    ' SIMULATOR.SubS_P_SRPackage.T5_SCP_Connection|24a5ea94-c71a-4f8b-af06-2b5cbafedfe8
    ' SIMULATOR.SubS_P_SRPackage.D41_310900|262236cc-bb25-4ddb-aa60-93f91692af47
    ' SIMULATOR.SubS_P_SRPackage.T18_Start_Status_Report|29a7c6c1-b520-4c4a-be8b-e0107f6f5857
    ' SIMULATOR.SubS_P_SRPackage.DT01_Move_Point_Target|2c94aa31-7f56-466b-96ef-7dc0b02fc596
    ' SIMULATOR.SubS_P_SRPackage.T6_Data_Up_To_Date|304e3378-c45e-4b1b-8ec6-3334fcba169f
    ' SIMULATOR.SubS_P_SRPackage.PM1_Position_Out|352cb25d-5585-4977-bbf8-4efffa09fd55
    ' SIMULATOR.SubS_P_SRPackage.D50_PDI_Connection_State_S|3539c5f8-e799-4356-a325-c2fd621c54b6
    ' SIMULATOR.SubS_P_SRPackage.D36_008300|39e192f5-a10f-49ee-bdfc-4d13afb419da
    ' SIMULATOR.SubS_P_SRPackage.T20_Ready_For_Update_Of_Data|3d36f945-f83e-458c-b6de-6085da7e2b7f
    ' SIMULATOR.SubS_P_SRPackage.T23_Sending_Status_Report_Completed|3e265343-f91e-495b-b7e0-97eb49e641e4
    ' SIMULATOR.SubS_P_SRPackage.D30_007000|489527f8-8507-4c2d-b7d7-3161e341ce9a
    ' SIMULATOR.SubS_P_SRPackage.D39_008700|4a607d26-380a-4494-938b-912390c22d34
    ' SIMULATOR.SubS_P_SRPackage.T8_Data|4dc94e5d-01d2-41f7-95e6-4f02d3a77b27
    ' SIMULATOR.SubS_P_SRPackage.D3_Con_PDI_Version|4ea6d1ea-9d8b-410b-b17e-7b63f13cdaa8
    ' SIMULATOR.SubS_P_SRPackage.D50_PDI_Connection_State|55fd4ffd-4a72-49ec-bc60-0d4f2275dce3
    ' SIMULATOR.SubS_P_SRPackage.D44_Con_tmax_Booting|564f2690-9692-46d4-aabd-7cfcff51b25d
    ' SIMULATOR.SubS_P_SRPackage.D31_007400|5c05e515-a754-442e-8203-f3e4198184a1
    ' SIMULATOR.SubS_P_SRPackage.T23_SIL_Not_Fulfilled|5cef8e21-d4f8-4121-b642-8c9d2d99defa
    ' SIMULATOR.SubS_P_SRPackage.D51_F_EST_EfeS_Gen_SR_state|5e06e036-eacf-4dfd-be9f-3ad8fe52f36e
    ' SIMULATOR.SubS_P_SRPackage.T7_Cd_PDI_Version_Check1|5e86978e-d4da-4b50-b5a6-cf3e07b10dc5
    ' SIMULATOR.SubS_P_SRPackage.D2_Con_tmax_PDI_Connection_I|60ecadee-d2cf-4042-b23f-0001357719d4
    ' SIMULATOR.SubS_P_SRPackage.D20_Con_MDM_Used|6498a73d-8b3f-40fe-8e9c-86ed16788e80
    ' SIMULATOR.SubS_P_SRPackage.D25_Redrive|69b2c0e0-1e65-40d3-aca7-46871ad43b9e
    ' SIMULATOR.SubS_P_SRPackage.T07_Information_Out_Of_Sequence|6e4b0b69-f4b3-46ff-9545-b0809060a3f1
    ' SIMULATOR.SubS_P_SRPackage.D37_008400|70cb123d-464e-47ed-b57d-67047dd0e93d
    ' SIMULATOR.SubS_P_SRPackage.EST|7109ffb7-dca5-4744-ab06-9572d19cd0ad
    ' SIMULATOR.SubS_P_SRPackage.T7_Data_Not_Up_To_Date|71e05544-f3f2-4402-af38-74e1b43ce04b
    ' SIMULATOR.SubS_P_SRPackage.T9_Transmission_Complete|73538b81-1e06-42a5-99a9-832ccc9759f2
    ' SIMULATOR.SubS_P_SRPackage.P3|7760ac4b-7edf-4e5a-b534-04dc3cfa02ee
    ' SIMULATOR.SubS_P_SRPackage.DT02_Point_Position|78689fd8-0b2e-4bd4-ab99-ee763b9adc21
    ' SIMULATOR.SubS_P_SRPackage.D4_Con_tmax_Response_MDM|7ab9502a-30ab-4089-8064-d932e99d6968
    ' SIMULATOR.SubS_P_SRPackage.T11_Data_Invalid|7cfd2128-a3c8-43f9-9e75-95e7d2f1acc2
    ' SIMULATOR.SubS_P_SRPackage.D6_Move_Right|80e97a04-de95-4aac-8c14-7e6604bda840
    ' SIMULATOR.SubS_P_SRPackage.T10_Data_Valid|810467e0-cfc9-42b1-af39-65d1daa99b17
    ' SIMULATOR.SubS_P_SRPackage.DT7_PDI_Version1|8257330e-f6e1-4920-86af-6a0e889d7343
    ' SIMULATOR.SubS_P_SRPackage.D5_Con_tmax_DataTransmission|82ab18f1-3819-41cd-a88b-55773899402c
    ' SIMULATOR.SubS_P_SRPackage.T22_Content_Telegram_Error|83566a88-f150-4750-999c-5950beeeba14
    ' SIMULATOR.SubS_P_SRPackage.T4_Information_No_End_Position|8451a16e-071c-4cf5-9539-63f68f5ddb12
    ' SIMULATOR.SubS_P_SRPackage.D5_Move_Left|85ef335c-def9-460c-ac43-75a350c6932e
    ' SIMULATOR.SubS_P_SRPackage.T8_Cd_Initialisation_Request1|887fed92-3713-471f-9e7e-e65ba88cdb2a
    ' SIMULATOR.SubS_P_SRPackage.SMI|8b9332e7-835c-462f-8f90-f91cfdf2e3da
    ' SIMULATOR.SubS_P_SRPackage.DT13_Checksum_data|8ecf908a-dc6d-49cd-9485-9bae630d0e71
    ' SIMULATOR.SubS_P_SRPackage.T1_Power_On_Detected|90000bdd-2b7c-44b3-bf44-817f4c4e3817
    ' SIMULATOR.SubS_P_SRPackage.T12_Data_Installation_Successfully|911c7297-e2d4-4aee-87fa-ec03a080e640
    ' SIMULATOR.SubS_P_SRPackage.D1_Con_t_Ini_Def_Delay|9281f283-4b37-4ff7-9974-0747d7046bfc
    ' SIMULATOR.SubS_P_SRPackage.D34_008000|971e1249-f1eb-43e3-bed6-24cc0c1ea23c
    ' SIMULATOR.SubS_P_SRPackage.T12_Disconnect_SCP|9768e9fe-798f-4119-8f94-2fe821be3776
    ' SIMULATOR.SubS_P_SRPackage.T15_Msg_Initialisation_Completed|9cbde6b6-cfca-417f-9743-d15b67e35ee9
    ' SIMULATOR.SubS_P_SRPackage.SCI_P|9daea24a-bab2-4435-bfc3-a3289cc4bdfc
    ' SIMULATOR.SubS_P_SRPackage.T6_Establish_SCP_Connection_I|a040469b-36e7-4499-8f65-c24586b85cd5
    ' SIMULATOR.SubS_P_SRPackage.T20_Protocol_Error|a0b84623-ecbb-4b8b-ad51-d4f12e3bb871
    ' SIMULATOR.SubS_P_SRPackage.T12_Terminate_SCP_Connection_I|a1142fab-3fae-4324-b4fd-7bb9d916cb8c
    ' SIMULATOR.SubS_P_SRPackage.PM2_Active|a27f57c1-c17f-433d-aef9-ddcb4e21a072
    ' SIMULATOR.SubS_P_SRPackage.T2_Power_Off_Detected|a3b81d63-39a8-4cae-b9cf-be61865de3a9
    ' SIMULATOR.SubS_P_SRPackage.PM2|a5aa54e6-9baf-4a49-a96c-e52600eb5f62
    ' SIMULATOR.SubS_P_SRPackage.T5_Info_End_Position_Arrived|a7ba83e3-66bc-44d2-8f36-35df7c9c6d19
    ' SIMULATOR.SubS_P_SRPackage.PM2_Position_Out|ac3a360a-33f3-40f2-8673-478c2f3caea1
    ' SIMULATOR.SubS_P_SRPackage.T01_Cmd_Move_Point|ad45c170-de5d-4dc3-afb4-83a7c3a3c4fd
    ' SIMULATOR.SubS_P_SRPackage.T4_Booted|b349ecd7-922e-43a4-85a6-8cab69d5c09f
    ' SIMULATOR.SubS_P_SRPackage.D35_008200|b57ad268-f19d-4d12-aaac-4e1b6b109e96
    ' SIMULATOR.SubS_P_SRPackage.T06_Information_Trailed_Point|bdcebe1a-f031-4c94-90fa-a8d930da0076
    ' SIMULATOR.SubS_P_SRPackage.D32_007600|c3738771-9284-4ca1-a4be-c3707aa8c19d
    ' SIMULATOR.SubS_P_SRPackage.T20_Protocol_Error_I|c73ec70f-5e5e-43d2-b63c-14bd58c5f99d
    ' SIMULATOR.SubS_P_SRPackage.D40_008800|cc474bdb-cc6c-4494-b5d6-87f301f4b901
    ' SIMULATOR.SubS_P_SRPackage.SCI_Prim|cfc1d7fe-dcfe-41f6-9ce2-cbd26ffeb11b
    ' SIMULATOR.SubS_P_SRPackage.D04_Con_tmax_Point_Operation|d0b98b71-552e-400b-88ee-d3bba4216f54
    ' SIMULATOR.SubS_P_SRPackage.T21_Formal_Telegram_Error_I|d0e320e1-48ce-4188-9a2e-cbfe7359107c
    ' SIMULATOR.SubS_P_SRPackage.D3_Con_t_Ini_Max|d8fa4f06-2733-4bf7-850b-3a2a004368e1
    ' SIMULATOR.SubS_P_SRPackage.T7_Invalid_Or_Missing_Basic_Data|e3fe0c69-1f86-45dc-9f3b-d65250403a95
    ' SIMULATOR.SubS_P_SRPackage.T13_Msg_PDI_Version_Check|e4728dbd-4b1d-4123-bd76-ac91b855e83a
    ' SIMULATOR.SubS_P_SRPackage.DT13_Result|e6511e01-85a2-4061-9955-631fc735fea3
    ' SIMULATOR.SubS_P_SRPackage.T03_Msg_Timeout|ea5b82db-236d-4c13-a513-2323168f233c
    ' SIMULATOR.SubS_P_SRPackage.T10_SCP_Connection_Terminated|ead8e52e-d36c-4b34-8c4b-c66acf012c7a
    ' SIMULATOR.SubS_P_SRPackage.D3_Con_PDI_Version_I|eb4b7241-e934-4a38-97b2-31a48a3f91d3
    ' SIMULATOR.SubS_P_SRPackage.D38_008500|eb6e1218-adbb-4e0d-9e59-761b03c8d44f
    ' SIMULATOR.SubS_P_SRPackage.T22_Content_Telegram_Error_I|f4275289-3681-4e13-8620-e43033ff088c
    ' SIMULATOR.SubS_P_SRPackage.T19_Validate_Data|f7087371-5395-45cd-8eaf-76c3277c9625
    ' SIMULATOR.SubS_P_SRPackage.D23_Con_Checksum_Data_Used|f809f7e0-73dc-4aeb-b24f-2b93ade55b4e
    ' SIMULATOR.SubS_P_SRPackage.PM1|f8cd9e32-9327-46f0-a011-4a0bec4c3932
    ' SIMULATOR.SubS_P_SRPackage.T21_Formal_Telegram_Error|fd23c4bb-381a-46bc-9a6f-412d2dd5d0b4
    ' SIMULATOR.SubS_P_SRPackage.T12_Reset_PMs|ff362466-c27d-4576-8716-51eceef4c287
    ' SIMULATOR.SubS_P_SRPackage.SySimControlBar_SubS_P_SR|68b91994-3af0-42ba-a5b4-932ddb0cf7e9
    ' Used control history
    
    ' ## DesignerHistory End 
  End Class
End Namespace
