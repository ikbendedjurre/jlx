Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.BoolIndicator
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class BoolIndicator : Inherits PictureBox
    Private D5_Move_LeftAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D5_Move_Left", 1, 1)
    Private D6_Move_RightAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D6_Move_Right", 1, 1)
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Protected inp As OInputPort(Of Boolean)
    Public Sub updateInputValues(ByVal Ph As OPhase) Handles SimCore.OnReadInputs
      ' ## VBOperationBody [8559349e-99fe-4d1c-9ae4-e6b2563154a5] 
      If inp.GetLatchedValue() = True Then
                Me.BackColor = Color.Orange
            Else
                Me.BackColor = Color.DarkGray
            End If
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub initialise(ByRef Rejections As Integer, ByVal ErrList As OErrorList) Handles SimCore.OnReadyToStart
      ' ## VBOperationBody [4c091f19-ed58-4da1-b71a-e428d8bf0cdc] 
      Me.BackColor = Color.DarkGray
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub New()
      ' ## VBOperationBody [1d871493-f8f7-45ac-bf9a-e3a80414c854] 
      Me.BackColor = Color.DarkGray
      Me.BorderStyle = BorderStyle.FixedSingle
      Me.Height = 30
      Me.Width = 30
      ' ## VBOperationBody End 
    End Sub
    
  End Class
End Namespace
