Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.InputIntegerBox
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class InputIntegerBox : Inherits TextBox
    Protected outp As OOutputPort(Of Integer)
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Public Sub send(ByVal Ph As OPhase) Handles SimCore.OnWriteOutputs
      ' ## VBOperationBody [16d126e5-b91e-446f-8da6-d26a3f74b290] 
            outp.SetValue(Integer.Parse(Me.Text))
      ' ## VBOperationBody End 
    End Sub
    
  End Class
End Namespace
