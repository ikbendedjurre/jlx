Option Explicit On
Imports SySimFWK, PredefinedControls
Imports SimSupport.SimPrimitives, SimSupport.SimPrimitives.NotifyEnum, SimSupport

Namespace EULYNX_Profile.Functional_requirements_specification.EULYNX_field_element_Subsystem.General_structure
End Namespace
