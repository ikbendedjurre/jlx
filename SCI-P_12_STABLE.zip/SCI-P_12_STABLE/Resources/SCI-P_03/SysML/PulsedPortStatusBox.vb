Option Explicit On
Imports SySimFWK, PredefinedControls
Imports SimSupport.SimPrimitives, SimSupport.SimPrimitives.NotifyEnum, SimSupport

Namespace EULYNX_Profile.Controls.PulsedPortStatusBox
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class PulsedPortStatusBox : Inherits PictureBox : Implements SMSupport.SMQueued 
    Protected Class PulsedPortStatusBoxSMQueue : Inherits SMSupport.SMQueue
      Public Overrides Sub DispatchOne(ByVal Target As SMSupport.SMQueued, ByVal Msg As SMSupport.SMMessage)
        Dim TheTarget As PulsedPortStatusBox = Target
        TheTarget.Sender = Msg.GetSender()
        Select Case Msg.GetId()
        End Select
        
      End Sub
      
    End Class
    Public Shadows Class TypeConverter : Inherits SMSupport.TypeConverterBase
    End Class
    Public Enum RtsPulsedPortStatusBox_States
      RtsPulsedPortStatusBox_States_an
      RtsPulsedPortStatusBox_States_aus
      RtsPulsedPortStatusBox_States_NotIn_PulsedPortStatusBox
    End Enum
    ' \ART_SMG :: Created for state : PulsedPortStatusBox
    Private RtsCurrent_PulsedPortStatusBox As PulsedPortStatusBox.RtsPulsedPortStatusBox_States
    ' \ART_SMG :: Created for state : an
    Private RtsAttan_Timer1 As SMSupport.RtsTimer
    ' \ART_SMG :: Always Created
    Private RtsBusy As SMSupport.RtsSemaphore
    Private ChgFlgLast1 As Boolean
    Private ChgFlg1 As Boolean
    Private Const TickDivider As Single = 0.050
    Private CurrentTime As SMSupport.Time
    Private OperatedStates As String = ""
    Private SMStarted As Boolean
    Protected Shadows Sender As Object
    Private TheQueue As PulsedPortStatusBoxSMQueue = New PulsedPortStatusBoxSMQueue
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Protected inp As OInputPort(Of Data_Types.PulsedIn)
    Public Sub switchOn()
      ' ## VBOperationBody [55cd4106-e5b0-433f-b5be-88e0b4594c5e] 
      Me.BackColor = Color.Orange
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub switchOff()
      ' ## VBOperationBody [16acecce-0c7e-45f2-b8ed-cd140480a51c] 
      Me.BackColor = Color.DarkGray
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub New()
      ' ## VBOperationBody [9cc5a820-db8a-49aa-8205-70002e981f40] 
      Me.BackColor = Color.DarkGray
      Me.BorderStyle = BorderStyle.FixedSingle
      Me.Height = 30
      Me.Width = 30
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub initialise(ByRef Rejections As Integer, ByVal ErrList As OErrorList) Handles SimCore.OnReadyToStart
      ' ## VBOperationBody [9df4281f-19bf-4de7-9ba5-8d0e01f6580a] 
      Me.BackColor = Color.DarkGray
      ' ## VBOperationBody End 
    End Sub
    
    ' \ART_SMG :: Created for state : an
    ' assume inp: a SySimInputPort;
    ' pInstance.Rtsan_Timer1();
    Private Shared Sub Rtsan_Timer1_CallBack(ByRef pInstance As PulsedPortStatusBox)
      pInstance.Rtsan_Timer1()
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' assume RtsCurrent_PulsedPortStatusBox: on object;
    ' assume RtsAttan_Timer1: on object;
    ' declare ThisState : String;
    ' /* #REF121# */
    ' if /* #REF121c# */ This.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States{enum_datatype}.RtsPulsedPortStatusBox_States_aus then
    ' /* #REF123# */
    ' 	/* c08a2b9e-cbf1-46c6-8b13-512936573dca aus */
    '   ThisState := "c08a2b9e-cbf1-46c6-8b13-512936573dca";
    ' 	if /* #REF2001# */ SenseTrigger(ChgFlg1, ChangeEventsActive, ThisState) then/* #REF124# */
    ' 	/* #REF125# */
    ' 		/* #REF7004# */
    ' 		/* #REF7001# */
    ' 		/* #REF7002# */
    ' 		/* #REF7002B#  RtsExit_aus */
    ' 		/* standard */
    ' 		This.RtsExit_aus();/* #REF1596# */
    ' 		// Simulation support : Notification function calls for transition/* #REF1598# */
    ' 		RtsNotify(This,TRANSITION,"975cfee1-1f2e-4011-859c-5c9533d2526d",0,NullString);/* #REF1599# */
    ' 		
    ' 		/*##STRT 2ac6aa3d-c56a-45ea-bf40-7e84ed5fad22 */  switchOn (); nullstat;/*##END 2ac6aa3d-c56a-45ea-bf40-7e84ed5fad22 */ /* #REF1546# */
    ' 		This.RtsEnter_an();/* #REF1590# */
    ' 		RetValue := true; /* #REF129# */
    ' 		return;/* #REF130# */
    ' 	End If/* #REF131# */
    ' End If/* #REF121# */
    ' if /* #REF121c# */ This.RtsCurrent_PulsedPortStatusBox =  /* #REF121d# */ RtsPulsedPortStatusBox_States{enum_datatype}.RtsPulsedPortStatusBox_States_NotIn_PulsedPortStatusBox then
    ' /* #REF123# */
    ' 	/* 6a300248-7e8b-4d8a-9706-0fb1fce67767 Initial */
    '   ThisState := "6a300248-7e8b-4d8a-9706-0fb1fce67767";
    ' 	// Simulation support : Notification function calls for Entry and Exit of Initial state/* #REF126# */
    ' 	RtsNotify(This,SENTER,"6a300248-7e8b-4d8a-9706-0fb1fce67767",0,NullString);/* #REF127# */
    ' 	RtsNotify(This,SEXIT,"6a300248-7e8b-4d8a-9706-0fb1fce67767",0,NullString);/* #REF128# */
    ' 	
    ' 	/* #REF7004# */
    ' 	/* #REF7001# */
    ' 	/* #REF7002# */
    ' 	/* #REF7002B#  RtsExit_Initial */
    ' 	/* standard */
    ' 	// Simulation support : Notification function calls for transition/* #REF1598# */
    ' 	RtsNotify(This,TRANSITION,"6c30cd66-3609-473f-8943-26a73c90ca40",0,NullString);/* #REF1599# */
    ' 	
    ' 	/*##STRT f005eea8-b843-44a0-b328-cb5826d69c8e */  nullstat;/*##END f005eea8-b843-44a0-b328-cb5826d69c8e */ /* #REF1546# */
    ' 	This.RtsEnter_aus();/* #REF1590# */
    ' 	RetValue := true; /* #REF129# */
    ' 	return;/* #REF130# */
    ' End If/* #REF122# */
    ' RetValue := false;
    ' return;
    Private Sub RtsRunToCompletion(ByRef RetValue As Boolean, Optional ByVal ChangeEventsActive As Boolean = False)
      Dim ThisState As String = Nothing
      If Me.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States.RtsPulsedPortStatusBox_States_aus Then
        ThisState = "c08a2b9e-cbf1-46c6-8b13-512936573dca"
        If SenseTrigger(ChgFlg1, ChangeEventsActive, ThisState) Then
          Me.RtsExit_aus()
          'Simulation support : Notification function calls for transition/* #REF1598# */
          RtsNotify(Me, TRANSITION, "975cfee1-1f2e-4011-859c-5c9533d2526d", 0, NullString)
          switchOn()
          Me.RtsEnter_an()
          RetValue = True
          Return
        End If
      End If
      If Me.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States.RtsPulsedPortStatusBox_States_NotIn_PulsedPortStatusBox Then
        ThisState = "6a300248-7e8b-4d8a-9706-0fb1fce67767"
        'Simulation support : Notification function calls for Entry and Exit of Initial state/* #REF126# */
        RtsNotify(Me, SENTER, "6a300248-7e8b-4d8a-9706-0fb1fce67767", 0, NullString)
        RtsNotify(Me, SEXIT, "6a300248-7e8b-4d8a-9706-0fb1fce67767", 0, NullString)
        'Simulation support : Notification function calls for transition/* #REF1598# */
        RtsNotify(Me, TRANSITION, "6c30cd66-3609-473f-8943-26a73c90ca40", 0, NullString)
        Me.RtsEnter_aus()
        RetValue = True
        Return
      End If
      RetValue = False
      Return
    End Sub
    
    ' \ART_SMG :: Constructor
    ' assume inp: a SySimInputPort;
    ' SimSetModelId("df7d62d6-d1cb-43e3-9dea-156304063f85");/* #REF1559# */
    ' SimInitialize();/* #REF1560# */
    ' CurrentTime := New SMSupport.Time;/* #REF1560# */
    ' RtsNotifySynchronous(This, CREATE, "0b3d8144-e827-4b9b-8c59-b1c0e10f3dcb", 0, NullString, addressof(RtsInjectEvent), addressof(RtsGetAttributeValue), addressof(RtsSetAttributeValue));/* #REF1561# */
    ' SMSupport.RtsBase.RtsCreateSemaphore(This.RtsBusy);/* #REF1563# */
    ' SMSupport.RtsBase.RtsLock(This.RtsBusy);/* #REF1564# */
    ' SMSupport.RtsBase.RtsCreateTimer(This.RtsAttan_Timer1);// DoState Timer Placeholder
    ' /* #REF1565# */
    ' 
    ' // Initialising State Vectors to NotIn
    ' This.RtsCurrent_PulsedPortStatusBox := RtsPulsedPortStatusBox_States{enum_datatype}.RtsPulsedPortStatusBox_States_NotIn_PulsedPortStatusBox;/* #REF1566# */
    ' SMSupport.RtsBase.RtsUnlock(This.RtsBusy);
    ' 
    Public Shadows Sub SMGInitialize(Optional ByVal SingleStep As Boolean = False)
      SimSetModelId("df7d62d6-d1cb-43e3-9dea-156304063f85")
      SimInitialize()
      CurrentTime = New SMSupport.Time
      RtsNotifySynchronous(Me, CREATE, "0b3d8144-e827-4b9b-8c59-b1c0e10f3dcb", 0, NullString, AddressOf RtsInjectEvent, AddressOf RtsGetAttributeValue, AddressOf RtsSetAttributeValue)
      SMSupport.RtsBase.RtsCreateSemaphore(Me.RtsBusy)
      SMSupport.RtsBase.RtsLock(Me.RtsBusy)
      SMSupport.RtsBase.RtsCreateTimer(Me.RtsAttan_Timer1)
      'DoState Timer Placeholder
      'Initialising State Vectors to NotIn
      Me.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States.RtsPulsedPortStatusBox_States_NotIn_PulsedPortStatusBox
      SMSupport.RtsBase.RtsUnlock(Me.RtsBusy)
    End Sub
    
    ' \ART_SMG :: Destructor
    ' assume inp: a SySimInputPort;
    ' /* #REF1617# */
    ' RtsUnregister(This);
    Public Shadows Sub SMGTerminate()
      RtsUnregister(Me)
    End Sub
    
    ' \ART_SMG :: Created for state : an
    ' assume inp: a SySimInputPort;
    ' if not OperatedStates.Contains ("7a3b862c-497a-441e-a59e-bf6dd20a4fb2|") then
    '   OperatedStates := OperatedStates + "7a3b862c-497a-441e-a59e-bf6dd20a4fb2|";
    ' end if
    ' // Simulation support : Notification function call for entering state : an ///* #REF520# */
    ' RtsNotify(This,SENTER,"7a3b862c-497a-441e-a59e-bf6dd20a4fb2",0,NullString);
    ' 
    ' SimCore.EnterState("7a3b862c-497a-441e-a59e-bf6dd20a4fb2","an");
    ' 
    ' This.RtsCurrent_PulsedPortStatusBox := RtsPulsedPortStatusBox_States{enum_datatype}.RtsPulsedPortStatusBox_States_an;/* #REF521# */
    ' /* #REF523# */
    ' // Start Timers/* #REF525# */
    ' SMSupport.RtsBase.RtsStartTimer(This.RtsAttan_Timer1, /*##STRT ef6bec50-b8b6-474e-8f7a-a12ffab6c508 */ 1000/*##END ef6bec50-b8b6-474e-8f7a-a12ffab6c508 */ , CurrentTime);
    Private Sub RtsEnter_an()
      If not OperatedStates.Contains("7a3b862c-497a-441e-a59e-bf6dd20a4fb2|") Then
        OperatedStates = OperatedStates + "7a3b862c-497a-441e-a59e-bf6dd20a4fb2|"
      End If
      'Simulation support : Notification function call for entering state : an ///* #REF520# */
      RtsNotify(Me, SENTER, "7a3b862c-497a-441e-a59e-bf6dd20a4fb2", 0, NullString)
      SimCore.EnterState("7a3b862c-497a-441e-a59e-bf6dd20a4fb2", "an")
      Me.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States.RtsPulsedPortStatusBox_States_an
      'Start Timers/* #REF525# */
      SMSupport.RtsBase.RtsStartTimer(Me.RtsAttan_Timer1, 1000, CurrentTime)
    End Sub
    
    ' \ART_SMG :: Created for state : aus
    ' assume inp: a SySimInputPort;
    ' if not OperatedStates.Contains ("c08a2b9e-cbf1-46c6-8b13-512936573dca|") then
    '   OperatedStates := OperatedStates + "c08a2b9e-cbf1-46c6-8b13-512936573dca|";
    ' end if
    ' // Simulation support : Notification function call for entering state : aus ///* #REF520# */
    ' RtsNotify(This,SENTER,"c08a2b9e-cbf1-46c6-8b13-512936573dca",0,NullString);
    ' 
    ' SimCore.EnterState("c08a2b9e-cbf1-46c6-8b13-512936573dca","aus");
    ' 
    ' This.RtsCurrent_PulsedPortStatusBox := RtsPulsedPortStatusBox_States{enum_datatype}.RtsPulsedPortStatusBox_States_aus;/* #REF521# */
    ' /* #REF522# */
    ' // Entry Actions
    ' /*##STRT 2f18b0fc-457e-4dd5-a3a5-8e4bc504a082 */  switchOff (); nullstat;/*##END 2f18b0fc-457e-4dd5-a3a5-8e4bc504a082 */ 
    Private Sub RtsEnter_aus()
      If not OperatedStates.Contains("c08a2b9e-cbf1-46c6-8b13-512936573dca|") Then
        OperatedStates = OperatedStates + "c08a2b9e-cbf1-46c6-8b13-512936573dca|"
      End If
      'Simulation support : Notification function call for entering state : aus ///* #REF520# */
      RtsNotify(Me, SENTER, "c08a2b9e-cbf1-46c6-8b13-512936573dca", 0, NullString)
      SimCore.EnterState("c08a2b9e-cbf1-46c6-8b13-512936573dca", "aus")
      Me.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States.RtsPulsedPortStatusBox_States_aus
      'Entry Actions
      switchOff()
    End Sub
    
    ' \ART_SMG :: Created for state : an
    ' assume inp: a SySimInputPort;
    ' if This.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States{enum_datatype}.RtsPulsedPortStatusBox_States_an then/* #REF753# */
    ' /* #REF722# */
    ' 	// Simulation support : Notification function call for exiting state : an
    ' 	RtsNotify(This,SEXIT,"7a3b862c-497a-441e-a59e-bf6dd20a4fb2",0,NullString);/* #REF723# */
    ' 	RtsExitSSOf_an ();
    ' 	/* #REF750# */
    ' 	// Stop Timers/* #REF751# */
    ' 	SMSupport.RtsBase.RtsStopTimer(This.RtsAttan_Timer1);
    ' 	/* #REF754# */
    ' end if
    Private Sub RtsExit_an()
      If Me.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States.RtsPulsedPortStatusBox_States_an Then
        'Simulation support : Notification function call for exiting state : an
        RtsNotify(Me, SEXIT, "7a3b862c-497a-441e-a59e-bf6dd20a4fb2", 0, NullString)
        RtsExitSSOf_an()
        'Stop Timers/* #REF751# */
        SMSupport.RtsBase.RtsStopTimer(Me.RtsAttan_Timer1)
      End If
    End Sub
    
    ' \ART_SMG :: Created for state : aus
    ' assume inp: a SySimInputPort;
    ' if This.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States{enum_datatype}.RtsPulsedPortStatusBox_States_aus then/* #REF753# */
    ' /* #REF722# */
    ' 	// Simulation support : Notification function call for exiting state : aus
    ' 	RtsNotify(This,SEXIT,"c08a2b9e-cbf1-46c6-8b13-512936573dca",0,NullString);/* #REF723# */
    ' 	RtsExitSSOf_aus ();
    ' 	/* #REF754# */
    ' end if
    Private Sub RtsExit_aus()
      If Me.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States.RtsPulsedPortStatusBox_States_aus Then
        'Simulation support : Notification function call for exiting state : aus
        RtsNotify(Me, SEXIT, "c08a2b9e-cbf1-46c6-8b13-512936573dca", 0, NullString)
        RtsExitSSOf_aus()
      End If
    End Sub
    
    Private Shared Sub RtsInjectEvent(ByRef RetValue As Integer, ByRef TheEvent As String, ByRef Params As SimStringArray, ByRef pInstance As PulsedPortStatusBox)
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' declare Ret := 0: Integer;
    ' if Name = "RtsCurrent_PulsedPortStatusBox" then
    '   Ret := TypeConverter.ConvertToString(Value, pInstance.RtsCurrent_PulsedPortStatusBox, "RtsPulsedPortStatusBox_States");
    ' end if
    ' if Name = "RtsBusy" then
    '   Ret := TypeConverter.ConvertToString(Value, pInstance.RtsBusy, "SMSupport.RtsSemaphore");
    ' end if
    ' if Name = "RtsCurrent_PulsedPortStatusBox" then
    '   Ret := TypeConverter.ConvertToString(Value, pInstance.RtsCurrent_PulsedPortStatusBox, "RtsPulsedPortStatusBox_States");
    ' end if
    ' if Name = "RtsBusy" then
    '   Ret := TypeConverter.ConvertToString(Value, pInstance.RtsBusy, "SMSupport.RtsSemaphore");
    ' end if
    ' if Name = "$ClassID" then
    '   // Return the Current Class ID
    '   Value := "0b3d8144-e827-4b9b-8c59-b1c0e10f3dcb";
    ' end if
    ' if Name = "$Model" then
    '   // Return the Current Model ID
    '   Value := "df7d62d6-d1cb-43e3-9dea-156304063f85";
    ' end if
    ' if Name = "$AttributeNames" then
    '   Value := "4";
    '   Value := Value + "|RtsCurrent_PulsedPortStatusBox";
    '   Value := Value + "|RtsBusy";
    '   Value := Value + "|RtsCurrent_PulsedPortStatusBox";
    '   Value := Value + "|RtsBusy";
    ' end if
    ' RetValue := Ret;
    ' 
    Private Shared Sub RtsGetAttributeValue(ByRef RetValue As Integer, ByRef Name As String, ByRef Value As String, ByVal buflen As Integer, ByRef pInstance As PulsedPortStatusBox)
      Dim Ret As Integer = 0
      If Name = "RtsCurrent_PulsedPortStatusBox" Then
        Ret = TypeConverter.ConvertToString(Value, pInstance.RtsCurrent_PulsedPortStatusBox, "RtsPulsedPortStatusBox_States")
      End If
      If Name = "RtsBusy" Then
        Ret = TypeConverter.ConvertToString(Value, pInstance.RtsBusy, "SMSupport.RtsSemaphore")
      End If
      If Name = "RtsCurrent_PulsedPortStatusBox" Then
        Ret = TypeConverter.ConvertToString(Value, pInstance.RtsCurrent_PulsedPortStatusBox, "RtsPulsedPortStatusBox_States")
      End If
      If Name = "RtsBusy" Then
        Ret = TypeConverter.ConvertToString(Value, pInstance.RtsBusy, "SMSupport.RtsSemaphore")
      End If
      If Name = "$ClassID" Then
        'Return the Current Class ID
        Value = "0b3d8144-e827-4b9b-8c59-b1c0e10f3dcb"
      End If
      If Name = "$Model" Then
        'Return the Current Model ID
        Value = "df7d62d6-d1cb-43e3-9dea-156304063f85"
      End If
      If Name = "$AttributeNames" Then
        Value = "4"
        Value = Value + "|RtsCurrent_PulsedPortStatusBox"
        Value = Value + "|RtsBusy"
        Value = Value + "|RtsCurrent_PulsedPortStatusBox"
        Value = Value + "|RtsBusy"
      End If
      RetValue = Ret
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' declare Ret := 0: Integer;
    ' if Name = "RtsCurrent_PulsedPortStatusBox" then
    '   Ret := TypeConverter.ConvertFromString(pInstance.RtsCurrent_PulsedPortStatusBox, Value, "RtsPulsedPortStatusBox_States", GetType(PulsedPortStatusBox.RtsPulsedPortStatusBox_States));
    ' end if
    ' if Name = "RtsBusy" then
    '   Ret := TypeConverter.ConvertFromString(pInstance.RtsBusy, Value, "SMSupport.RtsSemaphore", GetType(SMSupport.RtsSemaphore));
    ' end if
    ' RetValue := Ret;
    ' 
    Private Shared Sub RtsSetAttributeValue(ByRef RetValue As Integer, ByRef Name As String, ByRef Value As String, ByRef pInstance As PulsedPortStatusBox)
      Dim Ret As Integer = 0
      If Name = "RtsCurrent_PulsedPortStatusBox" Then
        Ret = TypeConverter.ConvertFromString(pInstance.RtsCurrent_PulsedPortStatusBox, Value, "RtsPulsedPortStatusBox_States", GetType(PulsedPortStatusBox.RtsPulsedPortStatusBox_States))
      End If
      If Name = "RtsBusy" Then
        Ret = TypeConverter.ConvertFromString(pInstance.RtsBusy, Value, "SMSupport.RtsSemaphore", GetType(SMSupport.RtsSemaphore))
      End If
      RetValue = Ret
    End Sub
    
    ' \ART_SMG :: Created for state : an
    ' assume inp: a SySimInputPort;
    ' SMSupport.RtsBase.RtsStopTimer(This.RtsAttan_Timer1);
    ' declare RetValue := false : boolean;
    '   SMSupport.RtsBase.RtsLock(This.RtsBusy);
    '   This.Rtsan_Timer1_In_PulsedPortStatusBox(RetValue);
    '   RetValue := true;
    '   while RetValue do
    '     This.RtsRunToCompletion(RetValue);
    '   end while
    '   SMSupport.RtsBase.RtsUnlock(This.RtsBusy);
    ' 
    Private Sub Rtsan_Timer1()
      SMSupport.RtsBase.RtsStopTimer(Me.RtsAttan_Timer1)
      Dim RetValue As boolean = False
      SMSupport.RtsBase.RtsLock(Me.RtsBusy)
      Me.Rtsan_Timer1_In_PulsedPortStatusBox(RetValue)
      RetValue = True
      While RetValue
        Me.RtsRunToCompletion(RetValue)
      End While
      SMSupport.RtsBase.RtsUnlock(Me.RtsBusy)
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' // H1 an
    ' if This.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States{enum_datatype}.RtsPulsedPortStatusBox_States_an then/* #REF5# */
    ' /* #REF6# */
    ' 	/* #REF7004# */
    ' 	/* #REF7001# */
    ' 	/* #REF7002# */
    ' 	/* #REF7002B#  RtsExit_an */
    ' 	/* standard */
    ' 	This.RtsExit_an();/* #REF1596# */
    ' 	// Simulation support : Notification function calls for transition/* #REF1598# */
    ' 	RtsNotify(This,TRANSITION,"0a92b614-376e-4640-918d-236e414170ed",0,NullString);/* #REF1599# */
    ' 	
    ' 	/*##STRT ef6bec50-b8b6-474e-8f7a-a12ffab6c508 */  nullstat;/*##END ef6bec50-b8b6-474e-8f7a-a12ffab6c508 */ /* #REF1546# */
    ' 	This.RtsEnter_aus();/* #REF1590# */
    ' 	/* #REF13# */
    ' 	RetValue := true;
    ' 	return;
    ' 	/* #REF15# */
    ' end if
    ' RetValue := false;/* #REF4# */
    ' return;
    Private Sub Rtsan_Timer1_In_PulsedPortStatusBox(ByRef RetValue As Boolean)
      'H1 an
      If Me.RtsCurrent_PulsedPortStatusBox = RtsPulsedPortStatusBox_States.RtsPulsedPortStatusBox_States_an Then
        Me.RtsExit_an()
        'Simulation support : Notification function calls for transition/* #REF1598# */
        RtsNotify(Me, TRANSITION, "0a92b614-376e-4640-918d-236e414170ed", 0, NullString)
        Me.RtsEnter_aus()
        RetValue = True
        Return
      End If
      RetValue = False
      Return
    End Sub
    
    ' \ART_SMG :: Created for state : an
    ' assume inp: a SySimInputPort;
    ' if not OperatedStates.Contains ("7a3b862c-497a-441e-a59e-bf6dd20a4fb2|") then
    '   OperatedStates := OperatedStates + "7a3b862c-497a-441e-a59e-bf6dd20a4fb2|";
    ' end if
    ' 
    Private Sub RtsExitSSOf_an()
      If not OperatedStates.Contains("7a3b862c-497a-441e-a59e-bf6dd20a4fb2|") Then
        OperatedStates = OperatedStates + "7a3b862c-497a-441e-a59e-bf6dd20a4fb2|"
      End If
    End Sub
    
    ' \ART_SMG :: Created for state : aus
    ' assume inp: a SySimInputPort;
    ' if not OperatedStates.Contains ("c08a2b9e-cbf1-46c6-8b13-512936573dca|") then
    '   OperatedStates := OperatedStates + "c08a2b9e-cbf1-46c6-8b13-512936573dca|";
    ' end if
    ' 
    Private Sub RtsExitSSOf_aus()
      If not OperatedStates.Contains("c08a2b9e-cbf1-46c6-8b13-512936573dca|") Then
        OperatedStates = OperatedStates + "c08a2b9e-cbf1-46c6-8b13-512936573dca|"
      End If
    End Sub
    
    ' assume inp: a SySimInputPort;
    '   declare Ret := SMSupport.RtsTimer.MaxDuration: SMSupport.Duration;
    '   CurrentTime := NewCurrentTime;
    ' This.RtsAttan_Timer1.TStep(CurrentTime);
    ' if This.RtsAttan_Timer1.HasElapsed() then
    '   This.RtsAttan_Timer1.TStop();
    '   Rtsan_Timer1_CallBack(This);
    ' end if
    ' Ret := SMSupport.Duration.MinOf(Ret, This.RtsAttan_Timer1.TimeToLive());
    ' TTL := Ret;
    Public Shadows Sub SMStep(ByVal NewCurrentTime As SMSupport.Time, ByRef TTL As SMSupport.Duration)
      Dim Ret As SMSupport.Duration = SMSupport.RtsTimer.MaxDuration
      CurrentTime = NewCurrentTime
      Me.RtsAttan_Timer1.TStep(CurrentTime)
      If Me.RtsAttan_Timer1.HasElapsed() Then
        Me.RtsAttan_Timer1.TStop()
        Rtsan_Timer1_CallBack(Me)
      End If
      Ret = SMSupport.Duration.MinOf(Ret, Me.RtsAttan_Timer1.TimeToLive())
      TTL = Ret
    End Sub
    
    Public Shadows Sub SMQueueStep(ByVal CurrentTime As SMSupport.Time, ByRef TTL As SMSupport.Duration)
      If Not SMStarted Then
        Dim RunAgain As Boolean = True
        While RunAgain
          RtsRunToCompletion(RunAgain)
        End While
        SMStarted = True
      End If
      GetQueue().DispatchAllExisting(Me)
      SMStep(CurrentTime, TTL)
      RunChangeEvents()
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' Declare RetValue := False : Boolean;
    ' declare ChgFlg1Tmp := (/*##STRT ef30b450-22b3-40ff-b43e-dc5fac20633c */ ( inp )/*##END ef30b450-22b3-40ff-b43e-dc5fac20633c */ ) : Boolean;
    ' ChgFlg1 := EvalTrigger(ChgFlg1Tmp , ChgFlgLast1);
    ' OperatedStates := "";
    ' RtsRunToCompletion(RetValue, True);
    ' ChgFlgLast1 := ChgFlg1Tmp;
    ' While DecrementInPorts() Do
    '   MaskInPorts(True);
    '   declare MaskedChgFlg1 := (/*##STRT ef30b450-22b3-40ff-b43e-dc5fac20633c */ ( inp )/*##END ef30b450-22b3-40ff-b43e-dc5fac20633c */ ) : Boolean;
    '   MaskInPorts(False);
    '   declare UnMaskedChgFlg1 := (/*##STRT ef30b450-22b3-40ff-b43e-dc5fac20633c */ ( inp )/*##END ef30b450-22b3-40ff-b43e-dc5fac20633c */ ) : Boolean;
    '   declare PreviousChgFlg1 := ChgFlg1 : Boolean;
    '   // A condition is 'sensitive to ports' whenever:
    '   // (1) was true so far in this execution, and
    '   // (2) is still true at this port decrement state, and
    '   // (3) would be false if we mask the ports
    '   If PreviousChgFlg1 And UnMaskedChgFlg1 And Not MaskedChgFlg1 Then
    '     // This is sensitive to ports - run it again
    '   ChgFlg1 := True;
    '     OperatedStates := "";
    '     RtsRunToCompletion(RetValue, True);
    '   End If
    ' End While
    ' ChgFlg1 := false;
    ' 
    Public Shadows Sub RunChangeEvents()
      Dim RetValue As Boolean = False
      Dim ChgFlg1Tmp As Boolean = ((inp.GetLatchedValue()))
      ChgFlg1 = EvalTrigger(ChgFlg1Tmp, ChgFlgLast1)
      OperatedStates = ""
      RtsRunToCompletion(RetValue, True)
      ChgFlgLast1 = ChgFlg1Tmp
      While DecrementInPorts()
        MaskInPorts(True)
        Dim MaskedChgFlg1 As Boolean = ((inp.GetLatchedValue()))
        MaskInPorts(False)
        Dim UnMaskedChgFlg1 As Boolean = ((inp.GetLatchedValue()))
        Dim PreviousChgFlg1 As Boolean = ChgFlg1
        'A condition is 'sensitive to ports' whenever:
        '(1) was true so far in this execution, and
        '(2) is still true at this port decrement state, and
        '(3) would be false if we mask the ports
        If PreviousChgFlg1 And UnMaskedChgFlg1 And Not MaskedChgFlg1 Then
          'This is sensitive to ports - run it again
          ChgFlg1 = True
          OperatedStates = ""
          RtsRunToCompletion(RetValue, True)
        End If
      End While
      ChgFlg1 = False
    End Sub
    
    Private Function SenseTrigger(ByVal ExprValue As Boolean, ByVal ChangeEventActive As Boolean, ByVal ThisState As String) As Boolean
      Dim Ret As Boolean = False
      If ChangeEventActive Then
        If Not OperatedStates.Contains(ThisState + "|") Then
          If ExprValue Then
            Ret = True
          End If
        End If
      End If
      Return Ret
    End Function
    
    Public Shadows Function EvalTrigger(ByVal ExprValue As Boolean, ByVal LastExprValue As Boolean) As Boolean
      Dim Ret As Boolean = False
      If ExprValue And Not LastExprValue Then
        Ret = True
      End If
      Return Ret
    End Function
    
    Public Shadows Function DecrementInPorts() As Boolean
      Dim Ret As Boolean = False
      Ret = (Ret Or inp.Decrement())
      Return Ret
    End Function
    
    Public Shadows Sub MaskInPorts(ByVal What As Boolean)
      inp.Mask(What)
      
    End Sub
    
    Public Overridable Function GetQueue() As SMSupport.SMQueue Implements SMSupport.SMQueued.GetQueue
      Return TheQueue
    End Function
    
  End Class
End Namespace
