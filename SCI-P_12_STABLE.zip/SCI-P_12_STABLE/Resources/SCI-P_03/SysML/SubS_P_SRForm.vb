Option Explicit On
Imports SIMULATOR.SubS_P_SRPackage
Namespace SIMULATOR
  Partial Public Class SubS_P_SRForm : Inherits PredefinedControls.OFormBase
    Private TheToolTip As Tooltip
    Private SimMaster As SIMULATOR.SubS_P_SRPackage.SubS_P_SRSimMaster
    Public Sub New()
      InitializeComponent()
      TheToolTip = New ToolTip()
      SimMaster = New SubS_P_SRSimMaster(Me)
      SimMaster.Build()
      SimMaster.CompleteBuild()
      SimMaster.Bind()
      SimMaster.Check()
      ApplyStyles("SubS_P_SR")
    End Sub
    
    Public Function GetTheToolTip() As Tooltip
      Return TheToolTip
    End Function
    
  End Class
End Namespace
