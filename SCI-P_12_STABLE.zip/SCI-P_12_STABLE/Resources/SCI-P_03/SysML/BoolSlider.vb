Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.BoolSlider
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class BoolSlider : Inherits TrackBar
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Protected outp As OOutputPort(Of Boolean)
    Public Sub initialise(ByRef Rejections As Integer, ByVal ErrList As OErrorList) Handles SimCore.OnReadyToStart
      ' ## VBOperationBody [c97d428b-0199-4b6c-a73e-3345bfe310e0] 
      Me.Value = 0
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub handleScroll() Handles Me.Scroll
      ' ## VBOperationBody [123e71a5-36ca-4158-bb69-395f0070ed99] 
      If Me.Value = 1 Then
          Me.BackColor = Color.Orange
      Else
          Me.BackColor = SystemColors.Control
      End If
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub updateOutputValues(ByVal Ph As OPhase) Handles SimCore.OnWriteOutputs
      ' ## VBOperationBody [0498a972-8b8e-4ec1-aea6-d2494b942e41] 
      If Me.Value = 1 Then
          outp.SetValue(True)
      Else
          outp.SetValue(False)
      End If
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub New()
      ' ## VBOperationBody [cca8ffb0-7da5-405b-a6d8-1c9c82161b30] 
      Me.Minimum = 0
      Me.Maximum = 1
      Me.TickStyle = TickStyle.Both
      Me.Width = 40
      ' ## VBOperationBody End 
    End Sub
    
  End Class
End Namespace
