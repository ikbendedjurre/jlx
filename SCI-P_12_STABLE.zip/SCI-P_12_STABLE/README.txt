################### README ###################

Instructions to run a test suite:
1. Open command prompt.
2. Navigate to bin/Release
3. Run "SubS_P_SR.exe -r" (random strategy) or "SubS_P_SR.exe -g" (guided strategy) or "SubS_P_SR.exe" (help)

Notes:
 Number of tests is currently hardcoded.
 Source code is located in SysML/
 Additions to the simulator code is located in SysML/mbt
 Entry point is SysML/mbt/Main.vb


