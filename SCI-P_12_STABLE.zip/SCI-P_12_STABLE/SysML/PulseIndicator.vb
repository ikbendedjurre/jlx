Option Explicit On
Imports SySimFWK, PredefinedControls
Imports SimSupport.SimPrimitives, SimSupport.SimPrimitives.NotifyEnum, SimSupport

Namespace EULYNX_Profile.Controls.PulseIndicator
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class PulseIndicator : Inherits PictureBox : Implements SMSupport.SMQueued 
    Protected Class PulseIndicatorSMQueue : Inherits SMSupport.SMQueue
      Public Overrides Sub DispatchOne(ByVal Target As SMSupport.SMQueued, ByVal Msg As SMSupport.SMMessage)
        Dim TheTarget As PulseIndicator = Target
        TheTarget.Sender = Msg.GetSender()
        Select Case Msg.GetId()
        End Select
        
      End Sub
      
    End Class
    Public Shadows Class TypeConverter : Inherits SMSupport.TypeConverterBase
    End Class
    Public Enum RtsPulseIndicator_States
      RtsPulseIndicator_States_off
      RtsPulseIndicator_States_on
      RtsPulseIndicator_States_NotIn_PulseIndicator
    End Enum
    ' \ART_SMG :: Created for state : PulseIndicator
    Private RtsCurrent_PulseIndicator As PulseIndicator.RtsPulseIndicator_States
    ' \ART_SMG :: Created for state : on
    Private RtsAtton_Timer1 As SMSupport.RtsTimer
    ' \ART_SMG :: Always Created
    Private RtsBusy As SMSupport.RtsSemaphore
    Private ChgFlgLast1 As Boolean
    Private ChgFlg1 As Boolean
    Private Const TickDivider As Single = 0.050
    Private CurrentTime As SMSupport.Time
    Private OperatedStates As String = ""
    Private SMStarted As Boolean
    Protected Shadows Sender As Object
    Private TheQueue As PulseIndicatorSMQueue = New PulseIndicatorSMQueue
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Protected inp As OInputPort(Of Data_Types.PulsedIn)
    Private Value As Boolean = False
    Public Sub receive(ByVal Ph As OPhase) Handles SimCore.OnReadInputs
      Dim ChgFlg1Tmp As Boolean = ((inp.GetLatchedValue()))
      'Console.WriteLine("** " + Me.Name + "/" + Me.Text + "/" + inp.FullName + "/" + inp.GetName() + "/" + inp.Description + " received " + ChgFlg1Tmp.ToString)
      Adapter.ReportOutput(Me, ChgFlg1Tmp)
    End Sub

    Public Sub switchOn()
      ' ## VBOperationBody [9e2bdae7-2b61-45ba-b9ca-ceb0b3f54150] 
      Me.BackColor = Color.Orange
      'Adapter.ReportOutput(Me, ChgFlg1Tmp)
      'Console.WriteLine("** " + Me.Name + " --> TRUE")
      'Adapter.ReportOutput(Me, True)
      ' ## VBOperationBody End 
    End Sub

    Public Sub switchOff()
      ' ## VBOperationBody [f1c41957-fb4a-4f48-a926-134acdb475e0] 
      Me.BackColor = Color.DarkGray
      'Console.WriteLine("** " + Me.Name + " --> FALSE")
      'Adapter.ReportOutput(Me, False)
      ' ## VBOperationBody End 
    End Sub

    Public Sub New()
      ' ## VBOperationBody [7f796ecf-6b4e-4d09-aa97-e1a77ecde560] 
      Me.BackColor = Color.DarkGray
      Me.BorderStyle = BorderStyle.FixedSingle
      Me.Height = 30
      Me.Width = 30
      ' ## VBOperationBody End 
    End Sub
    
    Public Sub initialise(ByRef Rejections As Integer, ByVal ErrList As OErrorList) Handles SimCore.OnReadyToStart
      ' ## VBOperationBody [d4e89054-d883-45c8-8fb7-85558b06d8a9] 
      Me.BackColor = Color.DarkGray
      ' ## VBOperationBody End 
    End Sub
    
    ' \ART_SMG :: Created for state : on
    ' assume inp: a SySimInputPort;
    ' pInstance.Rtson_Timer1();
    Private Shared Sub Rtson_Timer1_CallBack(ByRef pInstance As PulseIndicator)
      pInstance.Rtson_Timer1()
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' assume RtsCurrent_PulseIndicator: on object;
    ' assume RtsAtton_Timer1: on object;
    ' declare ThisState : String;
    ' /* #REF121# */
    ' if /* #REF121c# */ This.RtsCurrent_PulseIndicator =  /* #REF121d# */ RtsPulseIndicator_States{enum_datatype}.RtsPulseIndicator_States_NotIn_PulseIndicator then
    ' /* #REF123# */
    ' 	/* 01c9452e-34b5-4540-9c21-dd95265edca2 Initial */
    '   ThisState := "01c9452e-34b5-4540-9c21-dd95265edca2";
    ' 	// Simulation support : Notification function calls for Entry and Exit of Initial state/* #REF126# */
    ' 	RtsNotify(This,SENTER,"01c9452e-34b5-4540-9c21-dd95265edca2",0,NullString);/* #REF127# */
    ' 	RtsNotify(This,SEXIT,"01c9452e-34b5-4540-9c21-dd95265edca2",0,NullString);/* #REF128# */
    ' 	
    ' 	/* #REF7004# */
    ' 	/* #REF7001# */
    ' 	/* #REF7002# */
    ' 	/* #REF7002B#  RtsExit_Initial */
    ' 	/* standard */
    ' 	// Simulation support : Notification function calls for transition/* #REF1598# */
    ' 	RtsNotify(This,TRANSITION,"c487181b-ff8f-449e-a6ae-814a8aedbbc4",0,NullString);/* #REF1599# */
    ' 	
    ' 	/*##STRT 0d559db6-f8a5-4392-8734-9daec45295a4 */  switchOff (); nullstat;/*##END 0d559db6-f8a5-4392-8734-9daec45295a4 */ /* #REF1546# */
    ' 	This.RtsEnter_off();/* #REF1590# */
    ' 	RetValue := true; /* #REF129# */
    ' 	return;/* #REF130# */
    ' End If/* #REF121# */
    ' if /* #REF121c# */ This.RtsCurrent_PulseIndicator = RtsPulseIndicator_States{enum_datatype}.RtsPulseIndicator_States_off then
    ' /* #REF123# */
    ' 	/* 12497346-00a7-4ab8-a9fc-1fd821b56021 off */
    '   ThisState := "12497346-00a7-4ab8-a9fc-1fd821b56021";
    ' 	if /* #REF2001# */ SenseTrigger(ChgFlg1, ChangeEventsActive, ThisState) then/* #REF124# */
    ' 	/* #REF125# */
    ' 		/* #REF7004# */
    ' 		/* #REF7001# */
    ' 		/* #REF7002# */
    ' 		/* #REF7002B#  RtsExit_off */
    ' 		/* standard */
    ' 		This.RtsExit_off();/* #REF1596# */
    ' 		// Simulation support : Notification function calls for transition/* #REF1598# */
    ' 		RtsNotify(This,TRANSITION,"f4f816e3-676a-48cc-95b8-a0766f6014ed",0,NullString);/* #REF1599# */
    ' 		
    ' 		/*##STRT 11a40d36-9b46-4bda-afad-d41544d0acc5 */  switchOn (); nullstat;/*##END 11a40d36-9b46-4bda-afad-d41544d0acc5 */ /* #REF1546# */
    ' 		This.RtsEnter_on();/* #REF1590# */
    ' 		RetValue := true; /* #REF129# */
    ' 		return;/* #REF130# */
    ' 	End If/* #REF131# */
    ' End If/* #REF122# */
    ' RetValue := false;
    ' return;
    Private Sub RtsRunToCompletion(ByRef RetValue As Boolean, Optional ByVal ChangeEventsActive As Boolean = False)
      Dim ThisState As String = Nothing
      If Me.RtsCurrent_PulseIndicator = RtsPulseIndicator_States.RtsPulseIndicator_States_NotIn_PulseIndicator Then
        ThisState = "01c9452e-34b5-4540-9c21-dd95265edca2"
        'Simulation support : Notification function calls for Entry and Exit of Initial state/* #REF126# */
        RtsNotify(Me, SENTER, "01c9452e-34b5-4540-9c21-dd95265edca2", 0, NullString)
        RtsNotify(Me, SEXIT, "01c9452e-34b5-4540-9c21-dd95265edca2", 0, NullString)
        'Simulation support : Notification function calls for transition/* #REF1598# */
        RtsNotify(Me, TRANSITION, "c487181b-ff8f-449e-a6ae-814a8aedbbc4", 0, NullString)
        switchOff()
        Me.RtsEnter_off()
        RetValue = True
        Return
      End If
      If Me.RtsCurrent_PulseIndicator = RtsPulseIndicator_States.RtsPulseIndicator_States_off Then
        ThisState = "12497346-00a7-4ab8-a9fc-1fd821b56021"
        If SenseTrigger(ChgFlg1, ChangeEventsActive, ThisState) Then
          Me.RtsExit_off()
          'Simulation support : Notification function calls for transition/* #REF1598# */
          RtsNotify(Me, TRANSITION, "f4f816e3-676a-48cc-95b8-a0766f6014ed", 0, NullString)
          switchOn()
          Me.RtsEnter_on()
          RetValue = True
          Return
        End If
      End If
      RetValue = False
      Return
    End Sub
    
    ' \ART_SMG :: Constructor
    ' assume inp: a SySimInputPort;
    ' SimSetModelId("df7d62d6-d1cb-43e3-9dea-156304063f85");/* #REF1559# */
    ' SimInitialize();/* #REF1560# */
    ' CurrentTime := New SMSupport.Time;/* #REF1560# */
    ' RtsNotifySynchronous(This, CREATE, "222313c3-89f4-42bd-9263-d05aea77e725", 0, NullString, addressof(RtsInjectEvent), addressof(RtsGetAttributeValue), addressof(RtsSetAttributeValue));/* #REF1561# */
    ' SMSupport.RtsBase.RtsCreateSemaphore(This.RtsBusy);/* #REF1563# */
    ' SMSupport.RtsBase.RtsLock(This.RtsBusy);/* #REF1564# */
    ' SMSupport.RtsBase.RtsCreateTimer(This.RtsAtton_Timer1);// DoState Timer Placeholder
    ' /* #REF1565# */
    ' 
    ' // Initialising State Vectors to NotIn
    ' This.RtsCurrent_PulseIndicator := RtsPulseIndicator_States{enum_datatype}.RtsPulseIndicator_States_NotIn_PulseIndicator;/* #REF1566# */
    ' SMSupport.RtsBase.RtsUnlock(This.RtsBusy);
    ' 
    Public Shadows Sub SMGInitialize(Optional ByVal SingleStep As Boolean = False)
      SimSetModelId("df7d62d6-d1cb-43e3-9dea-156304063f85")
      SimInitialize()
      CurrentTime = New SMSupport.Time
      RtsNotifySynchronous(Me, CREATE, "222313c3-89f4-42bd-9263-d05aea77e725", 0, NullString, AddressOf RtsInjectEvent, AddressOf RtsGetAttributeValue, AddressOf RtsSetAttributeValue)
      SMSupport.RtsBase.RtsCreateSemaphore(Me.RtsBusy)
      SMSupport.RtsBase.RtsLock(Me.RtsBusy)
      SMSupport.RtsBase.RtsCreateTimer(Me.RtsAtton_Timer1)
      'DoState Timer Placeholder
      'Initialising State Vectors to NotIn
      Me.RtsCurrent_PulseIndicator = RtsPulseIndicator_States.RtsPulseIndicator_States_NotIn_PulseIndicator
      SMSupport.RtsBase.RtsUnlock(Me.RtsBusy)
    End Sub
    
    ' \ART_SMG :: Destructor
    ' assume inp: a SySimInputPort;
    ' /* #REF1617# */
    ' RtsUnregister(This);
    Public Shadows Sub SMGTerminate()
      RtsUnregister(Me)
    End Sub
    
    ' \ART_SMG :: Created for state : off
    ' assume inp: a SySimInputPort;
    ' if not OperatedStates.Contains ("12497346-00a7-4ab8-a9fc-1fd821b56021|") then
    '   OperatedStates := OperatedStates + "12497346-00a7-4ab8-a9fc-1fd821b56021|";
    ' end if
    ' // Simulation support : Notification function call for entering state : off ///* #REF520# */
    ' RtsNotify(This,SENTER,"12497346-00a7-4ab8-a9fc-1fd821b56021",0,NullString);
    ' 
    ' SimCore.EnterState("12497346-00a7-4ab8-a9fc-1fd821b56021","off");
    ' 
    ' This.RtsCurrent_PulseIndicator := RtsPulseIndicator_States{enum_datatype}.RtsPulseIndicator_States_off;/* #REF521# */
    ' 
    Private Sub RtsEnter_off()
      If not OperatedStates.Contains("12497346-00a7-4ab8-a9fc-1fd821b56021|") Then
        OperatedStates = OperatedStates + "12497346-00a7-4ab8-a9fc-1fd821b56021|"
      End If
      'Simulation support : Notification function call for entering state : off ///* #REF520# */
      RtsNotify(Me, SENTER, "12497346-00a7-4ab8-a9fc-1fd821b56021", 0, NullString)
      SimCore.EnterState("12497346-00a7-4ab8-a9fc-1fd821b56021", "off")
      Me.RtsCurrent_PulseIndicator = RtsPulseIndicator_States.RtsPulseIndicator_States_off
    End Sub
    
    ' \ART_SMG :: Created for state : on
    ' assume inp: a SySimInputPort;
    ' if not OperatedStates.Contains ("9686e789-93dc-48be-b338-14dece33d23a|") then
    '   OperatedStates := OperatedStates + "9686e789-93dc-48be-b338-14dece33d23a|";
    ' end if
    ' // Simulation support : Notification function call for entering state : on ///* #REF520# */
    ' RtsNotify(This,SENTER,"9686e789-93dc-48be-b338-14dece33d23a",0,NullString);
    ' 
    ' SimCore.EnterState("9686e789-93dc-48be-b338-14dece33d23a","on");
    ' 
    ' This.RtsCurrent_PulseIndicator := RtsPulseIndicator_States{enum_datatype}.RtsPulseIndicator_States_on;/* #REF521# */
    ' /* #REF523# */
    ' // Start Timers/* #REF525# */
    ' SMSupport.RtsBase.RtsStartTimer(This.RtsAtton_Timer1, /*##STRT 972bdfc9-99c9-4ebb-b7a7-165d756755ec */ 1000/*##END 972bdfc9-99c9-4ebb-b7a7-165d756755ec */ , CurrentTime);
    Private Sub RtsEnter_on()
      If not OperatedStates.Contains("9686e789-93dc-48be-b338-14dece33d23a|") Then
        OperatedStates = OperatedStates + "9686e789-93dc-48be-b338-14dece33d23a|"
      End If
      'Simulation support : Notification function call for entering state : on ///* #REF520# */
      RtsNotify(Me, SENTER, "9686e789-93dc-48be-b338-14dece33d23a", 0, NullString)
      SimCore.EnterState("9686e789-93dc-48be-b338-14dece33d23a", "on")
      Me.RtsCurrent_PulseIndicator = RtsPulseIndicator_States.RtsPulseIndicator_States_on
      'Start Timers/* #REF525# */
      SMSupport.RtsBase.RtsStartTimer(Me.RtsAtton_Timer1, 100, CurrentTime)
    End Sub
    
    ' \ART_SMG :: Created for state : off
    ' assume inp: a SySimInputPort;
    ' if This.RtsCurrent_PulseIndicator = RtsPulseIndicator_States{enum_datatype}.RtsPulseIndicator_States_off then/* #REF753# */
    ' /* #REF722# */
    ' 	// Simulation support : Notification function call for exiting state : off
    ' 	RtsNotify(This,SEXIT,"12497346-00a7-4ab8-a9fc-1fd821b56021",0,NullString);/* #REF723# */
    ' 	RtsExitSSOf_off ();
    ' 	/* #REF754# */
    ' end if
    Private Sub RtsExit_off()
      If Me.RtsCurrent_PulseIndicator = RtsPulseIndicator_States.RtsPulseIndicator_States_off Then
        'Simulation support : Notification function call for exiting state : off
        RtsNotify(Me, SEXIT, "12497346-00a7-4ab8-a9fc-1fd821b56021", 0, NullString)
        RtsExitSSOf_off()
      End If
    End Sub
    
    ' \ART_SMG :: Created for state : on
    ' assume inp: a SySimInputPort;
    ' if This.RtsCurrent_PulseIndicator = RtsPulseIndicator_States{enum_datatype}.RtsPulseIndicator_States_on then/* #REF753# */
    ' /* #REF722# */
    ' 	// Simulation support : Notification function call for exiting state : on
    ' 	RtsNotify(This,SEXIT,"9686e789-93dc-48be-b338-14dece33d23a",0,NullString);/* #REF723# */
    ' 	RtsExitSSOf_on ();
    ' 	/* #REF750# */
    ' 	// Stop Timers/* #REF751# */
    ' 	SMSupport.RtsBase.RtsStopTimer(This.RtsAtton_Timer1);
    ' 	/* #REF754# */
    ' end if
    Private Sub RtsExit_on()
      If Me.RtsCurrent_PulseIndicator = RtsPulseIndicator_States.RtsPulseIndicator_States_on Then
        'Simulation support : Notification function call for exiting state : on
        RtsNotify(Me, SEXIT, "9686e789-93dc-48be-b338-14dece33d23a", 0, NullString)
        RtsExitSSOf_on()
        'Stop Timers/* #REF751# */
        SMSupport.RtsBase.RtsStopTimer(Me.RtsAtton_Timer1)
      End If
    End Sub
    
    Private Shared Sub RtsInjectEvent(ByRef RetValue As Integer, ByRef TheEvent As String, ByRef Params As SimStringArray, ByRef pInstance As PulseIndicator)
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' declare Ret := 0: Integer;
    ' if Name = "RtsCurrent_PulseIndicator" then
    '   Ret := TypeConverter.ConvertToString(Value, pInstance.RtsCurrent_PulseIndicator, "RtsPulseIndicator_States");
    ' end if
    ' if Name = "RtsBusy" then
    '   Ret := TypeConverter.ConvertToString(Value, pInstance.RtsBusy, "SMSupport.RtsSemaphore");
    ' end if
    ' if Name = "RtsCurrent_PulseIndicator" then
    '   Ret := TypeConverter.ConvertToString(Value, pInstance.RtsCurrent_PulseIndicator, "RtsPulseIndicator_States");
    ' end if
    ' if Name = "RtsBusy" then
    '   Ret := TypeConverter.ConvertToString(Value, pInstance.RtsBusy, "SMSupport.RtsSemaphore");
    ' end if
    ' if Name = "$ClassID" then
    '   // Return the Current Class ID
    '   Value := "222313c3-89f4-42bd-9263-d05aea77e725";
    ' end if
    ' if Name = "$Model" then
    '   // Return the Current Model ID
    '   Value := "df7d62d6-d1cb-43e3-9dea-156304063f85";
    ' end if
    ' if Name = "$AttributeNames" then
    '   Value := "4";
    '   Value := Value + "|RtsCurrent_PulseIndicator";
    '   Value := Value + "|RtsBusy";
    '   Value := Value + "|RtsCurrent_PulseIndicator";
    '   Value := Value + "|RtsBusy";
    ' end if
    ' RetValue := Ret;
    ' 
    Private Shared Sub RtsGetAttributeValue(ByRef RetValue As Integer, ByRef Name As String, ByRef Value As String, ByVal buflen As Integer, ByRef pInstance As PulseIndicator)
      Dim Ret As Integer = 0
      If Name = "RtsCurrent_PulseIndicator" Then
        Ret = TypeConverter.ConvertToString(Value, pInstance.RtsCurrent_PulseIndicator, "RtsPulseIndicator_States")
      End If
      If Name = "RtsBusy" Then
        Ret = TypeConverter.ConvertToString(Value, pInstance.RtsBusy, "SMSupport.RtsSemaphore")
      End If
      If Name = "RtsCurrent_PulseIndicator" Then
        Ret = TypeConverter.ConvertToString(Value, pInstance.RtsCurrent_PulseIndicator, "RtsPulseIndicator_States")
      End If
      If Name = "RtsBusy" Then
        Ret = TypeConverter.ConvertToString(Value, pInstance.RtsBusy, "SMSupport.RtsSemaphore")
      End If
      If Name = "$ClassID" Then
        'Return the Current Class ID
        Value = "222313c3-89f4-42bd-9263-d05aea77e725"
      End If
      If Name = "$Model" Then
        'Return the Current Model ID
        Value = "df7d62d6-d1cb-43e3-9dea-156304063f85"
      End If
      If Name = "$AttributeNames" Then
        Value = "4"
        Value = Value + "|RtsCurrent_PulseIndicator"
        Value = Value + "|RtsBusy"
        Value = Value + "|RtsCurrent_PulseIndicator"
        Value = Value + "|RtsBusy"
      End If
      RetValue = Ret
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' declare Ret := 0: Integer;
    ' if Name = "RtsCurrent_PulseIndicator" then
    '   Ret := TypeConverter.ConvertFromString(pInstance.RtsCurrent_PulseIndicator, Value, "RtsPulseIndicator_States", GetType(PulseIndicator.RtsPulseIndicator_States));
    ' end if
    ' if Name = "RtsBusy" then
    '   Ret := TypeConverter.ConvertFromString(pInstance.RtsBusy, Value, "SMSupport.RtsSemaphore", GetType(SMSupport.RtsSemaphore));
    ' end if
    ' RetValue := Ret;
    ' 
    Private Shared Sub RtsSetAttributeValue(ByRef RetValue As Integer, ByRef Name As String, ByRef Value As String, ByRef pInstance As PulseIndicator)
      Dim Ret As Integer = 0
      If Name = "RtsCurrent_PulseIndicator" Then
        Ret = TypeConverter.ConvertFromString(pInstance.RtsCurrent_PulseIndicator, Value, "RtsPulseIndicator_States", GetType(PulseIndicator.RtsPulseIndicator_States))
      End If
      If Name = "RtsBusy" Then
        Ret = TypeConverter.ConvertFromString(pInstance.RtsBusy, Value, "SMSupport.RtsSemaphore", GetType(SMSupport.RtsSemaphore))
      End If
      RetValue = Ret
    End Sub
    
    ' \ART_SMG :: Created for state : on
    ' assume inp: a SySimInputPort;
    ' SMSupport.RtsBase.RtsStopTimer(This.RtsAtton_Timer1);
    ' declare RetValue := false : boolean;
    '   SMSupport.RtsBase.RtsLock(This.RtsBusy);
    '   This.Rtson_Timer1_In_PulseIndicator(RetValue);
    '   RetValue := true;
    '   while RetValue do
    '     This.RtsRunToCompletion(RetValue);
    '   end while
    '   SMSupport.RtsBase.RtsUnlock(This.RtsBusy);
    ' 
    Private Sub Rtson_Timer1()
      SMSupport.RtsBase.RtsStopTimer(Me.RtsAtton_Timer1)
      Dim RetValue As boolean = False
      SMSupport.RtsBase.RtsLock(Me.RtsBusy)
      Me.Rtson_Timer1_In_PulseIndicator(RetValue)
      RetValue = True
      While RetValue
        Me.RtsRunToCompletion(RetValue)
      End While
      SMSupport.RtsBase.RtsUnlock(Me.RtsBusy)
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' // H1 on
    ' if This.RtsCurrent_PulseIndicator = RtsPulseIndicator_States{enum_datatype}.RtsPulseIndicator_States_on then/* #REF5# */
    ' /* #REF6# */
    ' 	/* #REF7004# */
    ' 	/* #REF7001# */
    ' 	/* #REF7002# */
    ' 	/* #REF7002B#  RtsExit_on */
    ' 	/* standard */
    ' 	This.RtsExit_on();/* #REF1596# */
    ' 	// Simulation support : Notification function calls for transition/* #REF1598# */
    ' 	RtsNotify(This,TRANSITION,"f1561736-2232-4993-9fe4-3ca31955a2dc",0,NullString);/* #REF1599# */
    ' 	
    ' 	/*##STRT 972bdfc9-99c9-4ebb-b7a7-165d756755ec */  switchOff (); nullstat;/*##END 972bdfc9-99c9-4ebb-b7a7-165d756755ec */ /* #REF1546# */
    ' 	This.RtsEnter_off();/* #REF1590# */
    ' 	/* #REF13# */
    ' 	RetValue := true;
    ' 	return;
    ' 	/* #REF15# */
    ' end if
    ' RetValue := false;/* #REF4# */
    ' return;
    Private Sub Rtson_Timer1_In_PulseIndicator(ByRef RetValue As Boolean)
      'H1 on
      If Me.RtsCurrent_PulseIndicator = RtsPulseIndicator_States.RtsPulseIndicator_States_on Then
        Me.RtsExit_on()
        'Simulation support : Notification function calls for transition/* #REF1598# */
        RtsNotify(Me, TRANSITION, "f1561736-2232-4993-9fe4-3ca31955a2dc", 0, NullString)
        switchOff()
        Me.RtsEnter_off()
        RetValue = True
        Return
      End If
      RetValue = False
      Return
    End Sub
    
    ' \ART_SMG :: Created for state : off
    ' assume inp: a SySimInputPort;
    ' if not OperatedStates.Contains ("12497346-00a7-4ab8-a9fc-1fd821b56021|") then
    '   OperatedStates := OperatedStates + "12497346-00a7-4ab8-a9fc-1fd821b56021|";
    ' end if
    ' 
    Private Sub RtsExitSSOf_off()
      If not OperatedStates.Contains("12497346-00a7-4ab8-a9fc-1fd821b56021|") Then
        OperatedStates = OperatedStates + "12497346-00a7-4ab8-a9fc-1fd821b56021|"
      End If
    End Sub
    
    ' \ART_SMG :: Created for state : on
    ' assume inp: a SySimInputPort;
    ' if not OperatedStates.Contains ("9686e789-93dc-48be-b338-14dece33d23a|") then
    '   OperatedStates := OperatedStates + "9686e789-93dc-48be-b338-14dece33d23a|";
    ' end if
    ' 
    Private Sub RtsExitSSOf_on()
      If not OperatedStates.Contains("9686e789-93dc-48be-b338-14dece33d23a|") Then
        OperatedStates = OperatedStates + "9686e789-93dc-48be-b338-14dece33d23a|"
      End If
    End Sub
    
    ' assume inp: a SySimInputPort;
    '   declare Ret := SMSupport.RtsTimer.MaxDuration: SMSupport.Duration;
    '   CurrentTime := NewCurrentTime;
    ' This.RtsAtton_Timer1.TStep(CurrentTime);
    ' if This.RtsAtton_Timer1.HasElapsed() then
    '   This.RtsAtton_Timer1.TStop();
    '   Rtson_Timer1_CallBack(This);
    ' end if
    ' Ret := SMSupport.Duration.MinOf(Ret, This.RtsAtton_Timer1.TimeToLive());
    ' TTL := Ret;
    Public Shadows Sub SMStep(ByVal NewCurrentTime As SMSupport.Time, ByRef TTL As SMSupport.Duration)
      Dim Ret As SMSupport.Duration = SMSupport.RtsTimer.MaxDuration
      CurrentTime = NewCurrentTime
      Me.RtsAtton_Timer1.TStep(CurrentTime)
      If Me.RtsAtton_Timer1.HasElapsed() Then
        Me.RtsAtton_Timer1.TStop()
        Rtson_Timer1_CallBack(Me)
      End If
      Ret = SMSupport.Duration.MinOf(Ret, Me.RtsAtton_Timer1.TimeToLive())
      TTL = Ret
    End Sub
    
    Public Shadows Sub SMQueueStep(ByVal CurrentTime As SMSupport.Time, ByRef TTL As SMSupport.Duration)
      If Not SMStarted Then
        Dim RunAgain As Boolean = True
        While RunAgain
          RtsRunToCompletion(RunAgain)
        End While
        SMStarted = True
      End If
      GetQueue().DispatchAllExisting(Me)
      SMStep(CurrentTime, TTL)
      RunChangeEvents()
    End Sub
    
    ' assume inp: a SySimInputPort;
    ' Declare RetValue := False : Boolean;
    ' declare ChgFlg1Tmp := (/*##STRT 520dd150-7988-45b1-9f44-be7b16766cb8 */ ( inp )/*##END 520dd150-7988-45b1-9f44-be7b16766cb8 */ ) : Boolean;
    ' ChgFlg1 := EvalTrigger(ChgFlg1Tmp , ChgFlgLast1);
    ' OperatedStates := "";
    ' RtsRunToCompletion(RetValue, True);
    ' ChgFlgLast1 := ChgFlg1Tmp;
    ' While DecrementInPorts() Do
    '   MaskInPorts(True);
    '   declare MaskedChgFlg1 := (/*##STRT 520dd150-7988-45b1-9f44-be7b16766cb8 */ ( inp )/*##END 520dd150-7988-45b1-9f44-be7b16766cb8 */ ) : Boolean;
    '   MaskInPorts(False);
    '   declare UnMaskedChgFlg1 := (/*##STRT 520dd150-7988-45b1-9f44-be7b16766cb8 */ ( inp )/*##END 520dd150-7988-45b1-9f44-be7b16766cb8 */ ) : Boolean;
    '   declare PreviousChgFlg1 := ChgFlg1 : Boolean;
    '   // A condition is 'sensitive to ports' whenever:
    '   // (1) was true so far in this execution, and
    '   // (2) is still true at this port decrement state, and
    '   // (3) would be false if we mask the ports
    '   If PreviousChgFlg1 And UnMaskedChgFlg1 And Not MaskedChgFlg1 Then
    '     // This is sensitive to ports - run it again
    '   ChgFlg1 := True;
    '     OperatedStates := "";
    '     RtsRunToCompletion(RetValue, True);
    '   End If
    ' End While
    ' ChgFlg1 := false;
    ' 
    Public Shadows Sub RunChangeEvents()
      Dim RetValue As Boolean = False
      Dim ChgFlg1Tmp As Boolean = ((inp.GetLatchedValue()))
      ChgFlg1 = EvalTrigger(ChgFlg1Tmp, ChgFlgLast1)
      OperatedStates = ""
      RtsRunToCompletion(RetValue, True)
      ChgFlgLast1 = ChgFlg1Tmp
      While DecrementInPorts()
        MaskInPorts(True)
        Dim MaskedChgFlg1 As Boolean = ((inp.GetLatchedValue()))
        MaskInPorts(False)
        Dim UnMaskedChgFlg1 As Boolean = ((inp.GetLatchedValue()))
        Dim PreviousChgFlg1 As Boolean = ChgFlg1
        'A condition is 'sensitive to ports' whenever:
        '(1) was true so far in this execution, and
        '(2) is still true at this port decrement state, and
        '(3) would be false if we mask the ports
        If PreviousChgFlg1 And UnMaskedChgFlg1 And Not MaskedChgFlg1 Then
          'This is sensitive to ports - run it again
          ChgFlg1 = True
          OperatedStates = ""
          RtsRunToCompletion(RetValue, True)
        End If
      End While
      ChgFlg1 = False
    End Sub
    
    Private Function SenseTrigger(ByVal ExprValue As Boolean, ByVal ChangeEventActive As Boolean, ByVal ThisState As String) As Boolean
      Dim Ret As Boolean = False
      If ChangeEventActive Then
        If Not OperatedStates.Contains(ThisState + "|") Then
          If ExprValue Then
            Ret = True
          End If
        End If
      End If
      Return Ret
    End Function
    
    Public Shadows Function EvalTrigger(ByVal ExprValue As Boolean, ByVal LastExprValue As Boolean) As Boolean
      Dim Ret As Boolean = False
      If ExprValue And Not LastExprValue Then
        Ret = True
      End If
      Return Ret
    End Function
    
    Public Shadows Function DecrementInPorts() As Boolean
      Dim Ret As Boolean = False
      Ret = (Ret Or inp.Decrement())
      Return Ret
    End Function
    
    Public Shadows Sub MaskInPorts(ByVal What As Boolean)
      inp.Mask(What)
      
    End Sub
    
    Public Overridable Function GetQueue() As SMSupport.SMQueue Implements SMSupport.SMQueued.GetQueue
      Return TheQueue
    End Function
    
  End Class
End Namespace
