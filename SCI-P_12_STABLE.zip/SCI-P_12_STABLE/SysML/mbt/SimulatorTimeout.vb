﻿Imports System.Reflection
Imports SySimFWK
Public Class SimulatorTimeout
	Private logicalComponent As SMSupport.SMQueued
	Private logicalCompName As String
	Private timerField As FieldInfo
	Private stable As Boolean
	Private Sub New(logicalComponent As SMSupport.SMQueued, logicalCompName As String, timerField As FieldInfo)
		Me.logicalComponent = logicalComponent
		Me.logicalCompName = logicalCompName
		Me.timerField = timerField
		stable = IsStableTimeout(Me)
	End Sub
	Public Function GetLogicalCompName() As String
		Return logicalCompName
	End Function
	Public Function GetTimerElemName() As String
		Return timerField.Name
	End Function
	Public Function IsStable() As Boolean
		Return stable
	End Function
	Public Sub Trigger()
		'We collect these objects on-demand, because they may be reassigned by their owner:
		Dim semaphore As SMSupport.RtsSemaphore = Reflect.GetFieldValue(logicalComponent, "RtsBusy", False)
		Dim currTime As SMSupport.Time = Reflect.GetFieldValue(logicalComponent, "CurrentTime", True)
		Dim timerElem As SMSupport.RtsTimer = timerField.GetValue(logicalComponent)
		SMSupport.RtsBase.RtsLock(semaphore)
		SMSupport.RtsBase.RtsStopTimer(timerElem)
		SMSupport.RtsBase.RtsStartTimer(timerElem, 0, currTime)
		SMSupport.RtsBase.RtsUnlock(semaphore)
	End Sub
	Private Shared timeouts As List(Of SimulatorTimeout) = Nothing
	Public Shared Function GetTimeouts(master As OSimMaster) As List(Of SimulatorTimeout)
		If timeouts Is Nothing Then
			timeouts = ExtractTimeouts(master)
		End If
		Return timeouts
	End Function
	Private Shared Function ExtractTimeouts(master As OSimMaster) As List(Of SimulatorTimeout)
		Dim result = New List(Of SimulatorTimeout)
		For Each f1 As FieldInfo In Reflect.GetFieldsOfType(master, GetType(SMSupport.SMQueued))
			If Not f1.Name.Equals("SMI") Then
				If Not GetType(EULYNX_Profile.Controls.PulseIndicator.PulseIndicator).IsAssignableFrom(f1.FieldType) Then
					If Not GetType(EULYNX_Profile.Controls.PulsedPortStatusBox.PulsedPortStatusBox).IsAssignableFrom(f1.FieldType) Then
						Dim logicalComponent As SMSupport.SMQueued = f1.GetValue(master)
						For Each f2 As FieldInfo In Reflect.GetFieldsOfType(logicalComponent, GetType(SMSupport.RtsTimer))
							result.Add(New SimulatorTimeout(logicalComponent, f1.Name, f2))
						Next
					End If
				End If
			End If
		Next
		Return result
	End Function
	Private Shared Function IsStableTimeout(timeout As SimulatorTimeout) As Boolean
		For Each p As TimeoutPort In TimeoutPort.GetList()
			If p.Includes(timeout.GetLogicalCompName(), timeout.GetTimerElemName()) Then
				Return True
			End If
		Next
		Return False
	End Function
End Class

