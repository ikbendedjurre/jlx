Imports System
Imports System.IO
Imports System.Text
Namespace Testing
	Public Class LoadedModel
		Private __scopes As Dictionary(Of Integer, String)
		Private __inputPorts As Dictionary(Of Integer, Port)
		Private __outputPorts As Dictionary(Of Integer, Port)
		Private __observableOutputPorts As HashSet(Of Port)
		Private __vertices As Dictionary(Of Integer, Vertex)
		Private __inputChanges As Dictionary(Of Integer, InputChanges)
		Private __outputEvolutions As Dictionary(Of Integer, OutputEvolution)
		Private __initialTransition As Transition
		'Private __initialTransitionGrp As TransitionGrp
		Private __initialTransitionTarget As Vertex
		Private __transitions As List(Of Transition)
		Private __charSets As List(Of CharSet)
		Private __tests As List(Of Trace)
		Public Class Port
			Private __name As String
			Private __ownerName As String
			Private __typeName As String
			Private __hasPulsePort As Boolean
			Private __adapterLabel As String
			Private __isEnvironmentPort As Boolean
			Private __isTimeoutPort As Boolean
			Private __executionTime As Integer
			Public Sub New(name As String, ownerName As String, typeName As String, hasPulsePort As Boolean, adapterLabel As String, isEnvironmentPort As Boolean, isTimeoutPort As Boolean, executionTime As Integer)
				__name = name
				__ownerName = ownerName
				__typeName = typeName
				__hasPulsePort = hasPulsePort
				__adapterLabel = adapterLabel
				__isEnvironmentPort = isEnvironmentPort
				__isTimeoutPort = isTimeoutPort
				__executionTime = executionTime
			End Sub
			Public Function GetName() As String
				Return __name
			End Function
			Public Function GetOwnerName() As String
				Return __ownerName
			End Function
			Public Function GetTypeName() As String
				Return __typeName
			End Function
			Public Function HasPulsePort() As Boolean
				Return __hasPulsePort
			End Function
			Public Function GetAdapterLabel() As String
				Return __adapterLabel
			End Function
			Public Function IsEnvironmentPort() As Boolean
				Return __isEnvironmentPort
			End Function
			Public Function IsTimeoutPort() As Boolean
				Return __isTimeoutPort
			End Function
			Public Function GetExecutionTime() As Integer
				Return __executionTime
			End Function
		End Class
		Public Class Vertex
			Private __statePerScope As Dictionary(Of String, String)
			Private __clzsPerScope As Dictionary(Of String, String)
			'Private __transitionGrpPerTarget As Dictionary(Of Vertex, TransitionGrp)
			Public Sub New(ByRef statePerScope As Dictionary(Of String, String), ByRef clzsPerScope As Dictionary(Of String, String))
				__statePerScope = statePerScope
				__clzsPerScope = clzsPerScope
				'__transitionGrpPerTarget = New Dictionary(Of Vertex, TransitionGrp)
			End Sub
			Public Function GetStatePerScope() As Dictionary(Of String, String)
				Return __statePerScope
			End Function
			Public Function GetClzsPerScope() As Dictionary(Of String, String)
				Return __clzsPerScope
			End Function
			'Public Function GetTransitionsPerTarget() As Dictionary(Of Vertex, TransitionGrp)
			'	Return __transitionGrpPerTarget
			'End Function
		End Class
		Public Class InputChanges
			Private __newValuePerPort As Dictionary(Of Port, String)
			Private __durationPort As Port
			Private __isHiddenTimerTrigger As Boolean
			Public Sub New(ByRef newValuePerPort As Dictionary(Of Port, String), ByRef durationPort As Port, ByRef isHiddenTimerTrigger As Boolean)
				__newValuePerPort = newValuePerPort
				__durationPort = durationPort
				__isHiddenTimerTrigger = isHiddenTimerTrigger
			End Sub
			Public Function GetNewValuePerPort() As Dictionary(Of Port, String)
				Return __newValuePerPort
			End Function
			Public Function GetDurationPort() As Port
				Return __durationPort
			End Function
			Public Function IsHiddenTimerTrigger() As Boolean
				Return __isHiddenTimerTrigger
			End Function
		End Class
		Public Class OutputEvolution
			Private __evolution As List(Of Dictionary(Of Port, String))
			Public Sub New(ByRef evolution As List(Of Dictionary(Of Port, String)))
				__evolution = evolution
			End Sub
			Public Function GetEvolution() As List(Of Dictionary(Of Port, String))
				Return __evolution
			End Function
		End Class
		'Public Class TransitionGrp
		'	Private __transitions As List(Of Transition)
		'	Private __src As Vertex
		'	Private __tgt As Vertex
		'	Public Predecessor As TransitionGrp = Nothing
		'	Public Visited As Boolean = False
		'	Public Failed As Boolean = False
		'	Public Passed As Boolean = False
		'	Public FLAG As Boolean = False
		'	Public Sub New(transitions As List(Of Transition), ByRef src As Vertex, ByRef tgt As Vertex)
		'		__transitions = transitions
		'		__src = src
		'		__tgt = tgt
		'	End Sub
		'	Public Sub New(transition As Transition, ByRef src As Vertex, ByRef tgt As Vertex)
		'		__transitions = New List(Of Transition)
		'		__transitions.Add(transition)
		'		__src = src
		'		__tgt = tgt
		'	End Sub
		'	Public Function GetTransitions() As List(Of Transition)
		'		Return __transitions
		'	End Function
		'	Public Function GetSrc() As Vertex
		'		Return __src
		'	End Function
		'	Public Function GetTgt() As Vertex
		'		Return __tgt
		'	End Function
		'	Public Function GetRandom() As Transition
		'		Dim i As Integer = CInt(Math.Floor(Rnd() * __transitions.Count))
		'		Return __transitions(i)
		'	End Function
		'End Class
		Public Class Transition
			Private __inputChanges As InputChanges
			Private __outputEvolutions As HashSet(Of OutputEvolution)
			Private __src As Vertex
			Private __tgt As Vertex
			Public Sub New(ByRef inputChanges As InputChanges, ByRef outputEvolutions As HashSet(Of OutputEvolution), ByRef src As Vertex, ByRef tgt As Vertex)
				__inputChanges = inputChanges
				__outputEvolutions = outputEvolutions
				__src = src
				__tgt = tgt
			End Sub
			Public Function GetInputChanges() As InputChanges
				Return __inputChanges
			End Function
			Public Function GetOutputEvolutions() As HashSet(Of OutputEvolution)
				Return __outputEvolutions
			End Function
			Public Function GetObservedOutputPorts() As HashSet(Of Port)
				Dim result As HashSet(Of Port) = New HashSet(Of Port)
				For Each oe In __outputEvolutions
					For Each x In oe.GetEvolution()
						result.UnionWith(x.Keys)
					Next
				Next
				Return result
			End Function
			Public Function GetSrc() As Vertex
				Return __src
			End Function
			Public Function GetTgt() As Vertex
				Return __tgt
			End Function
		End Class
		Public Class CharSet
			Private __vtx As Vertex
			Private __traces As HashSet(Of Trace)
			Public Sub New(vtx As Vertex, traces As HashSet(Of Trace))
				__vtx = vtx
				__traces = traces
			End Sub
			Public Function GetVtx() As Vertex
				Return __vtx
			End Function
			Public Function GetTraces() As HashSet(Of Trace)
				Return __traces
			End Function
		End Class
		Public Class Trace
			Private __transitions As List(Of Transition)
			Public Sub New(ByRef transitions As List(Of Transition))
				__transitions = transitions
			End Sub
			Public Function GetTransitions() As List(Of Transition)
				Return __transitions
			End Function
		End Class
		Public Sub New()
			'Empty.
		End Sub
		Public Sub LoadFromFile(ByVal fileName As String)
			Dim x As BinaryReader = New BinaryReader(File.Open(fileName, FileMode.Open), Encoding.UTF8)
			ReadFromStream(x)
			x.Close()
		End Sub
		Private Sub ReadFromStream(ByRef src As BinaryReader)
			ReadScopes(src)
			ReadInputPorts(src)
			ReadOutputPorts(src)
			ReadVertices(src)
			ReadInputChanges(src)
			ReadOutputEvolutions(src)
			ReadInitialTransition(src)
			ReadTransitions(src)
			ReadCharSets(src)
			ReadTests(src)
			SanityCheck()
			'Dim x As Integer = GetReachableTransitionCount(__initialTransitionTarget)
			'If x <> __transitions.Count Then
			'  Throw New Exception("Expected " + __transitions.Count.ToString + " reachable transitions but found " + x.ToString + "?!!")
			'End If
		End Sub
		Private Sub ReadInitialTransition(ByRef src As BinaryReader)
			Console.WriteLine("Loading initial transitions . . .")
			Dim t As Transition = ReadTransition(src, Nothing, Nothing)
			'__initialTransition = New TransitionGrp(t, Nothing, Nothing)
			__initialTransitionTarget = ResolveVertex(src)
			'__initialTransitionGrp = New TransitionGrp(New Transition(t.GetInputChanges(), t.GetOutputEvolutions()), Nothing, __initialTransitionTarget)
			__initialTransition = New Transition(t.GetInputChanges(), t.GetOutputEvolutions(), Nothing, __initialTransitionTarget)
			Console.WriteLine("Loaded 1 initial transition")
		End Sub
		Private Shared Function ReadBoolean(ByRef src As BinaryReader) As Boolean
			Dim Data() = src.ReadBytes(1)
			Array.Reverse(Data)
			Return BitConverter.ToBoolean(Data, 0)
		End Function
		Private Shared Function ReadInt(ByRef src As BinaryReader) As Integer
			Dim Data() = src.ReadBytes(4)
			Array.Reverse(Data)
			Return BitConverter.ToInt32(Data, 0)
		End Function
		Private Shared Function ReadUTF(ByRef src As BinaryReader) As String
			Dim ByteCountData() = src.ReadBytes(2)
			Array.Reverse(ByteCountData)
			Dim ByteCount = BitConverter.ToUInt16(ByteCountData, 0)
			Dim StrData() = src.ReadBytes(ByteCount)
			Dim s = Encoding.UTF8.GetString(StrData)
			'Console.WriteLine("s = " + s)
			Return s
		End Function
		Private Sub ReadScopes(ByRef src As BinaryReader)
			Console.WriteLine("Loading scopes . . .")
			Dim scopeCount As Integer = ReadInt(src)
			__scopes = New Dictionary(Of Integer, String)
			Dim i As Integer = 0
			Do While i < scopeCount
				__scopes.Add(i, ReadUTF(src))
				i = i + 1
			Loop
			Console.WriteLine("Loaded " + __scopes.Count.ToString + " scopes")
		End Sub
		Private Sub ReadInputPorts(ByRef src As BinaryReader)
			Console.WriteLine("Loading input ports . . .")
			Dim inputPortCount As Integer = ReadInt(src)
			__inputPorts = New Dictionary(Of Integer, Port)
			Dim i As Integer = 0
			Do While i < inputPortCount
				Dim name = ReadUTF(src)
				Dim ownerName = ResolveScope(src)
				Dim typeName = ReadUTF(src)
				Dim hasPulsePort = ReadInt(src) <> -1
				Dim adapterLabel = ReadUTF(src)
				Dim isEnvironmentPort = ReadBoolean(src)
				Dim isTimeoutPort = ReadBoolean(src)
				Dim executionTime = ReadInt(src)
				__inputPorts.Add(i, New Port(name, ownerName, typeName, hasPulsePort, adapterLabel, isEnvironmentPort, isTimeoutPort, executionTime))
				i = i + 1
			Loop
			Console.WriteLine("Loaded " + __inputPorts.Count.ToString + " input ports")
		End Sub
		Private Sub ReadOutputPorts(ByRef src As BinaryReader)
			Console.WriteLine("Loading output ports . . .")
			Dim outputPortCount As Integer = ReadInt(src)
			__outputPorts = New Dictionary(Of Integer, Port)
			Dim i As Integer = 0
			Do While i < outputPortCount
				Dim name = ReadUTF(src)
				Dim ownerName = ResolveScope(src)
				Dim typeName = ReadUTF(src)
				Dim hasPulsePort = ReadInt(src) <> -1
				Dim adapterLabel = ReadUTF(src)
				Dim isEnvironmentPort = ReadBoolean(src)
				Dim isTimeoutPort = ReadBoolean(src)
				Dim executionTime = ReadInt(src)
				__outputPorts.Add(i, New Port(name, ownerName, typeName, hasPulsePort, adapterLabel, isEnvironmentPort, isTimeoutPort, executionTime))
				i = i + 1
			Loop
			__observableOutputPorts = New HashSet(Of Port)
			For Each port As Port In __outputPorts.Values
				If Not (port.GetAdapterLabel().Equals("") OrElse port.HasPulsePort()) Then 'No DT-ports!!
					__observableOutputPorts.Add(port)
				End If
			Next
			Console.WriteLine("Loaded " + __outputPorts.Count.ToString + " output ports")
			Console.WriteLine("Loaded " + __observableOutputPorts.Count.ToString + " observable output ports")
		End Sub
		Private Sub ReadVertices(ByRef src As BinaryReader)
			Console.WriteLine("Loading vertices . . .")
			Dim vertexCount As Integer = ReadInt(src)
			__vertices = New Dictionary(Of Integer, Vertex)
			Dim i As Integer = 0
			Do While i < vertexCount
				Dim statePerScope As Dictionary(Of String, String) = New Dictionary(Of String, String)
				Dim j As Integer = 0
				Do While j < __scopes.Count
					Dim state As String = ReadUTF(src)
					statePerScope.Add(__scopes(j), state)
					j = j + 1
				Loop
				Dim clzsPerScope As Dictionary(Of String, String) = New Dictionary(Of String, String)
				Dim k As Integer = 0
				Do While k < __scopes.Count
					Dim clzs As String = ReadUTF(src)
					clzsPerScope.Add(__scopes(k), clzs)
					k = k + 1
				Loop
				__vertices.Add(i, New Vertex(statePerScope, clzsPerScope))
				i = i + 1
			Loop
			Console.WriteLine("Loaded " + __vertices.Count.ToString + " vertices")
		End Sub
		Private Sub ReadInputChanges(ByRef src As BinaryReader)
			Console.WriteLine("Loading input changes . . .")
			Dim inputChangesCount As Integer = ReadInt(src)
			__inputChanges = New Dictionary(Of Integer, InputChanges)
			Dim i As Integer = 0
			Do While i < inputChangesCount
				'Console.WriteLine("Loading input change " + (i + 1).ToString + " / " + inputChangesCount.ToString)
				Dim newValuePerPort As Dictionary(Of Port, String) = New Dictionary(Of Port, String)
				Dim durationPort As Port
				Dim isHiddenTimerTrigger As Boolean
				Dim newValuePerPortSize As Integer = ReadInt(src)
				Dim j As Integer = 0
				Do While j < newValuePerPortSize
					Dim port As Port = ResolveInputPort(src)
					Dim value As String = ReadValue(src)
					newValuePerPort.Add(port, value)
					j = j + 1
				Loop
				If ReadBoolean(src) Then
					durationPort = ResolveInputPort(src)
					isHiddenTimerTrigger = False
				Else
					durationPort = Nothing
					isHiddenTimerTrigger = ReadBoolean(src)
				End If
				__inputChanges.Add(i, New InputChanges(newValuePerPort, durationPort, isHiddenTimerTrigger))
				i = i + 1
			Loop
			Console.WriteLine("Loaded " + __inputChanges.Count.ToString + " input changes")
		End Sub
		Private Sub ReadOutputEvolutions(ByRef src As BinaryReader)
			Console.WriteLine("Loading output evolutions . . .")
			Dim outputEvolutionCount As Integer = ReadInt(src)
			__outputEvolutions = New Dictionary(Of Integer, OutputEvolution)
			Dim i As Integer = 0
			Do While i < outputEvolutionCount
				Dim evolution As List(Of Dictionary(Of Port, String)) = New List(Of Dictionary(Of Port, String))
				Dim evolutionLength As Integer = ReadInt(src)
				Dim j As Integer = 0
				Do While j < evolutionLength
					Dim entries As Dictionary(Of Port, String) = New Dictionary(Of Port, String)
					Dim entryCount As Integer = ReadInt(src)
					Dim k As Integer = 0
					Do While k < entryCount
						Dim port As Port = ResolveOutputPort(src)
						Dim value As String = ReadValue(src)
						entries.Add(port, value)
						k = k + 1
					Loop
					evolution.Add(entries)
					j = j + 1
				Loop
				__outputEvolutions.Add(i, New OutputEvolution(evolution))
				i = i + 1
			Loop
			Console.WriteLine("Loaded " + __outputEvolutions.Count.ToString + " output evolutions")
		End Sub
		Private Sub ReadTransitions(ByRef src As BinaryReader)
			Console.WriteLine("Loading transitions . . .")
			Dim sourceVertexCount As Integer = ReadInt(src)
			__transitions = New List(Of Transition)
			Dim totalTransitionCount = 0
			Dim i As Integer = 0
			Do While i < sourceVertexCount
				Dim v1 As Vertex = ResolveVertex(src)
				Dim targetVertexCount As Integer = ReadInt(src)
				Dim j As Integer = 0
				Do While j < targetVertexCount
					Dim v2 As Vertex = ResolveVertex(src)
					Dim transitionCount As Integer = ReadInt(src)
					'Dim transitions As List(Of Transition) = New List(Of Transition)
					Dim k As Integer = 0
					Do While k < transitionCount
						Dim t As Transition = ReadTransition(src, v1, v2)
						__transitions.Add(t)
						totalTransitionCount = totalTransitionCount + 1
						If totalTransitionCount Mod 500000 = 0 Then
							Console.WriteLine("Loaded " + totalTransitionCount.ToString + " transitions")
						End If
						k = k + 1
					Loop
					'Dim transitionGrp = New TransitionGrp(transitions, v1, v2)
					'v1.GetTransitionsPerTarget().Add(v2, transitionGrp)
					'__transitionGrps.Add(transitionGrp)
					j = j + 1
				Loop
				i = i + 1
			Loop
			Console.WriteLine("Loaded " + __transitions.Count.ToString + " transitions")
			'Console.WriteLine("Loaded " + __transitionGrps.Count.ToString + " transition groups")
		End Sub
		Private Sub ReadCharSets(ByRef src As BinaryReader)
			If Not ReadBoolean(src) Then
				Console.WriteLine("( File does not contain a char set section )")
				Return
			End If
			Console.WriteLine("Loading char sets . . .")
			Dim charSetCount As Integer = ReadInt(src)
			Dim i As Integer = 0
			Do While i < charSetCount
				ReadCharSet(src) 'Note that we do not actually store these!!
				i = i + 1
			Loop
			Console.WriteLine("Loaded " + 0.ToString + " char sets")
		End Sub
		Private Function ReadCharSet(ByRef src As BinaryReader)
			Dim vtx As Vertex = ResolveVertex(src)
			Dim traceCount As Integer = ReadInt(src)
			Dim traces As HashSet(Of Trace) = New HashSet(Of Trace)
			Dim i As Integer = 0
			Do While i < traceCount
				traces.Add(ReadTrace(src))
				i = i + 1
			Loop
			Return New CharSet(vtx, traces)
		End Function
		Private Sub ReadTests(ByRef src As BinaryReader)
			If Not ReadBoolean(src) Then
				Console.WriteLine("( File does not contain a test section )")
				Return
			End If
			Console.WriteLine("Loading tests . . .")
			Dim testCount As Integer = ReadInt(src)
			__tests = New List(Of Trace)
			Dim i As Integer = 0
			Do While i < testCount
				__tests.Add(ReadTest(src))
				i = i + 1
				If __tests.Count Mod 10000 = 0 Then
					Console.WriteLine("Loaded " + __tests.Count.ToString + " tests")
				End If
			Loop
			Console.WriteLine("Loaded " + __tests.Count.ToString + " tests")
		End Sub
		Private Function ReadTrace(ByRef src As BinaryReader)
			Dim transitionCount As Integer = ReadInt(src)
			Dim transitions As List(Of Transition) = New List(Of Transition)
			Dim i As Integer = 0
			Do While i < transitionCount
				transitions.Add(ResolveTransition(src))
				i = i + 1
			Loop
			Return New Trace(transitions)
		End Function
		Private Function ReadTest(ByRef src As BinaryReader)
			Return ReadTrace(src)
		End Function
		Private Function ReadValue(ByRef src As BinaryReader) As String
			Dim s = ReadUTF(src) '.Replace("""", "")
			Dim s2 = s.Substring(1, s.Length - 2)
			'Console.WriteLine("Reading " + s + " -> " + s2)
			Return s2
		End Function
		Private Function ResolveScope(ByRef src As BinaryReader) As String
			Dim result As String = __scopes(ReadInt(src))
			If result Is Nothing Then
				Throw New Exception("Should not happen!")
			End If
			Return result
		End Function
		Private Function ResolveInputPort(ByRef src As BinaryReader) As Port
			Dim result As Port = Nothing
			Dim i As Integer = ReadInt(src)
			If __inputPorts.TryGetValue(i, result) Then
				Return result
			End If
			Throw New Exception("Should not happen, " + i.ToString + " is not in [0 .. " + __inputPorts.Count.ToString + ">!")
		End Function
		Private Function ResolveOutputPort(ByRef src As BinaryReader) As Port
			Dim result As Port = Nothing
			Dim i As Integer = ReadInt(src)
			If __outputPorts.TryGetValue(i, result) Then
				Return result
			End If
			Throw New Exception("Should not happen, " + i.ToString + " is not in [0 .. " + __outputPorts.Count.ToString + ">!")
		End Function
		Private Function ResolveVertex(ByRef src As BinaryReader) As Vertex
			Dim result As Vertex = Nothing
			Dim i As Integer = ReadInt(src)
			If __vertices.TryGetValue(i, result) Then
				Return result
			End If
			Throw New Exception("Should not happen, " + i.ToString + " is not in [0 .. " + __vertices.Count.ToString + ">!")
		End Function
		Private Function ReadTransition(ByRef src As BinaryReader, ByRef v1 As Vertex, ByRef v2 As Vertex) As Transition
			Dim dataSize As Integer = ReadInt(src)
			If dataSize > 100 Then
				Throw New Exception("Transition size is larger than it should be!!")
			End If
			'Console.WriteLine("dataSize = " + dataSize.ToString)
			Dim data As List(Of Integer) = New List(Of Integer) 'Because I do not understand arrays
			Dim i As Integer = 0
			Do While i < dataSize
				data.Add(ReadInt(src))
				i = i + 1
			Loop
			Dim ic As InputChanges = __inputChanges(data(0))
			If ic Is Nothing Then
				Throw New Exception("Should not happen; could not find input change " + data(0).ToString + "!")
			End If
			Dim aes As HashSet(Of OutputEvolution) = New HashSet(Of OutputEvolution)
			Dim j As Integer = 1
			Do While j < dataSize
				Dim ae As OutputEvolution = __outputEvolutions(data(j))
				If ae Is Nothing Then
					Throw New Exception("Should not happen; could not find output evolution " + data(j).ToString + "!")
				End If
				If ae.GetEvolution().Count > 1 Then
					aes.Add(ae)
				End If
				j = j + 1
			Loop
			Return New Transition(ic, aes, v1, v2)
		End Function
		Private Function ResolveTransition(ByRef src As BinaryReader) As Transition
			Dim i As Integer = ReadInt(src)
			If i = -1 Then
				Return __initialTransition
			End If
			If i < 0 OrElse i >= __transitions.Count Then
				Throw New Exception("Should not happen, " + i.ToString + " is not in [0 .. " + __transitions.Count.ToString + ">!")
			End If
			Return __transitions(i)
		End Function
		Private Sub SanityCheck()
			'For Each t In __transitionGrps
			'  t.Visited = False
			'Next
			'Dim fringe As HashSet(Of Vertex) = New HashSet(Of Vertex)
			'  Dim newFringe As HashSet(Of Vertex) = New HashSet(Of Vertex)
			'  fringe.Add(__initialTransitionTarget)
			'  While fringe.Count > 0
			'    newFringe.Clear()

			'    For Each v In fringe
			'      For Each e In v.GetTransitionsPerTarget()
			'        For Each t2 In e.Value
			'          If Not t2.Visited Then
			'            t2.Visited = True
			'            newFringe.Add(e.Key)
			'          End If
			'        Next
			'      Next
			'    Next

			'    fringe.Clear()
			'    fringe.UnionWith(newFringe)
			'  End While
			'  For Each t In __transitions
			'    If Not t.Visited Then
			'      Throw New Exception("Unreachable transitions?!!")
			'    End If
			'  Next
			'  For Each t In __transitions
			'    t.Visited = False
			'  Next
		End Sub
		'Public Function GetReachableTransitionCount(initVertex As Vertex) As Integer
		'  For Each t In __transitions
		'    t.FLAG = False
		'  Next
		'  Dim fringe As HashSet(Of Vertex) = New HashSet(Of Vertex)
		'  Dim newFringe As HashSet(Of Vertex) = New HashSet(Of Vertex)
		'  fringe.Add(initVertex)
		'  While fringe.Count > 0
		'    newFringe.Clear()

		'    For Each v In fringe
		'      For Each e In v.GetTransitionsPerTarget()
		'        For Each t2 In e.Value
		'          If Not t2.FLAG Then
		'            t2.FLAG = True
		'            newFringe.Add(e.Key)
		'          End If
		'        Next
		'      Next
		'    Next

		'    fringe.Clear()
		'    fringe.UnionWith(newFringe)
		'  End While
		'  Dim result As Integer = 0
		'  For Each t In __transitions
		'    If t.FLAG Then
		'      result = result + 1
		'      t.FLAG = False
		'    End If
		'  Next
		'  Return result
		'End Function
		'Public Function GetReachableTransitionCount2(initVertex As Vertex) As Integer
		'  For Each t In __transitions
		'    t.FLAG = False
		'  Next
		'  Dim fringe As HashSet(Of Vertex) = New HashSet(Of Vertex)
		'  Dim newFringe As HashSet(Of Vertex) = New HashSet(Of Vertex)
		'  fringe.Add(initVertex)
		'  While fringe.Count > 0
		'    newFringe.Clear()

		'    For Each v In fringe
		'      For Each e In v.GetTransitionsPerTarget()
		'        For Each t2 In e.Value
		'          If Not t2.FLAG Then
		'            t2.FLAG = True
		'            newFringe.Add(e.Key)
		'          End If
		'        Next
		'      Next
		'    Next

		'    fringe.Clear()
		'    fringe.UnionWith(newFringe)
		'  End While
		'  Dim result As Integer = 0
		'  For Each t In __transitions
		'    If t.FLAG AndAlso Not t.Visited Then
		'      result = result + 1
		'      t.FLAG = False
		'    End If
		'  Next
		'  Return result
		'End Function
		Public Function GetScopes() As Dictionary(Of Integer, String)
			Return __scopes
		End Function
		Public Function GetInputPorts() As Dictionary(Of Integer, Port)
			Return __inputPorts
		End Function
		Public Function GetOutputPorts() As Dictionary(Of Integer, Port)
			Return __outputPorts
		End Function
		Public Function GetObservableOutputPorts() As HashSet(Of Port)
			Return __observableOutputPorts
		End Function
		Public Function GetVertices() As Dictionary(Of Integer, Vertex)
			Return __vertices
		End Function
		Public Function GetInputChanges() As Dictionary(Of Integer, InputChanges)
			Return __inputChanges
		End Function
		Public Function GetOutputEvolutions() As Dictionary(Of Integer, OutputEvolution)
			Return __outputEvolutions
		End Function
		Public Function GetInitialTransition() As Transition
			Return __initialTransition
		End Function
		Public Function GetInitialTransitionTarget() As Vertex
			Return __initialTransitionTarget
		End Function
		Public Function GetTransitions() As List(Of Transition)
			Return __transitions
		End Function
		Public Function GetTests() As List(Of Trace)
			Return __tests
		End Function
	End Class
End Namespace