﻿Public Class PortValuePair
	Private port As OutputPort
	Private value As String
	Public Sub New(port As OutputPort, value As String)
		Me.port = port
		Me.value = value
	End Sub
	Public Sub New(portName As String, value As String)
		port = OutputPort.FindInGUI(portName)
		Me.value = value
	End Sub
	Public Function GetPort() As OutputPort
		Return port
	End Function
	Public Function GetValue() As String
		Return value
	End Function
	Public Function ToText() As String
		Return "(" + port.description + ", " + value + ")"
	End Function
End Class
