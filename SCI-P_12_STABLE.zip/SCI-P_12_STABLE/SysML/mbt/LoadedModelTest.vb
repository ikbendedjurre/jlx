﻿Namespace Testing
	Public Class LoadedModelTest
		Implements Test
		Private __testName As String
		Private __model As LoadedModel
		Private __trace As LoadedModel.Trace
		Public Sub New(testName As String, model As LoadedModel, trace As LoadedModel.Trace)
			__testName = testName
			__model = model
			__trace = trace
		End Sub
		Public Function GetStepCount() As Integer Implements Test.GetStepCount
			Return __trace.GetTransitions().Count
		End Function
		Public Sub Run(api As TestAPI) Implements Test.Run
			api.StartNewTest(__testName)
			api.Log("Test " + __testName + ", Initialization:")
			ApplyTransition(api, __trace.GetTransitions()(0))
			api.Stabilize()

			For i As Integer = 1 To __trace.GetTransitions().Count - 1
				api.Log("Test " + __testName + ", Step " + i.ToString + ":")
				ApplyTransition(api, __trace.GetTransitions()(i))
				api.Stabilize()
			Next
		End Sub
		'Private Function GetPathViaNearestUnvisited(curr As LoadedModel.TransitionGrp) As List(Of LoadedModel.TransitionGrp)
		'	For Each t In __model.GetTransitionGrps()
		'		t.Predecessor = Nothing
		'	Next
		'	curr.Predecessor = curr
		'	__model.GetInitialTransitionGrp().Predecessor = __model.GetInitialTransitionGrp()
		'	Dim fringe As List(Of LoadedModel.TransitionGrp) = New List(Of LoadedModel.TransitionGrp)
		'	Dim newFringe As List(Of LoadedModel.TransitionGrp) = New List(Of LoadedModel.TransitionGrp)
		'	fringe.Add(curr)
		'	fringe.Add(__model.GetInitialTransitionGrp())
		'	While fringe.Count > 0
		'		newFringe.Clear()

		'		For Each t1 As LoadedModel.TransitionGrp In fringe
		'			If Not t1.Visited Then
		'				Dim result As List(Of LoadedModel.TransitionGrp) = New List(Of LoadedModel.TransitionGrp)
		'				Dim last As LoadedModel.TransitionGrp = t1
		'				result.Add(t1)
		'				While last IsNot curr AndAlso last IsNot __model.GetInitialTransitionGrp()
		'					result.Add(last.Predecessor)
		'					last = last.Predecessor
		'				End While
		'				result.Reverse()
		'				Return result
		'			End If

		'			For Each e In t1.GetTgt().GetTransitionsPerTarget()
		'				If e.Value.Predecessor Is Nothing Then
		'					e.Value.Predecessor = t1
		'					newFringe.Add(e.Value)
		'				End If
		'			Next
		'		Next

		'		fringe.Clear()
		'		fringe.AddRange(newFringe)
		'	End While
		'	Dim untestedCount As Integer = 0
		'	For Each t In __model.GetTransitionGrps()
		'		If Not t.Visited Then
		'			If t.Predecessor IsNot Nothing Then
		'				Throw New Exception("Should not happen!")
		'			End If
		'			untestedCount = untestedCount + 1
		'		End If
		'	Next
		'	'Dim x1 As Integer = __model.GetReachableTransitionCount(__model.GetInitialTransitionTarget())
		'	'Dim y1 As Integer = __model.GetReachableTransitionCount(curr.GetTgt())
		'	'Dim x2 As Integer = __model.GetReachableTransitionCount2(__model.GetInitialTransitionTarget())
		'	'Dim y2 As Integer = __model.GetReachableTransitionCount2(curr.GetTgt())
		'	'Throw New Exception("Should not happen, could not find path to one of " + untestedCount.ToString + " non-visited transitions (" + x1.ToString + "(" + x2.ToString + ")/" + y1.ToString + "(" + y1.ToString + ") reachable from init/curr)!")
		'	Throw New Exception("Should not happen!")
		'End Function
		Private Sub ApplyTransition(api As TestAPI, transition As LoadedModel.Transition)
			If transition.GetSrc() Is Nothing Then
				For Each e In __model.GetScopes()
					'Console.WriteLine("#scopes = " + transition.GetTgt().GetClzsPerScope().Count.ToString)
					'For Each e2 In transition.GetTgt().GetClzsPerScope()
					'	Console.WriteLine(e2.Key.ToString + " = " + e2.Value.ToString)
					'Next
					'Console.WriteLine("key = " + e.Key.ToString)
					Dim v2 As String = transition.GetTgt().GetClzsPerScope()(e.Value)
					api.Log("  " + e.Value + " starts in " + v2)
				Next
			Else
				For Each e In __model.GetScopes()
					Dim v1 As String = transition.GetSrc().GetClzsPerScope()(e.Value)
					Dim v2 As String = transition.GetTgt().GetClzsPerScope()(e.Value)
					If v2.Equals(v1) Then
						api.Log("  " + e.Value + " should stay in " + v1)
					Else
						api.Log("  " + e.Value + " should move from " + v1 + " to " + v2)
					End If
				Next
			End If
			'Console.WriteLine("2")
			ApplyInputChanges(api, transition.GetInputChanges())
			'Console.WriteLine("3")
			ApplyOutputEvolutions(api, transition.GetOutputEvolutions())
			'Console.WriteLine("4")
			Dim unobservedOutputPorts As HashSet(Of LoadedModel.Port) = New HashSet(Of LoadedModel.Port)
			unobservedOutputPorts.UnionWith(__model.GetObservableOutputPorts())
			unobservedOutputPorts.ExceptWith(transition.GetObservedOutputPorts())
			'Console.WriteLine("5")
			For Each port In unobservedOutputPorts
				api.ExpectUnchangingOutput(port.GetAdapterLabel())
			Next
			'Console.WriteLine("6")
		End Sub
		Private Sub ApplyInputChanges(api As TestAPI, inputChanges As LoadedModel.InputChanges)
			If inputChanges.IsHiddenTimerTrigger() Then
				'api.TriggerHiddenTimeouts()
				Return
			End If
			If inputChanges.GetDurationPort() IsNot Nothing Then
				ConfirmLabeled(inputChanges.GetDurationPort(), "timeout port")
				api.TriggerTimeout(inputChanges.GetDurationPort().GetAdapterLabel())
			End If
			For Each x In inputChanges.GetNewValuePerPort()
				ConfirmLabeled(x.Key, "input port")
				api.SetInput(x.Key.GetAdapterLabel(), x.Value)
			Next
		End Sub
		Private Sub ConfirmLabeled(port As LoadedModel.Port, portType As String)
			If port.GetAdapterLabel().Equals("") Then
				Throw New Exception("Unlabeled " + portType + ": " + port.GetOwnerName() + "::" + port.GetName())
			End If
		End Sub
		Private Sub ApplyOutputEvolutions(api As TestAPI, outputEvolutions As HashSet(Of LoadedModel.OutputEvolution))
			For Each outputEvolution In outputEvolutions
				ApplyOutputEvolution(api, outputEvolution)
			Next
		End Sub
		Private Sub ApplyOutputEvolution(api As TestAPI, outputEvolution As LoadedModel.OutputEvolution)
			Dim x = ToListOfPortValuePairs(outputEvolution.GetEvolution())
			If x.Count > 0 Then 'TODO monitor unchanging outputs!!
				api.ExpectOutputs(x.ToArray())
			End If
		End Sub
		Private Function ToListOfPortValuePairs(outputs As List(Of Dictionary(Of LoadedModel.Port, String))) As List(Of PortValuePairs)
			Dim grps As List(Of PortValuePairs) = New List(Of PortValuePairs)
			For Each x In outputs
				Dim y As PortValuePairs = ToPortValuePairs(x)
				If y.GetPairs().Length > 0 Then
					grps.Add(y)
				End If
			Next
			Return grps
		End Function
		Private Shared Function ToPortValuePairs(outputs As Dictionary(Of LoadedModel.Port, String)) As PortValuePairs
			Dim pairs As List(Of PortValuePair) = New List(Of PortValuePair)
			For Each x In outputs
				If x.Key.GetAdapterLabel().Equals("") Then
					'Do nothing.
				Else
					pairs.Add(New PortValuePair(x.Key.GetAdapterLabel(), x.Value))
				End If
			Next
			Return New PortValuePairs(pairs.ToArray())
		End Function
	End Class
End Namespace
