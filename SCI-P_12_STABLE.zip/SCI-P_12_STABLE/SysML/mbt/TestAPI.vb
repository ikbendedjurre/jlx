﻿Imports System.IO
Namespace Testing
	Public Class TestAPI
		Private inputs As Dictionary(Of String, String)
		Private expectedSeqs As List(Of PortValuePairs())
		Private expectedOutputEvolutions As Dictionary(Of OutputPort, List(Of String))
		Private lastSeenOutputs As Dictionary(Of OutputPort, String)
		Private loggedLines As List(Of String)
		Private discrepancies As HashSet(Of TestDiscrepancy)
		Private f As SIMULATOR.SubS_P_SRForm
		Private stabilizationCount As Integer
		Private prefix As String
		Private doneStepCount As Integer
		Private totalStepCount As Integer
		Public Sub New(stabilizationCount As Integer)
			Console.Write("Initializing simulator...")
			inputs = New Dictionary(Of String, String)
			expectedOutputEvolutions = New Dictionary(Of OutputPort, List(Of String))
			expectedSeqs = New List(Of PortValuePairs())
			lastSeenOutputs = New Dictionary(Of OutputPort, String)
			loggedLines = New List(Of String)
			discrepancies = New HashSet(Of TestDiscrepancy)
			f = New SIMULATOR.SubS_P_SRForm()
			f.Reset() '(Doing this for the first time takes quite long, it looks nicer if we do it before the first test!)
			Console.WriteLine(" done!")
			Me.stabilizationCount = stabilizationCount
			prefix = ""
			doneStepCount = 0
			totalStepCount = 1
		End Sub
		Public Sub SetStepCounts(doneStepCount As Integer, totalStepCount As Integer)
			Me.doneStepCount = doneStepCount
			Me.totalStepCount = totalStepCount
		End Sub
		Public Sub SetPrefix(prefix As String)
			Me.prefix = prefix
		End Sub
		Public Sub StartNewTest(testName As String)
			Console.WriteLine("Starting test " + testName)
			f.Reset()
			f.DoSimStep() '(Otherwise, GUI elements may not have taken on the simulation value yet.)
			expectedSeqs.Clear()
			expectedOutputEvolutions.Clear()
			lastSeenOutputs.Clear()
			loggedLines.Clear()
			loggedLines.Add("Test ID: " + testName)
			discrepancies.Clear()
			UpdateLastSeenOutputs()
		End Sub
		Private f1 As Boolean
		Private f2 As Boolean
		Private Function UpdateLastSeenOutputs() As Boolean
			Dim observedChange As Boolean = False
			Dim newSeenOutputs = New Dictionary(Of OutputPort, String)
			For Each x In Adapter.GetLastSeenOutputValues()
				Dim v As String = Nothing
				If lastSeenOutputs.TryGetValue(x.Key, v) Then
					If x.Value.Equals(v) Then
						'Do nothing.
						'Log("  " + x.Key.description + " is still " + v)
					Else
						Log("  " + x.Key.description + " changed from " + v + " to " + x.Value)
						If x.Key.description.Equals("(prim, T8_Cd_Initialisation_Request)") Then
							If x.Value.ToLower.Equals("true") Then
								f1 = False
							End If
						End If
						If x.Key.description.Equals("(sp, T20_Point_Position)") Then
							If x.Value.ToLower.Equals("true") Then
								f2 = True
							End If
						End If
						observedChange = True
					End If
				End If
				newSeenOutputs.Add(x.Key, x.Value)
			Next
			lastSeenOutputs = newSeenOutputs
			Return observedChange
		End Function
		Public Sub TriggerTimeout(PortId As String)
			TriggerTimeout(TimeoutPort.FindInGUI(PortId))
		End Sub
		Public Sub TriggerTimeout(Port As TimeoutPort)
			Log(" Triggering timeout " + Port.description)
			Adapter.TriggerTimeout(f.GetMaster(), Port)
		End Sub
		Public Sub TriggerTimeout(Ports As HashSet(Of TimeoutPort))
			For Each Port In Ports
				TriggerTimeout(Port)
			Next
		End Sub
		Public Sub TriggerHiddenTimeouts()
			Log(" Triggering unregistered timeouts")
			Adapter.TriggerUnregisteredTimeouts(f.GetMaster())
		End Sub
		Public Sub SetInput(PortId As String, Value As String)
			SetInput(InputPort.FindInGUI(PortId), Value)
		End Sub
		Public Sub SetInput(Port As InputPort, Value As String)
			Log(" Setting " + Port.description + " to " + Value)
			inputs(Port.description) = Value
			Adapter.SetInput(f, Port, Value)
		End Sub
		Public Sub SetInput(Ports As HashSet(Of InputPort), Value As String)
			For Each Port In Ports
				SetInput(Port, Value)
			Next
		End Sub
		Public Sub ExpectOutputs(ParamArray ByVal expectedSeq() As PortValuePairs)
			expectedSeqs.Add(expectedSeq)
		End Sub
		Public Sub ExpectOutputs(PortId As String, ByVal ParamArray Values() As String)
			ExpectOutputs(OutputPort.FindInGUI(PortId), Values)
		End Sub
		Public Sub ExpectOutputs(Port As OutputPort, ByVal ParamArray Values() As String)
			Dim L As List(Of String) = New List(Of String)
			For Each V In Values
				L.Add(V)
			Next
			expectedOutputEvolutions(Port) = L
		End Sub
		Public Sub ExpectUnchangingOutput(PortId As String)
			ExpectUnchangingOutput(OutputPort.FindInGUI(PortId))
		End Sub
		Public Sub ExpectUnchangingOutput(Port As OutputPort)
			Dim L As List(Of String) = New List(Of String)
			L.Add(lastSeenOutputs(Port))
			expectedOutputEvolutions(Port) = L
		End Sub
		Public Sub Log(line As String)
			Dim s As String = String.Format("{0:0.00}%", 100.0 * doneStepCount / totalStepCount)
			Console.WriteLine(prefix + "[" + s + "][" + f.GetTimeStr() + "] " + line)
			loggedLines.Add("[" + f.GetTimeStr() + "] " + line)
		End Sub
		Private Sub AddDisprepancy(header As String, expected As String, found As String)
			Log(header + ":")
			Log("  Expected: " + expected)
			Log("  Observed: " + found)
			discrepancies.Add(New TestDiscrepancy(header, expected, found))
		End Sub
		Public Sub Stabilize()
			Log(" Stabilizing:")

			Dim observers As List(Of Observer) = New List(Of Observer)
			For Each expectedSeq In expectedSeqs
				observers.Add(New Observer(expectedSeq))
			Next

			f1 = True
			f2 = False
			Dim observedChange As Boolean = False
			For Index As Integer = 1 To stabilizationCount
				f.DoSimStep()

				If UpdateLastSeenOutputs() Then
					observedChange = True
				End If

				For Each observer In observers
					observer.Observe(lastSeenOutputs)
				Next

				Dim failed As Boolean = False
				For Each observer In observers
					If observer.HasFailed() Then
						AddDisprepancy("Unexpected output evolution", observer.GetExpectationText(), observer.GetFoundText(lastSeenOutputs))
						failed = True
					End If
				Next
				If failed Then
					Log("One or more outputs evolved in an unexpected manner!")
					Throw New ConformanceException("One or more outputs evolved in an unexpected manner!")
				End If
			Next
			If f1 AndAlso f2 Then
				Dim x As String = ""
				If inputs.TryGetValue("(sp, T10_Move_Point)", x) Then
					If x.ToLower.Equals("true") Then
						Throw New Exception("Found T1, T20, and not T8!")
					End If
				End If
			End If
			If Not observedChange Then
				Log("  no changes observed")
			End If

			Dim incomplete As Boolean = False
			For Each observer In observers
				If Not observer.IsDone() Then
					AddDisprepancy("Incomplete output evolution", observer.GetExpectationText(), observer.GetFoundText())
					incomplete = True
				End If
			Next
			If incomplete Then
				Log("One or more outputs did not evolve completely!")
				Throw New ConformanceException("One or more outputs did not evolve completely!")
			End If

			doneStepCount = doneStepCount + 1
			inputs.Clear()
			expectedSeqs.Clear()
		End Sub
		Public Function GetLastSeenOutputValues() As Dictionary(Of OutputPort, String)
			Return lastSeenOutputs
		End Function
		Public Sub SaveLog(filename As String)
			Dim out As New System.IO.StreamWriter(filename, False)
			For Each loggedLine In loggedLines
				out.WriteLine(loggedLine)
			Next
			out.Close()
		End Sub
		Public Function GetDiscrepancies() As HashSet(Of TestDiscrepancy)
			Return discrepancies
		End Function
	End Class
End Namespace
