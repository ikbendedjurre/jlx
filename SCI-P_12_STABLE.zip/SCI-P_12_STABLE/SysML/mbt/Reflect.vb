﻿Imports System.Reflection
Class Reflect
	Private Shared Sub AddFieldsOfType(x As Type, t As Type, dest As List(Of FieldInfo))
		If x Is GetType(Object) Then
			Return
		End If
		For Each f As FieldInfo In x.GetFields(BindingFlags.Instance Or BindingFlags.NonPublic)
			If t.IsAssignableFrom(f.FieldType) Then
				dest.Add(f)
			End If
		Next
		AddFieldsOfType(x.BaseType, t, dest)
	End Sub
	Public Shared Function GetFieldsOfType(x As Object, t As Type) As List(Of FieldInfo)
		Dim fields As List(Of FieldInfo) = New List(Of FieldInfo)
		AddFieldsOfType(x.GetType(), t, fields)
		Return fields
	End Function
	Private Shared Sub PrintFields(t As Type)
		Console.WriteLine("FIELDS OF TYPE " + t.FullName)
		For Each x In t.GetFields(BindingFlags.Instance Or BindingFlags.NonPublic)
			Console.WriteLine(x.Name + " : " + x.FieldType.Name)
		Next
	End Sub
	Private Shared Function GetField(t As Type, fieldName As String) As FieldInfo
		If t Is GetType(Object) Then
			PrintFields(t)
			Return Nothing
		End If
		Dim result As FieldInfo = t.GetField(fieldName, BindingFlags.Instance Or BindingFlags.NonPublic)
		If result IsNot Nothing Then
			Return result
		End If
		result = GetField(t.BaseType, fieldName)
		If result IsNot Nothing Then
			Return result
		End If
		PrintFields(t)
		Return Nothing
	End Function
	Public Shared Function GetFieldValue(x As Object, fieldName As String, confirmNotNothing As Boolean) As Object
		Dim fieldInfo As FieldInfo = GetField(x.GetType(), fieldName)
		If fieldInfo Is Nothing Then
			Throw New Exception("Could not find """ + x.GetType.FullName + "::" + fieldName + """!")
		End If
		Dim result As Object = fieldInfo.GetValue(x)
		If confirmNotNothing Then
			If result Is Nothing Then
				Throw New Exception("No value is stored in """ + x.GetType.FullName + "::" + fieldName + """!")
			End If
		End If
		Return result
	End Function
End Class

