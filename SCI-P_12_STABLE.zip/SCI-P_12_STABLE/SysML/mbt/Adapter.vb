Imports System
Imports System.Reflection
Imports EULYNX_Profile.Controls
Imports EULYNX_Profile.Controls.BoolIndicator
Imports EULYNX_Profile.Controls.BoolSlider
Imports EULYNX_Profile.Controls.InputIntegerBox
Imports EULYNX_Profile.Controls.InputComboBox
Imports EULYNX_Profile.Controls.InputTextBox
Imports EULYNX_Profile.Controls.OutputTextBox
Imports EULYNX_Profile.Controls.PulseButton
Imports EULYNX_Profile.Controls.PulsedPortStatusBox
Imports EULYNX_Profile.Controls.PulseIndicator
Imports SIMULATOR
Imports SySimFWK

Module Adapter
	Private Enabled As Boolean = False
	Public Sub Enable()
		Enabled = True
	End Sub
	Public Sub Disable()
		'Reset input data fields of the simulator:
		For Each startingInput In startingInputs
			SetInput(form, startingInput.Key, startingInput.Value)
		Next

		Outputs.Clear()
		LastSeenOutputValues = InitLastSeenOutputs()
		Enabled = False
	End Sub
	Private form As PredefinedControls.OFormBase = Nothing
	'Inputs that were found when the simulator was booted for the first time
	Private startingInputs As Dictionary(Of InputPort, String) = Nothing
	Private Sub PrintFields(t As Type)
		Console.WriteLine("FIELDS OF TYPE " + t.FullName)

		For Each x In t.GetFields(BindingFlags.Instance Or BindingFlags.NonPublic)
			Console.WriteLine(x.Name + " : " + x.FieldType.Name)
		Next
	End Sub
	Private Sub PrintFields(x As Object)
		PrintFields(x.GetType)
	End Sub
	Private Function GetInheritedPrivateField(t As Type, fieldName As String) As FieldInfo
		If t Is GetType(Object) Then
			PrintFields(t)
			Return Nothing
		End If
		Dim result As FieldInfo = t.GetField(fieldName, BindingFlags.Instance Or BindingFlags.NonPublic)
		If result IsNot Nothing Then
			Return result
		End If
		result = GetInheritedPrivateField(t.BaseType, fieldName)
		If result IsNot Nothing Then
			Return result
		End If
		PrintFields(t)
		Return Nothing
	End Function
	Private Function GetInheritedPrivateFieldValue(x As Object, fieldName As String) As Object
		Dim fieldInfo As FieldInfo = GetInheritedPrivateField(x.GetType(), fieldName)
		If fieldInfo Is Nothing Then
			Throw New Exception("Could not find """ + x.GetType.FullName + "::" + fieldName + """!")
		End If
		Dim result As Object = fieldInfo.GetValue(x)
		'If result Is Nothing Then
		'	Throw New Exception("No value is stored in """ + x.GetType.FullName + "::" + fieldName + """!")
		'End If
		Return result
	End Function
	Public Sub LocalizeGUIElems(form As PredefinedControls.OFormBase, master As OSimMaster)
		If form Is Nothing Then
			Throw New Exception("Should not happen!")
		End If
		Adapter.form = form
		If form.GetType() Is Nothing Then
			Throw New Exception("Should not happen!")
		End If
		'Main.LOG.Write("JLXAdapter", "Locating simulator components...")
		For Each def As TimeoutPort In TimeoutPort.GetList()
			Dim logicalComponent As SMSupport.SMQueued = Reflect.GetFieldValue(master, def.logicalCompName, True)
			Dim semaphore As SMSupport.RtsSemaphore = Reflect.GetFieldValue(logicalComponent, "RtsBusy", False)
			Dim currTime As SMSupport.Time = Reflect.GetFieldValue(logicalComponent, "CurrentTime", True)
			For Each timerElementName As String In def.timerElemNames
				Dim timerElement As SMSupport.RtsTimer = Reflect.GetFieldValue(logicalComponent, timerElementName, False)
			Next
		Next
		For Each def As InputPort In InputPort.GetList()
			'Note that a Friend WithEvents field X become a property X backed by a field _X:
			Dim f As FieldInfo = form.GetType().GetField("_" + def.guiElemName, BindingFlags.Instance Or BindingFlags.NonPublic)
			If f Is Nothing Then
				PrintFields(form)
				Throw New Exception("Could not find simulator component: ""_" + def.guiElemName + """")
			End If
			Dim resolvedField = f.GetValue(form)
			If resolvedField Is Nothing Then
				Throw New Exception("Found simulator component without a value: ""_" + def.guiElemName + """")
			End If
			'Main.LOG.Write("JLXAdapter", "  Found simulator component: _" + def(2))
		Next
		For Each def As OutputPort In OutputPort.GetList()
			'Note that a Friend WithEvents field X become a property X backed by a field _X:
			Dim f As FieldInfo = form.GetType().GetField("_" + def.guiElemName, BindingFlags.Instance Or BindingFlags.NonPublic)
			If f Is Nothing Then
				PrintFields(form)
				Throw New Exception("Could not find simulator component: ""_" + def.guiElemName + """")
			End If
			Dim resolvedField = f.GetValue(form)
			If resolvedField Is Nothing Then
				Throw New Exception("Found simulator component without a value: ""_" + def.guiElemName + """")
			End If
			'Main.LOG.Write("JLXAdapter", "  Found simulator component: _" + def(2))
		Next
		'Main.LOG.Write("JLXAdapter", "Found all simulator components!")
		startingInputs = GetStartingInputValues()
		'Main.LOG.Write("JLXAdapter", "Found " + resetEvents.Count.ToString + " simulation reset events!")
	End Sub
	Private Outputs As List(Of String) = New List(Of String)
	Public Function DequeueOutput(ByRef Output As String) As Boolean
		If Outputs.Count > 0 Then
			Output = Outputs(0)
			Outputs.RemoveAt(0)
			Return True
		End If
		Return False
	End Function
	Public Sub ReportOutput(guiElem As BoolIndicator, output As Boolean)
		UpdateLastSeenOutputValue(guiElem, If(output, "true", "false"))
	End Sub
	Public Sub ReportOutput(guiElem As PulseIndicator, output As Boolean)
		UpdateLastSeenOutputValue(guiElem, If(output, "true", "false"))
	End Sub
	Public Sub ReportOutput(guiElem As OutputTextBox, output As String)
		UpdateLastSeenOutputValue(guiElem, output)
	End Sub
	Public Sub ReportOutput(guiElem As PulsedPortStatusBox, output As Boolean)
		UpdateLastSeenOutputValue(guiElem, If(output, "true", "false"))
	End Sub
	Private LastSeenOutputValues As Dictionary(Of OutputPort, String) = InitLastSeenOutputs()
	Private Function InitLastSeenOutputs() As Dictionary(Of OutputPort, String)
		Dim result As Dictionary(Of OutputPort, String) = New Dictionary(Of OutputPort, String)
		For Each def As OutputPort In OutputPort.GetList()
			result.Add(def, GetDefaultOutputValue(def))
		Next
		Return result
	End Function
	Public Function GetLastSeenOutputValues() As Dictionary(Of OutputPort, String)
		Dim result As Dictionary(Of OutputPort, String) = New Dictionary(Of OutputPort, String)
		For Each x In LastSeenOutputValues
			result.Add(x.Key, x.Value)
		Next
		Return result
	End Function
	Private Sub UpdateLastSeenOutputValue(guiElem As Control, output As String)
		Dim def = GetDef(guiElem)
		If def Is Nothing Then
			If guiElem.Name.Length > 0 Then
				'Main.LOG.Write("JLXAdapter", "[" + form.GetTimeStr() + "] INTERNAL: " + guiElem.Name + " changed from """ + oldOutput + """ to """ + output + """")
			Else
				'Main.LOG.Write("JLXAdapter", "[" + form.GetTimeStr() + "] INTERNAL: " + guiElem.GetType().FullName + " changed from """ + oldOutput + """ to """ + output + """")
			End If
			'Console.WriteLine("( " + guiElem.Name + "/" + guiElem.Text + " -> " + output + " was ignored by adapter )")
		Else
			LastSeenOutputValues(def) = output
		End If
	End Sub
	Private Function GetDefaultOutputValue(def As OutputPort) As String
		Select Case def.dataType
			Case "PULSE"
				Return "FALSE"
			Case "BOOLEAN"
				Return "FALSE"
			Case "NUMBER"
				Return "0"
			Case "STRING"
				Return ""
			Case Else
				Throw New Exception("No implementation for data type " + def.dataType + "!")
		End Select
		Return Nothing
	End Function
	Private Function GetDef(guiElem As Control) As OutputPort
		For Each def As OutputPort In OutputPort.GetList()
			If def.guiElemName.Equals(guiElem.Name) Then
				Return def
			End If
		Next
		Return Nothing
	End Function
	Private Function GetStartingInputValues() As Dictionary(Of InputPort, String)
		Dim result As Dictionary(Of InputPort, String) = New Dictionary(Of InputPort, String)
		For Each def As InputPort In InputPort.GetList()
			Dim f As FieldInfo = form.GetType().GetField("_" + def.guiElemName, BindingFlags.Instance Or BindingFlags.NonPublic)
			Dim resolvedField = f.GetValue(form)
			Select Case def.dataType
				Case "BOOLEAN"
					result.Add(def, ExtractBoolInputFromGUIElem(def, resolvedField))
				Case "PULSE"
					'Do nothing
				Case "NUMBER"
					result.Add(def, ExtractIntInputFromGUIElem(def, resolvedField))
				Case "STRING"
					result.Add(def, ExtractStringInputFromGUIElem(def, resolvedField))
				Case Else
					Throw New Exception("No implementation for data type " + def.dataType + "!")
			End Select
		Next
		Return result
	End Function
	Public Sub TriggerTimeout2(master As OSimMaster, def As TimeoutPort)
		Dim logicalComponent As SMSupport.SMQueued = GetInheritedPrivateFieldValue(master, def.logicalCompName)
		Dim semaphore As SMSupport.RtsSemaphore = GetInheritedPrivateFieldValue(logicalComponent, "RtsBusy")
		Dim currTime As SMSupport.Time = GetInheritedPrivateFieldValue(logicalComponent, "CurrentTime")
		For Each timerElementName As String In def.timerElemNames
			Dim timerElement As SMSupport.RtsTimer = GetInheritedPrivateFieldValue(logicalComponent, timerElementName)
			SMSupport.RtsBase.RtsLock(semaphore)
			SMSupport.RtsBase.RtsStopTimer(timerElement)
			SMSupport.RtsBase.RtsStartTimer(timerElement, 0, currTime)
			SMSupport.RtsBase.RtsUnlock(semaphore)
		Next
	End Sub
	Public Sub TriggerTimeout(master As OSimMaster, def As TimeoutPort)
		For Each t As SimulatorTimeout In SimulatorTimeout.GetTimeouts(master)
			If def.Includes(t.GetLogicalCompName(), t.GetTimerElemName()) Then
				Console.WriteLine("Test triggers timeout " + t.GetLogicalCompName() + "::" + t.GetTimerElemName())
				t.Trigger()
			End If
		Next
	End Sub
	Public Sub TriggerUnregisteredTimeouts(master As OSimMaster)
		For Each t As SimulatorTimeout In SimulatorTimeout.GetTimeouts(master)
			If Not t.IsStable() Then
				Console.WriteLine("Triggering timeout " + t.GetLogicalCompName() + "::" + t.GetTimerElemName())
				t.Trigger()
			End If
		Next
	End Sub
	Public Sub SetInput(form As PredefinedControls.OFormBase, Inp As InputPort, InputValue As String)
		'Main.LOG.Write("JLXAdapter", "[" + form.GetTimeStr() + "] DEBUG: detected stimulus " + def(0) + "!" + Stimulus)
		'Note that a Friend WithEvents field X become a property X backed by a field _X:
		Dim f As FieldInfo = form.GetType().GetField("_" + Inp.guiElemName, BindingFlags.Instance Or BindingFlags.NonPublic)
		Dim resolvedField = f.GetValue(form)
		Select Case Inp.dataType
			Case "BOOLEAN"
				SetBoolInput(resolvedField, InputValue)
			Case "PULSE"
				SetPulseInput(resolvedField, InputValue)
			Case "NUMBER"
				SetIntInput(resolvedField, InputValue)
			Case "STRING"
				SetStringInput(resolvedField, InputValue)
			Case Else
				Throw New Exception("No implementation for data type " + Inp.dataType + "!")
		End Select
	End Sub
	Private Sub SetBoolInput(guiElem As BoolSlider, input As String)
		Dim v = input.Contains("TRUE")
		If v Then
			guiElem.Value = 1
		Else
			guiElem.Value = 0
		End If
	End Sub
	Private Sub SetPulseInput(guiElem As PulseButton, input As String)
		If input.Contains("TRUE") Then
			guiElem.handleClick()
		End If
	End Sub
	Private Sub SetIntInput(guiElem As InputIntegerBox, input As String)
		guiElem.Text = input
	End Sub
	Private Sub SetStringInput(guiElem As Object, input As String)
		If TypeOf guiElem Is InputComboBox Then
			guiElem.Text = input
			Return
		End If
		If TypeOf guiElem Is InputTextBox Then
			guiElem.Text = input
			Return
		End If
		Throw New Exception("Type of GUI element is not supported (" + guiElem.GetType.FullName + ")!")
	End Sub
	Private Function ExtractBoolInputFromGUIElem(def As InputPort, guiElem As BoolSlider) As String
		If guiElem.Value <> 0 Then
			Return "TRUE"
		Else
			Return "FALSE"
		End If
	End Function
	Private Function ExtractIntInputFromGUIElem(def As InputPort, guiElem As InputIntegerBox) As String
		Return guiElem.Text
	End Function
	Private Function ExtractStringInputFromGUIElem(def As InputPort, guiElem As Object) As String
		If TypeOf guiElem Is InputComboBox Then
			Return guiElem.Text
		End If
		If TypeOf guiElem Is InputTextBox Then
			Return guiElem.Text
		End If
		Throw New Exception("Type of GUI element is not supported (" + guiElem.GetType.FullName + ")!")
	End Function
End Module

