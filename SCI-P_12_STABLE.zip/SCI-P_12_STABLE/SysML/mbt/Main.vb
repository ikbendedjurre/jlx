﻿Imports Testing
Module Main
	Sub Main(args As String())
		Dim model = New LoadedModel()
		model.LoadFromFile(args(0))
		Dim testAPI As TestAPI = New TestAPI(20)
		Dim testSuite As LoadedModelTestSuite = New LoadedModelTestSuite(model)
		Dim startTime As DateTime = Now
		testSuite.Run(testAPI)
		Dim endTime As DateTime = Now
		Console.WriteLine("Time elapsed: " + endTime.Subtract(startTime).TotalSeconds.ToString("0.000"))
	End Sub
End Module
