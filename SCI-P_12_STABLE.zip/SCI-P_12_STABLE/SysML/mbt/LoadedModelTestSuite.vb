﻿Namespace Testing
	Public Class LoadedModelTestSuite
		Inherits TestSuite
		Private __model As LoadedModel
		Public Sub New(model As LoadedModel)
			__model = model
		End Sub
		Public Overrides Function GetTests() As Test()
			Console.WriteLine("#tests = " + __model.GetTests().Count.ToString)
			'Dim tests(0) As Test
			'Dim i As Integer = 178
			'tests(0) = New LoadedModelTest(i.ToString("D5"), __model, __model.GetTests()(i))
			Dim tests(__model.GetTests().Count - 1) As Test
			For i As Integer = 0 To tests.Length - 1
				tests(i) = New LoadedModelTest(i.ToString("D5"), __model, __model.GetTests()(i))
			Next
			Return tests
		End Function
	End Class
End Namespace
