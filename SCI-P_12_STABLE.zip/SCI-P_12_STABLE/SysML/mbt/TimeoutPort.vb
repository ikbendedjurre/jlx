﻿Imports System.Reflection

Public Class TimeoutPort
	Public Shared ReadOnly PRIM_D2 As TimeoutPort = New TimeoutPort("(prim, TIMER)", "D2_Con_tmax_PDI_Connection_I1", "SCI_Prim", "RtsAttESTABLISHING_PDI_CONNECTION_Timer1")
	Public Shared ReadOnly P3_D4 As TimeoutPort = New TimeoutPort("(p3, TIMER)", "D04_Con_tmax_Point_Operation2", "P3", "RtsAttMOVING_LEFT_Timer1", "RtsAttMOVING_RIGHT_Timer1")
	'Public Shared ReadOnly EST_D44 As TimeoutPort = New TimeoutPort("(est, TIMER)", "D44_Con_tmax_Booting1", "EST", "RtsAttBOOTING_Timer1")

	Public ReadOnly description As String
	Public ReadOnly adapterLabel As String
	Public ReadOnly logicalCompName As String
	Public ReadOnly timerElemNames As HashSet(Of String)
	Private Sub New(description As String, adapterLabel As String, logicalCompName As String, ParamArray ByVal timerElemNames() As String)
		Me.description = description
		Me.adapterLabel = adapterLabel
		Me.logicalCompName = logicalCompName
		Me.timerElemNames = New HashSet(Of String)
		For Each timerElemName As String In timerElemNames
			Me.timerElemNames.Add(timerElemName)
		Next
	End Sub
	Public Function Includes(logicalCompName As String, timerElemName As String) As Boolean
		Return Me.logicalCompName.Equals(logicalCompName) AndAlso timerElemNames.Contains(timerElemName)
	End Function
	Public Shared Function GetList() As List(Of TimeoutPort)
		Dim result As List(Of TimeoutPort) = New List(Of TimeoutPort)
		Dim fields = GetType(TimeoutPort).GetFields(BindingFlags.Public Or BindingFlags.Static)
		For Each f As FieldInfo In fields
			result.Add(f.GetValue(Nothing))
		Next
		Return result
	End Function
	Private Shared portPerAdapterLabel As Dictionary(Of String, HashSet(Of TimeoutPort)) = Nothing
	Public Shared Function FindInGUI(adapterLabel As String) As HashSet(Of TimeoutPort)
		If portPerAdapterLabel Is Nothing Then
			portPerAdapterLabel = New Dictionary(Of String, HashSet(Of TimeoutPort))
			For Each p In GetList()
				If Not portPerAdapterLabel.ContainsKey(p.adapterLabel) Then
					portPerAdapterLabel.Add(p.adapterLabel, New HashSet(Of TimeoutPort))
				End If
				portPerAdapterLabel(p.adapterLabel).Add(p)
			Next
		End If
		If Not portPerAdapterLabel.ContainsKey(adapterLabel) Then
			Throw New Exception("Could not find timeout port " + adapterLabel + "!")
		End If
		Return portPerAdapterLabel(adapterLabel)
	End Function
End Class
