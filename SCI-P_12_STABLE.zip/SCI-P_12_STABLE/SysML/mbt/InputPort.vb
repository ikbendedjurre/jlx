﻿Imports System.Reflection

Public Class InputPort
	Public Shared ReadOnly EST_D20 As InputPort = New InputPort("(est, D20_Con_MDM_Used)", "BOOLEAN", "D20_Con_MDM_Used1")
	Public Shared ReadOnly EST_T1 As InputPort = New InputPort("(est, T1_Power_On_Detected)", "PULSE", "T1_Power_On_Detected1")
	Public Shared ReadOnly EST_T2 As InputPort = New InputPort("(est, T2_Power_Off_Detected)", "PULSE", "T2_Power_Off_Detected1")
	Public Shared ReadOnly EST_T3 As InputPort = New InputPort("(est, T3_Reset)", "PULSE", "T3_Reset1")
	Public Shared ReadOnly EST_T4 As InputPort = New InputPort("(est, T4_Booted)", "PULSE", "T4_Booted1")
	Public Shared ReadOnly EST_T5 As InputPort = New InputPort("(est, T5_SIL_Not_Fulfilled)", "PULSE", "T5_SIL_Not_Fulfilled1")
	Public Shared ReadOnly EST_T7 As InputPort = New InputPort("(est, T7_Invalid_Or_Missing_Basic_Data)", "PULSE", "T7_Invalid_Or_Missing_Basic_Data1")
	Public Shared ReadOnly P3_D13 As InputPort = New InputPort("(p3, D13_PM2_Activation)", "STRING", "D13_Active_PM21")
	Public Shared ReadOnly P3_D21 As InputPort = New InputPort("(p3, D21_PM1_Position)", "STRING", "PM1_Position1")
	Public Shared ReadOnly P3_D22 As InputPort = New InputPort("(p3, D22_PM2_Position)", "STRING", "PM2_Position1")
	Public Shared ReadOnly P3_D30 As InputPort = New InputPort("(p3, D30_Con_007000)", "BOOLEAN", "D30_0070001")
	Public Shared ReadOnly P3_D32 As InputPort = New InputPort("(p3, D32_Con_007600)", "BOOLEAN", "D32_0076001")
	Public Shared ReadOnly P3_D33 As InputPort = New InputPort("(p3, D33_Con_007900)", "BOOLEAN", "D33_0079001")
	Public Shared ReadOnly P3_D34 As InputPort = New InputPort("(p3, D34_Con_008000)", "BOOLEAN", "D34_0080001")
	Public Shared ReadOnly P3_D35 As InputPort = New InputPort("(p3, D35_Con_008200)", "BOOLEAN", "D35_0082001")
	Public Shared ReadOnly P3_D36 As InputPort = New InputPort("(p3, D36_Con_008300)", "BOOLEAN", "D36_0083001")
	Public Shared ReadOnly P3_D37 As InputPort = New InputPort("(p3, D37_Con_008400)", "BOOLEAN", "D37_0084001")
	Public Shared ReadOnly D3_D38 As InputPort = New InputPort("(p3, D38_Con_008500)", "BOOLEAN", "D38_0085001")
	Public Shared ReadOnly P3_D4 As InputPort = New InputPort("(p3, D4_Con_tmax_Point_Operation)", "NUMBER", "D04_Con_tmax_Point_Operation2")
	Public Shared ReadOnly PRIM_D23 As InputPort = New InputPort("(prim, D23_Con_Checksum_Data_Used)", "BOOLEAN", "D23_Con_Checksum_Data_Used1")
	Public Shared ReadOnly PRIM_D2 As InputPort = New InputPort("(prim, D2_Con_tmax_PDI_Connection)", "NUMBER", "D2_Con_tmax_PDI_Connection_I1")
	Public Shared ReadOnly PRIM_D3 As InputPort = New InputPort("(prim, D3_Con_PDI_Version)", "STRING", "D3_Con_PDI_Version_I1")
	Public Shared ReadOnly PRIM_D4 As InputPort = New InputPort("(prim, D4_Con_Checksum_Data)", "STRING", "D4_Con_Checksum_Data_I1")
	Public Shared ReadOnly PRIM_T10 As InputPort = New InputPort("(prim, T10_SCP_Connection_Terminated)", "PULSE", "T10_SCP_Connection_Terminated1")
	Public Shared ReadOnly PRIM_T20 As InputPort = New InputPort("(prim, T20_Protocol_Error)", "PULSE", "T20_Protocol_Error_I1")
	Public Shared ReadOnly PRIM_T21 As InputPort = New InputPort("(prim, T21_Formal_Telegram_Error)", "PULSE", "T21_Formal_Telegram_Error_I1")
	Public Shared ReadOnly PRIM_T22 As InputPort = New InputPort("(prim, T22_Content_Telegram_Error)", "PULSE", "T22_Content_Telegram_Error_I1")
	Public Shared ReadOnly PRIM_T5 As InputPort = New InputPort("(prim, T5_SCP_Connection_Established)", "PULSE", "T5_SCP_Connection1")
	Public Shared ReadOnly SEC_D23 As InputPort = New InputPort("(sec, D23_Con_Checksum_Data_Used)", "BOOLEAN", "D23_Con_Checksum_Data_Used1")
	Public Shared ReadOnly SEC_D3 As InputPort = New InputPort("(sec, D3_Con_PDI_Version)", "STRING", "D3_Con_PDI_Version1")
	Public Shared ReadOnly SEC_D4 As InputPort = New InputPort("(sec, D4_Con_Checksum_Data)", "STRING", "D4_Checksum_Data1")
	Public Shared ReadOnly SEC_T10 As InputPort = New InputPort("(sec, T10_SCP_Connection_Terminated)", "PULSE", "T10_SCP_Connection_Terminated1")
	Public Shared ReadOnly SEC_T20 As InputPort = New InputPort("(sec, T20_Protocol_Error)", "PULSE", "T20_Protocol_Error1")
	Public Shared ReadOnly SEC_T21 As InputPort = New InputPort("(sec, T21_Formal_Telegram_Error)", "PULSE", "T21_Formal_Telegram_Error1")
	Public Shared ReadOnly SEC_T22 As InputPort = New InputPort("(sec, T22_Content_Telegram_Error)", "PULSE", "T22_Content_Telegram_Error1")
	Public Shared ReadOnly SEC_T5 As InputPort = New InputPort("(sec, T5_SCP_Connection_Established)", "PULSE", "T5_SCP_Connection1")
	Public Shared ReadOnly SMI_D1 As InputPort = New InputPort("(smi, D1_Con_t_Ini_Def_Delay)", "NUMBER", "D1_Con_t_Ini_Def_Delay1")
	Public Shared ReadOnly SMI_D2 As InputPort = New InputPort("(smi, D2_Con_t_Ini_Step)", "NUMBER", "D2_Con_t_Ini_Step1")
	Public Shared ReadOnly SMI_D3 As InputPort = New InputPort("(smi, D3_Con_t_Ini_Max)", "NUMBER", "D3_Con_t_Ini_Max1")
	Public Shared ReadOnly SMI_D4 As InputPort = New InputPort("(smi, D4_Con_tmax_Response_MDM)", "NUMBER", "D4_Con_tmax_Response_MDM1")
	Public Shared ReadOnly SMI_D5 As InputPort = New InputPort("(smi, D5_Con_tmax_DataTransmission)", "NUMBER", "D5_Con_tmax_DataTransmission1")
	Public Shared ReadOnly SMI_T10 As InputPort = New InputPort("(smi, T10_Data_Valid)", "PULSE", "T10_Data_Valid1")
	Public Shared ReadOnly SMI_T11 As InputPort = New InputPort("(smi, T11_Data_Invalid)", "PULSE", "T11_Data_Invalid1")
	Public Shared ReadOnly SMI_T12 As InputPort = New InputPort("(smi, T12_Data_Installation_Successfully)", "PULSE", "T12_Data_Installation_Successfully1")
	Public Shared ReadOnly SMI_T6 As InputPort = New InputPort("(smi, T6_Data_Up_To_Date)", "PULSE", "T6_Data_Up_To_Date1")
	Public Shared ReadOnly SMI_T7 As InputPort = New InputPort("(smi, T7_Data_Not_Up_To_Date)", "PULSE", "T7_Data_Not_Up_To_Date1")
	Public Shared ReadOnly SMI_T8 As InputPort = New InputPort("(smi, T8_Data)", "PULSE", "T8_Data1")
	Public Shared ReadOnly SMI_T9 As InputPort = New InputPort("(smi, T9_Transmission_Complete)", "PULSE", "T9_Transmission_Complete1")
	Public Shared ReadOnly SP_DT10 As InputPort = New InputPort("(sp, DT10_Move_Point)", "STRING", "DT01_Move_Point_Target2")
	Public Shared ReadOnly SP_T10 As InputPort = New InputPort("(sp, T10_Move_Point)", "PULSE", "T01_Cmd_Move_Point2")

	Public ReadOnly description As String
	Public ReadOnly dataType As String
	Public ReadOnly guiElemName As String
	Private Sub New(description As String, dataType As String, guiElemName As String)
		Me.description = description
		Me.dataType = dataType
		Me.guiElemName = guiElemName
	End Sub
	Public Shared Function GetList() As List(Of InputPort)
		Dim result As List(Of InputPort) = New List(Of InputPort)
		Dim fields = GetType(InputPort).GetFields(BindingFlags.Public Or BindingFlags.Static)
		For Each f As FieldInfo In fields
			result.Add(f.GetValue(Nothing))
		Next
		Return result
	End Function
	Private Shared portPerGuiElemName As Dictionary(Of String, HashSet(Of InputPort)) = Nothing
	Public Shared Function FindInGUI(guiElemName As String) As HashSet(Of InputPort)
		If portPerGuiElemName Is Nothing Then
			portPerGuiElemName = New Dictionary(Of String, HashSet(Of InputPort))
			For Each p In GetList()
				If Not portPerGuiElemName.ContainsKey(p.guiElemName) Then
					portPerGuiElemName.Add(p.guiElemName, New HashSet(Of InputPort))
				End If
				portPerGuiElemName(p.guiElemName).Add(p)
			Next
		End If
		If Not portPerGuiElemName.ContainsKey(guiElemName) Then
			Throw New Exception("Could not find input port " + guiElemName + "!")
		End If
		Return portPerGuiElemName(guiElemName)
	End Function
End Class
