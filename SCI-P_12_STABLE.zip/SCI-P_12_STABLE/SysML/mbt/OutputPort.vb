﻿Imports System.Reflection

Public Class OutputPort
	Public Shared ReadOnly P3_D10 As OutputPort = New OutputPort("(p3, D10_Move_Left)", "BOOLEAN", "D5_Move_Left1")
	Public Shared ReadOnly P3_D11 As OutputPort = New OutputPort("(p3, D11_Move_Right)", "BOOLEAN", "D6_Move_Right1")
	Public Shared ReadOnly P3_D25 As OutputPort = New OutputPort("(p3, D25_Redrive)", "BOOLEAN", "D25_Redrive1")
	Public Shared ReadOnly P3_D5 As OutputPort = New OutputPort("(p3, D5_Drive_State)", "STRING", "D05_Drive_State1")
	Public Shared ReadOnly P3_D6 As OutputPort = New OutputPort("(p3, D6_Detection_State)", "STRING", "D06_Detection_State1")
	Public Shared ReadOnly P3_T3 As OutputPort = New OutputPort("(p3, T4_Information_No_End_Position)", "PULSE", "T04_Information_No_End_Position1")
	Public Shared ReadOnly P3_T5 As OutputPort = New OutputPort("(p3, T5_Info_End_Position_Arrived)", "PULSE", "T5_Info_End_Position_Arrived1")
	Public Shared ReadOnly P3_T6 As OutputPort = New OutputPort("(p3, T6_Information_Trailed_Point)", "PULSE", "T06_Information_Trailed_Point1")
	Public Shared ReadOnly P3_T7 As OutputPort = New OutputPort("(p3, T7_Information_Out_Of_Sequence)", "PULSE", "T07_Information_Out_Of_Sequence1")
	Public Shared ReadOnly PRIM_T12 As OutputPort = New OutputPort("(prim, T12_Terminate_SCP_Connection)", "PULSE", "T12_Terminate_SCP_Connection_I1")
	Public Shared ReadOnly PRIM_T6 As OutputPort = New OutputPort("(prim, T6_Establish_SCP_Connection)", "PULSE", "T6_Establish_SCP_Connection_I1")
	Public Shared ReadOnly SEC_T12 As OutputPort = New OutputPort("(sec, T12_Terminate_SCP_Connection)", "PULSE", "T12_Disconnect_SCP1")
	Public Shared ReadOnly SMI_T19 As OutputPort = New OutputPort("(smi, T19_Validate_Data)", "PULSE", "T19_Validate_Data1")
	Public Shared ReadOnly SMI_T20 As OutputPort = New OutputPort("(smi, T20_Ready_For_Update_Of_Data)", "PULSE", "T20_Ready_For_Update_Of_Data1")
	Public Shared ReadOnly SP_DT20 As OutputPort = New OutputPort("(sp, DT20_Point_Position)", "STRING", "DT20_Position1")
	Public Shared ReadOnly SP_T20 As OutputPort = New OutputPort("(sp, T20_Point_Position)", "PULSE", "T02_Msg_Point_Position1")
	Public Shared ReadOnly SP_T30 As OutputPort = New OutputPort("(sp, T30_Timeout)", "PULSE", "T3_Msg_Timeout1")

	'EST <> SEC:
	'Public Shared ReadOnly EST_T21 As OutputPort = New OutputPort("(est, T21_Ready_For_PDI_Connection)", "PULSE", "T21_Ready_For_PDI_Connection1")

	'PRIM <> SEC:
	Public Shared ReadOnly PRIM_T7 As OutputPort = New OutputPort("(prim, T7_Cd_PDI_Version_Check)", "PULSE", "T7_Cd_PDI_Version_Check11")
	Public Shared ReadOnly PRIM_DT7 As OutputPort = New OutputPort("(prim, DT7_PDI_Version)", "PULSE", "DT7_PDI_Version11")
	Public Shared ReadOnly PRIM_T8 As OutputPort = New OutputPort("(prim, T8_Cd_Initialisation_Request)", "PULSE", "T8_Cd_Initialisation_Request12")
	Public Shared ReadOnly SEC_T13 As OutputPort = New OutputPort("(sec, T13_Msg_PDI_Version_Check)", "PULSE", "T13_Msg_PDI_Version_Check1")
	Public Shared ReadOnly SEC_DT13a As OutputPort = New OutputPort("(sec, DT13_Result)", "STRING", "DT13_Result1")
	Public Shared ReadOnly SEC_DT13b As OutputPort = New OutputPort("(sec, DT13_Checksum_Data)", "STRING", "DT13_Checksum_data1")
	Public Shared ReadOnly SEC_T14 As OutputPort = New OutputPort("(sec, T14_Msg_Start_Initialisation)", "PULSE", "T14_Msg_Start_Initialisation1")
	Public Shared ReadOnly SEC_T15 As OutputPort = New OutputPort("(sec, T15_Msg_Initialization_Completed)", "PULSE", "T15_Msg_Initialisation_Completed1")

	'PRIM <> SP:
	Public Shared ReadOnly PRIM_D50 As OutputPort = New OutputPort("(prim, D50_PDI_Connection_State)", "STRING", "D50_PDI_Connection_State1")

	'SEC <> FP:
	Public Shared ReadOnly SEC_D50 As OutputPort = New OutputPort("(sec, D50_PDI_Connection_State)", "STRING", "D50_PDI_Connection_State_S1")
	Public Shared ReadOnly SEC_T6 As OutputPort = New OutputPort("(sec, T6_Start_Status_Report)", "PULSE", "T18_Start_Status_Report1")
	'Public Shared ReadOnly FP_T23 As OutputPort = New OutputPort("(sec, T23_Sending_Status_Report_Completed)", "PULSE", "????")

	'EST <> P3:
	Public Shared ReadOnly EST_D51 As OutputPort = New OutputPort("(est, D51_F_EST_EfeS_State)", "STRING", "D51_F_EST_EfeS_Gen_SR_state1")

	'SP <> FP:
	'Public Shared ReadOnly SP_T1 As OutputPort = New OutputPort("(sp, T1_Cd_Move_Point)", "PULSE", "D51_F_EST_EfeS_Gen_SR_state1")
	'Public Shared ReadOnly SP_DT1 As OutputPort = New OutputPort("(sp, DT1_Move_Point_Target)", "STRING", "D51_F_EST_EfeS_Gen_SR_state1")
	'Public Shared ReadOnly FP_T2 As OutputPort = New OutputPort("(fp, T2_Msg_Point_Position)", "PULSE", "D51_F_EST_EfeS_Gen_SR_state1")
	'Public Shared ReadOnly FP_DT2 As OutputPort = New OutputPort("(fp, DT2_Point_Position)", "STRING", "D51_F_EST_EfeS_Gen_SR_state1")
	'Public Shared ReadOnly FP_T3 As OutputPort = New OutputPort("(fp, T3_Msg_Timeout)", "PULSE", "D51_F_EST_EfeS_Gen_SR_state1")

	'FP <> P3:
	'Public Shared ReadOnly FP_T10 As OutputPort = New OutputPort("(fp, T10_Move)", "PULSE", "????")
	'Public Shared ReadOnly FP_DT10 As OutputPort = New OutputPort("(fp, DT10_Move_Target)", "STRING", "????")
	'Public Shared ReadOnly FP_T11 As OutputPort = New OutputPort("(fp, T11_Stop_Operation)", "PULSE", "????")
	'Public Shared ReadOnly P3_T20 As OutputPort = New OutputPort("(p3, T20_Point_Position)", "PULSE", "????")
	'Public Shared ReadOnly P3_DT20 As OutputPort = New OutputPort("(p3, DT20_Point_Position)", "STRING", "????")
	'Public Shared ReadOnly FP_T40 As OutputPort = New OutputPort("(fp, T40_Send_Status_Report)", "PULSE", "????")
	'Public Shared ReadOnly P3_T30 As OutputPort = New OutputPort("(p3, T30_Report_Timeout)", "PULSE", "????")

	Public ReadOnly description As String
	Public ReadOnly dataType As String
	Public ReadOnly guiElemName As String
	Private Sub New(description As String, dataType As String, guiElemName As String)
		Me.description = description
		Me.dataType = dataType
		Me.guiElemName = guiElemName
	End Sub
	Public Shared Function GetList() As List(Of OutputPort)
		Dim result As List(Of OutputPort) = New List(Of OutputPort)
		Dim fields = GetType(OutputPort).GetFields(BindingFlags.Public Or BindingFlags.Static)
		For Each f As FieldInfo In fields
			result.Add(f.GetValue(Nothing))
		Next
		Return result
	End Function
	Private Shared portPerGuiElemName As Dictionary(Of String, OutputPort) = Nothing
	Public Shared Function FindInGUI(guiElemName As String) As OutputPort
		If portPerGuiElemName Is Nothing Then
			portPerGuiElemName = New Dictionary(Of String, OutputPort)
			For Each p In GetList()
				If portPerGuiElemName.ContainsKey(p.guiElemName) Then
					Throw New Exception("Two output ports named " + p.guiElemName)
				End If
				portPerGuiElemName.Add(p.guiElemName, p)
			Next
		End If
		If Not portPerGuiElemName.ContainsKey(guiElemName) Then
			Throw New Exception("Could not find output port " + guiElemName + "!")
		End If
		Return portPerGuiElemName(guiElemName)
	End Function
End Class
