﻿Public Class PortValuePairs
	Private pairs() As PortValuePair
	Public Sub New(ParamArray ByVal pairs() As PortValuePair)
		Me.pairs = pairs
	End Sub
	Public Sub New(ParamArray ByVal ps() As String)
		Dim newPairs As PortValuePair() = New PortValuePair(ps.Length / 2 - 1) {}
		For i As Integer = 0 To newPairs.Length - 1
			newPairs(i) = New PortValuePair(ps(2 * i), ps(2 * i + 1))
		Next
		Me.pairs = newPairs
	End Sub
	Public Function GetPairs() As PortValuePair()
		Return pairs
	End Function
	Public Function ToText() As String
		If pairs.Length > 0 Then
			Dim result As String = pairs(0).ToText()
			For i As Integer = 1 To pairs.Length - 1
				result = result + ", " + pairs(i).ToText()
			Next
			Return "{ " + result + " }"
		End If
		Return "{ }"
	End Function
End Class

