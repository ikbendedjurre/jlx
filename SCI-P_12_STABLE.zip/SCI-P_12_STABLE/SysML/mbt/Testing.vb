﻿Namespace Testing
	Public Class ConformanceException
		Inherits System.ApplicationException
		Public Sub New(ByVal message As String)
			MyBase.New(message)
		End Sub
	End Class
	Public Interface Test
		Function GetStepCount() As Integer
		Sub Run(testAPI As TestAPI)
	End Interface
	Public Class TestDiscrepancy
		Public ReadOnly header As String
		Public ReadOnly expected As String
		Public ReadOnly observed As String
		Public Sub New(header As String, expected As String, found As String)
			Me.header = header
			Me.expected = expected
			Me.observed = found
		End Sub
		Public Overrides Function Equals(obj As Object) As Boolean
			Dim d = TryCast(obj, TestDiscrepancy)
			Return d IsNot Nothing AndAlso header = d.header AndAlso expected = d.expected AndAlso observed = d.observed
		End Function
		Public Overrides Function GetHashCode() As Integer
			Dim hashCode As Long = -442547264
			hashCode = (hashCode * -1521134295 + EqualityComparer(Of String).Default.GetHashCode(header)).GetHashCode()
			hashCode = (hashCode * -1521134295 + EqualityComparer(Of String).Default.GetHashCode(expected)).GetHashCode()
			hashCode = (hashCode * -1521134295 + EqualityComparer(Of String).Default.GetHashCode(observed)).GetHashCode()
			Return hashCode
		End Function
	End Class
	Public Class TestSuiteResult
		Public passCount As Integer
		Public failCount As Integer
		Public testCount As Integer
	End Class
	Public MustInherit Class TestSuite
		Private discrepancies As Dictionary(Of TestDiscrepancy, HashSet(Of String))
		Public Sub New()
			discrepancies = New Dictionary(Of TestDiscrepancy, HashSet(Of String))
		End Sub
		Public MustOverride Function GetTests() As Test()
		Public Function Run(testAPI As TestAPI) As TestSuiteResult
			Dim result As TestSuiteResult = New TestSuiteResult()
			Dim tests As Test() = GetTests()
			Dim doneStepCount As Integer = 0
			Dim totalStepCount As Integer = 0
			For Each test As Test In tests
				totalStepCount = totalStepCount + test.GetStepCount()
			Next
			For Each test As Test In tests
				Try
					testAPI.SetStepCounts(doneStepCount, totalStepCount)
					testAPI.SetPrefix(String.Format(" [{0}/{1}/{2} failures]", discrepancies.Count, result.failCount, tests.Length))
					test.Run(testAPI)
					doneStepCount = doneStepCount + test.GetStepCount()
					result.passCount = result.passCount + 1
				Catch e As ConformanceException
					result.failCount = result.failCount + 1
					Dim save As Boolean = False
					Dim save2 As Boolean = False
					For Each d In testAPI.GetDiscrepancies()
						Dim ts As HashSet(Of String) = Nothing
						If Not discrepancies.TryGetValue(d, ts) Then
							ts = New HashSet(Of String)
							discrepancies.Add(d, ts)
						End If
						If ts.Count < 3 Then
							ts.Add(test.GetType().Name() + ".fail")
							save = True
							save2 = True
						Else
							If ts.Count < 4 Then
								ts.Add(". . .")
								save2 = True
							End If
						End If
					Next
					If save Then
						testAPI.SaveLog(test.GetType().Name + ".fail")
					End If
					If save2 Then
						SaveDiscrepancies("discrepancies.txt")
					End If
				End Try
				result.testCount = result.testCount + 1
			Next
			'SaveDiscrepancies("discrepancies.txt")
			Return result
		End Function
		Public Sub SaveDiscrepancies(filename As String)
			Dim out As New System.IO.StreamWriter(filename, False)
			For Each d In discrepancies
				out.WriteLine(d.Key.header + ":")
				out.WriteLine("  Expected: " + d.Key.expected)
				out.WriteLine("  Observed: " + d.Key.observed)
				out.WriteLine("Tests:")

				For Each t In d.Value
					out.WriteLine("  " + t)
				Next
			Next
			out.Close()
		End Sub
	End Class
End Namespace
