﻿Public Class Observer
	Private seq() As PortValuePairs
	Private index As Integer
	Private failed As Boolean
	Public Sub New(seq() As PortValuePairs)
		Me.seq = seq
		index = 0
		failed = False
	End Sub
	Public Sub Observe(outputs As Dictionary(Of OutputPort, String))
		If failed Then
			Return
		End If
		If GetDiffs(outputs, seq(index)).Count = 0 Then
			Return
		End If
		If index + 1 >= seq.Length Then
			failed = True
			Return
		End If
		If GetDiffs(outputs, seq(index + 1)).Count = 0 Then
			index = index + 1
			Return
		End If
		failed = True
	End Sub
	Private Shared Function GetDiffs(outputs As Dictionary(Of OutputPort, String), pairs As PortValuePairs) As List(Of String)
		Dim result As List(Of String) = New List(Of String)
		For Each p In pairs.GetPairs()
			If Not GetOutputSynonyms(p.GetValue()).Contains(outputs(p.GetPort())) Then
				result.Add("(" + p.GetPort().description + ", " + outputs(p.GetPort()) + ")")
			End If
		Next
		Return result
	End Function
	Private Shared Function GetDiffsText(outputs As Dictionary(Of OutputPort, String), pairs As PortValuePairs) As String
		Dim diffs As List(Of String) = GetDiffs(outputs, pairs)
		If diffs.Count > 0 Then
			Dim result As String = diffs(0)
			For i As Integer = 1 To diffs.Count - 1
				result = result + ", " + diffs(i)
			Next
			Return "{ " + result + " }"
		End If
		Return "{ }"
	End Function
	Private Shared Function GetOutputSynonyms(Value As String) As HashSet(Of String)
		Select Case Value
			Case "TRUE"
				Return New HashSet(Of String) From {"TRUE", "true", "True"}
			Case "FALSE"
				Return New HashSet(Of String) From {"FALSE", "false", "False"}
			Case "NONE"
				Return New HashSet(Of String) From {"NONE", ""}
			Case Else
				Return New HashSet(Of String) From {Value}
		End Select
	End Function
	Public Function HasFailed() As Boolean
		Return failed
	End Function
	Public Function IsDone() As Boolean
		Return index = seq.Length - 1
	End Function
	Public Function GetExpectationText() As String
		Dim result As String = seq(0).ToText()
		For i As Integer = 1 To seq.Length - 1
			result = result + " -> " + seq(i).ToText()
		Next
		Return result
	End Function
	Public Function GetFoundText() As String
		Dim result As String = seq(0).ToText()
		For i As Integer = 1 To index
			result = result + " -> " + seq(i).ToText()
		Next
		Return result
	End Function
	Public Function GetFoundText(outputs As Dictionary(Of OutputPort, String)) As String
		If Not failed Then
			Return GetFoundText()
		End If
		If index + 1 >= seq.Length Then
			Return GetFoundText() + " -> " + GetDiffsText(outputs, seq(seq.Length - 1))
		Else
			Return GetFoundText() + " -> " + GetDiffsText(outputs, seq(index + 1))
		End If
	End Function
End Class

