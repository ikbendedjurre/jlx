Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.PulseButton
	<System.ComponentModel.ToolboxItem(False)>
	Public Class PulseButton : Inherits Button
		Private Shadows WithEvents SimCore As OSimDeviceCore
		Protected outp As OOutputPort(Of Data_Types.PulsedOut)
		Private wasClicked As Boolean
		Public Sub handleClick() Handles Me.Click
			' ## VBOperationBody [88a026aa-d0fd-4160-be3e-1eece4bdd215] 
			Me.wasClicked = True
			'Console.WriteLine("Pulse button " + outp.FullName() + " handleClick (inner)")
			' ## VBOperationBody End 
			'Console.WriteLine("Pulse button " + outp.FullName() + " handleClick")
		End Sub

		Public Sub onSimulationStart() Handles SimCore.OnSimulationStart
			'Console.WriteLine("Pulse button " + outp.FullName() + " started simulation!")
			Me.wasClicked = False
		End Sub
		Public Sub onSimulationEnd() Handles SimCore.OnSimulationEnd
			'Console.WriteLine("Pulse button " + outp.FullName() + " ended simulation!")
		End Sub

		Public Sub updateOutputValues(ByVal Ph As OPhase) Handles SimCore.OnWriteOutputs
			' ## VBOperationBody [62e5e84e-119d-48b5-a56e-6cfd3d4a0f51] 
			If Me.wasClicked Then
				'Console.WriteLine("(hook) Pulse button " + outp.FullName() + " has been clicked")
				Me.wasClicked = False
				outp.SetValue(True)
			End If
			' ## VBOperationBody End 
		End Sub

		Public Sub initialise(ByRef Rejections As Integer, ByVal ErrList As OErrorList) Handles SimCore.OnReadyToStart
			' ## VBOperationBody [ca208ae5-5a62-4b98-adf3-c5b98c90f474] 
			Me.wasClicked = False
			' ## VBOperationBody End 
		End Sub

		Public Sub New()
			' ## VBOperationBody [c3946f60-4f98-4f83-a91a-ab97fb2c4c3e] 
			Me.Height = 23
			Me.Width = 50
			' ## VBOperationBody End 
		End Sub

	End Class
End Namespace
