Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.BoolIndicator
	<System.ComponentModel.ToolboxItem(False)>
	Public Class BoolIndicator : Inherits PictureBox
		Private Shadows WithEvents SimCore As OSimDeviceCore
		Private Value As Boolean = False
		Protected inp As OInputPort(Of Boolean)
		Public Sub updateInputValues(ByVal Ph As OPhase) Handles SimCore.OnReadInputs
			Dim T As Type = MyClass.GetType

			' ## VBOperationBody [8559349e-99fe-4d1c-9ae4-e6b2563154a5] 
			If inp.GetLatchedValue() = True Then
				Me.BackColor = Color.Orange
				Adapter.ReportOutput(Me, True)
			Else
				Me.BackColor = Color.DarkGray
				Adapter.ReportOutput(Me, False)
			End If
			' ## VBOperationBody End 
		End Sub

		Public Sub initialise(ByRef Rejections As Integer, ByVal ErrList As OErrorList) Handles SimCore.OnReadyToStart
			' ## VBOperationBody [4c091f19-ed58-4da1-b71a-e428d8bf0cdc] 
			Me.BackColor = Color.DarkGray
			' ## VBOperationBody End 
		End Sub

		Public Sub New()
			' ## VBOperationBody [1d871493-f8f7-45ac-bf9a-e3a80414c854] 
			Me.BackColor = Color.DarkGray
			Me.BorderStyle = BorderStyle.FixedSingle
			Me.Height = 30
			Me.Width = 30
			' ## VBOperationBody End 
		End Sub

	End Class
End Namespace
