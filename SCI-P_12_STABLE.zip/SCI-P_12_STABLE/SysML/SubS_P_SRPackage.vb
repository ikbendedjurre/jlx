Option Explicit On
Imports SySimFWK
Imports EULYNX_Profile.Controls.BoolIndicator
Imports EULYNX_Profile.Controls.BoolSlider
Imports EULYNX_Profile.Controls.InputComboBox
Imports EULYNX_Profile.Controls.InputIntegerBox
Imports EULYNX_Profile.Controls.InputTextBox
Imports EULYNX_Profile.Controls.OutputTextBox
Imports EULYNX_Profile.Controls.PulseButton
Imports EULYNX_Profile.Controls.PulsedPortStatusBox
Imports EULYNX_Profile.Controls.PulseIndicator
Imports SIMULATOR.Logical_Components
Imports PredefinedControls

Namespace SIMULATOR.SubS_P_SRPackage
  Public Class D10_Move_Left_BoolIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D10_Move_Left)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolIndicator.BoolIndicator)
      MyBase.New(D, N)
      SetStudioId("85ef335c-def9-460c-ac43-75a350c6932e")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("ddfc4117-32f8-4c7c-a14f-893ac0c15cfa")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D10_Move_Left : Inherits EULYNX_Profile.Controls.BoolIndicator.BoolIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D10_Move_Left:BoolIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D10_Move_Left_BoolIndicator_In_SubS_P_SR("SubS_P_SR.D10_Move_Left", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D11_Move_Right_BoolIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D11_Move_Right)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolIndicator.BoolIndicator)
      MyBase.New(D, N)
      SetStudioId("80e97a04-de95-4aac-8c14-7e6604bda840")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("50b0a3f8-1c44-42be-a6ed-41e95bf1dc64")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D11_Move_Right : Inherits EULYNX_Profile.Controls.BoolIndicator.BoolIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D11_Move_Right:BoolIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D11_Move_Right_BoolIndicator_In_SubS_P_SR("SubS_P_SR.D11_Move_Right", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D13_Activation_PM2_InputComboBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D13_Activation_PM2)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D13_Activation_PM2
      ' -- to P3|D13_PM2_Activation at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D13_PM2_Activation", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputComboBox.InputComboBox)
      MyBase.New(D, N)
      SetStudioId("ed8b2af1-12b9-406e-a04a-79bca4922ad1")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("1116d078-b248-49c2-824a-cf8f4da0eb50")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D13_Activation_PM2 : Inherits EULYNX_Profile.Controls.InputComboBox.InputComboBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D13_Activation_PM2:InputComboBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D13_Activation_PM2_InputComboBox_In_SubS_P_SR("SubS_P_SR.D13_Activation_PM2", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D1_Con_t_Ini_Def_Delay_InputIntegerBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D1_Con_t_Ini_Def_Delay)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D1_Con_t_Ini_Def_Delay
      ' -- to SMI|D1_Con_t_Ini_Def_Delay at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "D1_Con_t_Ini_Def_Delay", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox)
      MyBase.New(D, N)
      SetStudioId("9281f283-4b37-4ff7-9974-0747d7046bfc")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("46141848-ee4b-48e8-ad50-c6eafe01c610")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D1_Con_t_Ini_Def_Delay : Inherits EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D1_Con_t_Ini_Def_Delay:InputIntegerBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D1_Con_t_Ini_Def_Delay_InputIntegerBox_In_SubS_P_SR("SubS_P_SR.D1_Con_t_Ini_Def_Delay", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D20_Con_MDM_Used_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D20_Con_MDM_Used)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D20_Con_MDM_Used
      ' -- to EST|D20_Con_MDM_Used at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "outp", "D20_Con_MDM_Used", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("6498a73d-8b3f-40fe-8e9c-86ed16788e80")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("3522d011-3852-48ad-b494-49f1195425e5")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D20_Con_MDM_Used : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D20_Con_MDM_Used:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D20_Con_MDM_Used_BoolSlider_In_SubS_P_SR("SubS_P_SR.D20_Con_MDM_Used", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D23_Con_Checksum_Data_Used_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D23_Con_Checksum_Data_Used)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D23_Con_Checksum_Data_Used
      ' -- to SCI_Prim|D23_Con_Checksum_Data_Used at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "D23_Con_Checksum_Data_Used", ErrList)
      Next
      ' -- to SCI_Sec|D23_Con_Checksum_Data_Used at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "outp", "D23_Con_Checksum_Data_Used", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("f809f7e0-73dc-4aeb-b24f-2b93ade55b4e")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("307e46f7-db92-41d2-983f-d0b3f16c6225")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D23_Con_Checksum_Data_Used : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D23_Con_Checksum_Data_Used:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D23_Con_Checksum_Data_Used_BoolSlider_In_SubS_P_SR("SubS_P_SR.D23_Con_Checksum_Data_Used", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D25_Redrive_BoolIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D25_Redrive)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolIndicator.BoolIndicator)
      MyBase.New(D, N)
      SetStudioId("69b2c0e0-1e65-40d3-aca7-46871ad43b9e")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("ccec8917-78cf-497d-ac5c-64178a65cfaf")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D25_Redrive : Inherits EULYNX_Profile.Controls.BoolIndicator.BoolIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D25_Redrive:BoolIndicator"
        <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")>
        Public Property SySimTooltip() As String
            Get
                Return _SySimTooltip
            End Get
            Set(ByVal Value As String)
                _SySimTooltip = Value
            End Set
        End Property
        Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D25_Redrive_BoolIndicator_In_SubS_P_SR("SubS_P_SR.D25_Redrive", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D2_Con_t_Ini_Step_InputIntegerBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D2_Con_t_Ini_Step)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D2_Con_t_Ini_Step
      ' -- to SMI|D2_Con_t_Ini_Step at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "D2_Con_t_Ini_Step", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox)
      MyBase.New(D, N)
      SetStudioId("14cf4c52-cbbe-4704-a26d-f696c563f1b5")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("541a8855-e8ce-41f2-83f0-e3b4b7dfe752")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D2_Con_t_Ini_Step : Inherits EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D2_Con_t_Ini_Step:InputIntegerBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D2_Con_t_Ini_Step_InputIntegerBox_In_SubS_P_SR("SubS_P_SR.D2_Con_t_Ini_Step", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D2_Con_tmax_PDI_Connection_I_InputIntegerBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D2_Con_tmax_PDI_Connection_I)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D2_Con_tmax_PDI_Connection_I
      ' -- to SCI_Prim|D2_Con_tmax_PDI_Connection at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "D2_Con_tmax_PDI_Connection", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox)
      MyBase.New(D, N)
      SetStudioId("60ecadee-d2cf-4042-b23f-0001357719d4")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("d66879b8-9b16-4c7c-9955-f00ab8b62d3a")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D2_Con_tmax_PDI_Connection_I : Inherits EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D2_Con_tmax_PDI_Connection_I:InputIntegerBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D2_Con_tmax_PDI_Connection_I_InputIntegerBox_In_SubS_P_SR("SubS_P_SR.D2_Con_tmax_PDI_Connection_I", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D30_Con_007000_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D30_Con_007000)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D30_Con_007000
      ' -- to P3|D30_Con_007000 at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D30_Con_007000", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("489527f8-8507-4c2d-b7d7-3161e341ce9a")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("5462cd10-a504-4ce7-88f3-9f9a37e0834c")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D30_Con_007000 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D30_Con_007000:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D30_Con_007000_BoolSlider_In_SubS_P_SR("SubS_P_SR.D30_Con_007000", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D31_Con_007400_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D31_Con_007400)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D31_Con_007400
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("5c05e515-a754-442e-8203-f3e4198184a1")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("e0534013-31c4-4474-81e9-fa779d88af59")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D31_Con_007400 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D31_Con_007400:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D31_Con_007400_BoolSlider_In_SubS_P_SR("SubS_P_SR.D31_Con_007400", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D32_Con_007600_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D32_Con_007600)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D32_Con_007600
      ' -- to P3|D32_Con_007600 at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D32_Con_007600", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("c3738771-9284-4ca1-a4be-c3707aa8c19d")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("cdb8cb70-8918-4139-931f-22a92d067a30")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D32_Con_007600 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D32_Con_007600:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D32_Con_007600_BoolSlider_In_SubS_P_SR("SubS_P_SR.D32_Con_007600", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D33_Con_007900_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D33_Con_007900)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D33_Con_007900
      ' -- to P3|D33_Con_007900 at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D33_Con_007900", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("16ca70af-68ad-4354-9b8b-e1d3d4cd6e9a")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("7e0d17d2-647c-42cb-9263-6b83f6ec320f")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D33_Con_007900 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D33_Con_007900:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D33_Con_007900_BoolSlider_In_SubS_P_SR("SubS_P_SR.D33_Con_007900", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D34_Con_008000_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D34_Con_008000)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D34_Con_008000
      ' -- to P3|D34_Con_008000 at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D34_Con_008000", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("971e1249-f1eb-43e3-bed6-24cc0c1ea23c")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("a15e9e53-0a9c-453b-a78d-a9793be425f0")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D34_Con_008000 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D34_Con_008000:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D34_Con_008000_BoolSlider_In_SubS_P_SR("SubS_P_SR.D34_Con_008000", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D35_Con_008200_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D35_Con_008200)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D35_Con_008200
      ' -- to P3|D35_Con_008200 at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D35_Con_008200", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("b57ad268-f19d-4d12-aaac-4e1b6b109e96")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("bad7dab1-ad53-43e4-bd1c-c824719dad85")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D35_Con_008200 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D35_Con_008200:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D35_Con_008200_BoolSlider_In_SubS_P_SR("SubS_P_SR.D35_Con_008200", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D36_Con_008300_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D36_Con_008300)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D36_Con_008300
      ' -- to P3|D36_Con_008300 at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D36_Con_008300", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("39e192f5-a10f-49ee-bdfc-4d13afb419da")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("ec4134a2-30f5-49c3-8dc8-bace7948bb28")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D36_Con_008300 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D36_Con_008300:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D36_Con_008300_BoolSlider_In_SubS_P_SR("SubS_P_SR.D36_Con_008300", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D37_Con_008400_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D37_Con_008400)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D37_Con_008400
      ' -- to P3|D37_Con_008400 at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D37_Con_008400", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("70cb123d-464e-47ed-b57d-67047dd0e93d")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("5c8c218f-c00f-4b79-95fe-6d080835a3c4")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D37_Con_008400 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D37_Con_008400:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D37_Con_008400_BoolSlider_In_SubS_P_SR("SubS_P_SR.D37_Con_008400", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D38_Con_008500_BoolSlider_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D38_Con_008500)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D38_Con_008500
      ' -- to P3|D38_Con_008500 at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D38_Con_008500", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.BoolSlider.BoolSlider)
      MyBase.New(D, N)
      SetStudioId("eb6e1218-adbb-4e0d-9e59-761b03c8d44f")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("33ce2bfc-79ab-4d48-903b-4d0dacd89eaa")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D38_Con_008500 : Inherits EULYNX_Profile.Controls.BoolSlider.BoolSlider : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D38_Con_008500:BoolSlider"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D38_Con_008500_BoolSlider_In_SubS_P_SR("SubS_P_SR.D38_Con_008500", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D3_Con_PDI_Version_InputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D3_Con_PDI_Version)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D3_Con_PDI_Version
      ' -- to SCI_Sec|D3_Con_PDI_Version at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "outp", "D3_Con_PDI_Version", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputTextBox.InputTextBox)
      MyBase.New(D, N)
      SetStudioId("4ea6d1ea-9d8b-410b-b17e-7b63f13cdaa8")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("3152da54-b430-409e-83ae-8099f1ef3b4e")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D3_Con_PDI_Version : Inherits EULYNX_Profile.Controls.InputTextBox.InputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D3_Con_PDI_Version:InputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D3_Con_PDI_Version_InputTextBox_In_SubS_P_SR("SubS_P_SR.D3_Con_PDI_Version", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D3_Con_PDI_Version_I_InputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D3_Con_PDI_Version_I)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D3_Con_PDI_Version_I
      ' -- to SCI_Prim|D3_Con_PDI_Version at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "D3_Con_PDI_Version", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputTextBox.InputTextBox)
      MyBase.New(D, N)
      SetStudioId("eb4b7241-e934-4a38-97b2-31a48a3f91d3")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("0cf6ed0f-3aa2-42d7-9a94-b0989063a1bc")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D3_Con_PDI_Version_I : Inherits EULYNX_Profile.Controls.InputTextBox.InputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D3_Con_PDI_Version_I:InputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D3_Con_PDI_Version_I_InputTextBox_In_SubS_P_SR("SubS_P_SR.D3_Con_PDI_Version_I", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D3_Con_t_Ini_Max_InputIntegerBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D3_Con_t_Ini_Max)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D3_Con_t_Ini_Max
      ' -- to SMI|D3_Con_t_Ini_Max at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "D3_Con_t_Ini_Max", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox)
      MyBase.New(D, N)
      SetStudioId("d8fa4f06-2733-4bf7-850b-3a2a004368e1")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("f0c083ff-f270-4b30-9fe0-a450181ebdaf")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D3_Con_t_Ini_Max : Inherits EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D3_Con_t_Ini_Max:InputIntegerBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D3_Con_t_Ini_Max_InputIntegerBox_In_SubS_P_SR("SubS_P_SR.D3_Con_t_Ini_Max", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D44_Con_tmax_Booting_InputIntegerBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D44_Con_tmax_Booting)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D44_Con_tmax_Booting
      ' -- to EST|D44_Con_tmax_Booting at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "outp", "D44_Con_tmax_Booting", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox)
      MyBase.New(D, N)
      SetStudioId("564f2690-9692-46d4-aabd-7cfcff51b25d")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("5cd3302f-01ce-408e-876f-551a4f678c42")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D44_Con_tmax_Booting : Inherits EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D44_Con_tmax_Booting:InputIntegerBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D44_Con_tmax_Booting_InputIntegerBox_In_SubS_P_SR("SubS_P_SR.D44_Con_tmax_Booting", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D4_Checksum_Data_InputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D4_Checksum_Data)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D4_Checksum_Data
      ' -- to SCI_Sec|D4_Con_Checksum_Data at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "outp", "D4_Con_Checksum_Data", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputTextBox.InputTextBox)
      MyBase.New(D, N)
      SetStudioId("1fc630db-0ac8-4220-ae4e-9bc90575bf28")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("8ace5901-7305-4091-90e7-64f618ba24ce")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D4_Checksum_Data : Inherits EULYNX_Profile.Controls.InputTextBox.InputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D4_Checksum_Data:InputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D4_Checksum_Data_InputTextBox_In_SubS_P_SR("SubS_P_SR.D4_Checksum_Data", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D4_Con_Checksum_Data_I_InputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D4_Con_Checksum_Data_I)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D4_Con_Checksum_Data_I
      ' -- to SCI_Prim|D4_Con_Checksum_Data at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "D4_Con_Checksum_Data", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputTextBox.InputTextBox)
      MyBase.New(D, N)
      SetStudioId("2379f88b-0b28-401b-aa43-9f856cba0fda")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("db3e9528-899b-48a7-b725-11cc1f94cc6f")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D4_Con_Checksum_Data_I : Inherits EULYNX_Profile.Controls.InputTextBox.InputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D4_Con_Checksum_Data_I:InputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D4_Con_Checksum_Data_I_InputTextBox_In_SubS_P_SR("SubS_P_SR.D4_Con_Checksum_Data_I", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D4_Con_tmax_Point_Operation_InputIntegerBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D4_Con_tmax_Point_Operation)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D4_Con_tmax_Point_Operation
      ' -- to P3|D4_Con_tmax_Point_Operation at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D4_Con_tmax_Point_Operation", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox)
      MyBase.New(D, N)
      SetStudioId("d0b98b71-552e-400b-88ee-d3bba4216f54")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("b4e844e3-e145-4111-b9cf-4d01db03fa55")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D4_Con_tmax_Point_Operation : Inherits EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D4_Con_tmax_Point_Operation:InputIntegerBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D4_Con_tmax_Point_Operation_InputIntegerBox_In_SubS_P_SR("SubS_P_SR.D4_Con_tmax_Point_Operation", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D4_Con_tmax_Response_MDM_InputIntegerBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D4_Con_tmax_Response_MDM)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D4_Con_tmax_Response_MDM
      ' -- to SMI|D4_Con_tmax_Response_MDM at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "D4_Con_tmax_Response_MDM", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox)
      MyBase.New(D, N)
      SetStudioId("7ab9502a-30ab-4089-8064-d932e99d6968")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("02e2cede-9cc8-4824-81fe-6d6c78b960af")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D4_Con_tmax_Response_MDM : Inherits EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D4_Con_tmax_Response_MDM:InputIntegerBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D4_Con_tmax_Response_MDM_InputIntegerBox_In_SubS_P_SR("SubS_P_SR.D4_Con_tmax_Response_MDM", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D50_PDI_Connection_State_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D50_PDI_Connection_State)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("55fd4ffd-4a72-49ec-bc60-0d4f2275dce3")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("3feb4282-cb33-4617-ab9e-fb7f6600ac86")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D50_PDI_Connection_State : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D50_PDI_Connection_State:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D50_PDI_Connection_State_OutputTextBox_In_SubS_P_SR("SubS_P_SR.D50_PDI_Connection_State", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D50_PDI_Connection_State_S_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D50_PDI_Connection_State_S)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("3539c5f8-e799-4356-a325-c2fd621c54b6")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("c4412877-b1d9-4e60-9b2d-3b6f74cc2151")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D50_PDI_Connection_State_S : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D50_PDI_Connection_State_S:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D50_PDI_Connection_State_S_OutputTextBox_In_SubS_P_SR("SubS_P_SR.D50_PDI_Connection_State_S", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D51_F_EST_EfeS_Gen_SR_state_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D51_F_EST_EfeS_Gen_SR_state)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("5e06e036-eacf-4dfd-be9f-3ad8fe52f36e")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("6ec77391-6552-409a-8a38-b7a1a0f437f4")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D51_F_EST_EfeS_Gen_SR_state : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D51_F_EST_EfeS_Gen_SR_state:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D51_F_EST_EfeS_Gen_SR_state_OutputTextBox_In_SubS_P_SR("SubS_P_SR.D51_F_EST_EfeS_Gen_SR_state", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D5_Con_tmax_DataTransmission_InputIntegerBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D5_Con_tmax_DataTransmission)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context D5_Con_tmax_DataTransmission
      ' -- to SMI|D5_Con_tmax_DataTransmission at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "D5_Con_tmax_DataTransmission", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox)
      MyBase.New(D, N)
      SetStudioId("82ab18f1-3819-41cd-a88b-55773899402c")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("af3da1e2-461a-4f63-ae06-970eac5926a9")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D5_Con_tmax_DataTransmission : Inherits EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D5_Con_tmax_DataTransmission:InputIntegerBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D5_Con_tmax_DataTransmission_InputIntegerBox_In_SubS_P_SR("SubS_P_SR.D5_Con_tmax_DataTransmission", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D5_Drive_State_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D5_Drive_State)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("0036427f-8115-4897-8a48-df30569300a4")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("41362e2b-11e4-4500-9bf5-99a4cbb203f7")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D5_Drive_State : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D5_Drive_State:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D5_Drive_State_OutputTextBox_In_SubS_P_SR("SubS_P_SR.D5_Drive_State", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class D6_Detection_State_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.D6_Detection_State)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("07fc1412-f0f6-4d75-9cad-af10141818f4")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("434af108-6123-4c09-9d02-87123e270465")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class D6_Detection_State : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "D6_Detection_State:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New D6_Detection_State_OutputTextBox_In_SubS_P_SR("SubS_P_SR.D6_Detection_State", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class DT13_Checksum_data_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.DT13_Checksum_data)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("8ecf908a-dc6d-49cd-9485-9bae630d0e71")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("e8f5b368-6f34-4042-872c-a866c471de37")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class DT13_Checksum_data : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "DT13_Checksum_data:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New DT13_Checksum_data_OutputTextBox_In_SubS_P_SR("SubS_P_SR.DT13_Checksum_data", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class DT13_Result_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.DT13_Result)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("e6511e01-85a2-4061-9955-631fc735fea3")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("bc023a37-a976-4fbf-b346-c525f26c761e")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class DT13_Result : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "DT13_Result:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New DT13_Result_OutputTextBox_In_SubS_P_SR("SubS_P_SR.DT13_Result", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class DT1_Move_Point_Target_InputComboBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.DT1_Move_Point_Target)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context DT1_Move_Point_Target
      ' -- to S_SCI_P|DT10_Move_Point at SubS_P_SR.S_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.S_SCI_P")
        Me.BindPort(DestPart, "outp", "DT10_Move_Point", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputComboBox.InputComboBox)
      MyBase.New(D, N)
      SetStudioId("2c94aa31-7f56-466b-96ef-7dc0b02fc596")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("6bd9c117-3075-47da-8b7d-e9ec693d5679")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class DT1_Move_Point_Target : Inherits EULYNX_Profile.Controls.InputComboBox.InputComboBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "DT1_Move_Point_Target:InputComboBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New DT1_Move_Point_Target_InputComboBox_In_SubS_P_SR("SubS_P_SR.DT1_Move_Point_Target", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class DT1_OUT_Move_Point_Target_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.DT1_OUT_Move_Point_Target)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("3235f2c6-a495-429f-8fd9-3b73274b9a8b")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("0d971ce2-eef0-48f7-9e52-67c48c4ad036")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class DT1_OUT_Move_Point_Target : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "DT1_OUT_Move_Point_Target:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New DT1_OUT_Move_Point_Target_OutputTextBox_In_SubS_P_SR("SubS_P_SR.DT1_OUT_Move_Point_Target", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class DT20_Position_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.DT20_Position)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("05b2e605-bbee-4d8a-9b82-8e4dc32d2056")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("3f5d8afe-5bda-4025-99d6-ff6678e392a0")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class DT20_Position : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "DT20_Position:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New DT20_Position_OutputTextBox_In_SubS_P_SR("SubS_P_SR.DT20_Position", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class DT2_OUT_Point_Position_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.DT2_OUT_Point_Position)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("942bb28b-759c-4e2c-b0a5-993bfee00e4f")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("08641c58-2a1a-495c-941f-8cee2659a4ab")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class DT2_OUT_Point_Position : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "DT2_OUT_Point_Position:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New DT2_OUT_Point_Position_OutputTextBox_In_SubS_P_SR("SubS_P_SR.DT2_OUT_Point_Position", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class DT2_Point_Position_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.DT2_Point_Position)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("78689fd8-0b2e-4bd4-ab99-ee763b9adc21")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("3710485b-ffc3-4487-a9e0-07ef2eacb9b5")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class DT2_Point_Position : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "DT2_Point_Position:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New DT2_Point_Position_OutputTextBox_In_SubS_P_SR("SubS_P_SR.DT2_Point_Position", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class DT7_PDI_Version1_OutputTextBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.DT7_PDI_Version1)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox)
      MyBase.New(D, N)
      SetStudioId("8257330e-f6e1-4920-86af-6a0e889d7343")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("d4350767-fe93-436a-af03-f9ffecbda8f8")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class DT7_PDI_Version1 : Inherits EULYNX_Profile.Controls.OutputTextBox.OutputTextBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "DT7_PDI_Version1:OutputTextBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New DT7_PDI_Version1_OutputTextBox_In_SubS_P_SR("SubS_P_SR.DT7_PDI_Version1", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class EST_F_EST_EfeS_SR_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_D20_Con_MDM_Used : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D44_Con_tmax_Booting : Inherits OInputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_D51_EST_EfeS_State : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T10_PDI_Connection_Terminated : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T13_Data_Update_After_Booting : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T14_Data_Update_After_Operational : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T15_Data_Update_In_Initialising : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T16_Data_Installation_Complete : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T17_Data_Update_Finished : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T18_Not_Ready_For_PDI_Connection : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T1_Power_On_Detected : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T21_Ready_For_PDI_Connection : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T22_Data_Update_Stop : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T2_Power_Off_Detected : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T3_Reset : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T4_Booted : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T5_SIL_Not_Fulfilled : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T7_Invalid_Or_Missing_Basic_Data : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T9_PDI_Connection_Established : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.EST)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port D51_EST_EfeS_State in invocation context EST
      ' -- to D51_F_EST_EfeS_Gen_SR_state|inp at SubS_P_SR.D51_F_EST_EfeS_Gen_SR_state
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.D51_F_EST_EfeS_Gen_SR_state")
        Me.BindPort(DestPart, "D51_EST_EfeS_State", "inp", ErrList)
      Next
      ' -- to P3|D20_F_EST_EfeS_Gen_SR_State at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "D51_EST_EfeS_State", "D20_F_EST_EfeS_Gen_SR_State", ErrList)
      Next
      ' Port T13_Data_Update_After_Booting in invocation context EST
      ' -- to SMI|T13_Data_Update_After_Booting at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "T13_Data_Update_After_Booting", "T13_Data_Update_After_Booting", ErrList)
      Next
      ' Port T14_Data_Update_After_Operational in invocation context EST
      ' -- to SMI|T14_Data_Update_After_Operational at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "T14_Data_Update_After_Operational", "T14_Data_Update_After_Operational", ErrList)
      Next
      ' Port T15_Data_Update_In_Initialising in invocation context EST
      ' -- to SMI|T15_Data_Update_In_Initialising at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "T15_Data_Update_In_Initialising", "T15_Data_Update_In_Initialising", ErrList)
      Next
      ' Port T18_Not_Ready_For_PDI_Connection in invocation context EST
      ' -- to SCI_Sec|T18_Not_Ready_For_PDI_Connection at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "T18_Not_Ready_For_PDI_Connection", "T18_Not_Ready_For_PDI_Connection", ErrList)
      Next
      ' Port T21_Ready_For_PDI_Connection in invocation context EST
      ' -- to SCI_Sec|T1_Ready_For_PDI_Connection at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "T21_Ready_For_PDI_Connection", "T1_Ready_For_PDI_Connection", ErrList)
      Next
      ' Port T22_Data_Update_Stop in invocation context EST
      ' -- to SMI|T22_Data_Update_Stop at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "T22_Data_Update_Stop", "T22_Data_Update_Stop", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As SIMULATOR.Logical_Components.F_EST_EfeS_SR)
      MyBase.New(D, N)
      SetStudioId("7109ffb7-dca5-4744-ab06-9572d19cd0ad")
      Dim O As Object
      ' D20_Con_MDM_Used:InputPort_D20_Con_MDM_Used
      O = New InputPort_D20_Con_MDM_Used("D20_Con_MDM_Used", Me, D)
      O.SetStudioId("7948a8c6-4d71-4ee8-84dd-199e21a4f643")
      ' D44_Con_tmax_Booting:InputPort_D44_Con_tmax_Booting
      O = New InputPort_D44_Con_tmax_Booting("D44_Con_tmax_Booting", Me, D)
      O.SetStudioId("7ba18007-d380-4877-ab2a-934b76d32e88")
      ' D51_EST_EfeS_State:OutputPort_D51_EST_EfeS_State
      O = New OutputPort_D51_EST_EfeS_State("D51_EST_EfeS_State", Me, D)
      O.SetStudioId("2912d2da-b915-4f54-b755-017fb064b0f6")
      ' T10_PDI_Connection_Terminated:InputPort_T10_PDI_Connection_Terminated
      O = New InputPort_T10_PDI_Connection_Terminated("T10_PDI_Connection_Terminated", Me, D)
      O.SetStudioId("9d81335c-cfa4-4797-b629-e2c824815abd")
      ' T13_Data_Update_After_Booting:OutputPort_T13_Data_Update_After_Booting
      O = New OutputPort_T13_Data_Update_After_Booting("T13_Data_Update_After_Booting", Me, D)
      O.SetStudioId("376b8fb5-4355-4c51-a2bd-e62129b891e5")
      ' T14_Data_Update_After_Operational:OutputPort_T14_Data_Update_After_Operational
      O = New OutputPort_T14_Data_Update_After_Operational("T14_Data_Update_After_Operational", Me, D)
      O.SetStudioId("5b36f84d-ab87-4818-a3f2-f320c6536162")
      ' T15_Data_Update_In_Initialising:OutputPort_T15_Data_Update_In_Initialising
      O = New OutputPort_T15_Data_Update_In_Initialising("T15_Data_Update_In_Initialising", Me, D)
      O.SetStudioId("19a1e94d-5d5b-494d-b18f-fd8fbf31a195")
      ' T16_Data_Installation_Complete:InputPort_T16_Data_Installation_Complete
      O = New InputPort_T16_Data_Installation_Complete("T16_Data_Installation_Complete", Me, D)
      O.SetStudioId("1e214d84-6f57-4381-92bf-7e05286bc446")
      ' T17_Data_Update_Finished:InputPort_T17_Data_Update_Finished
      O = New InputPort_T17_Data_Update_Finished("T17_Data_Update_Finished", Me, D)
      O.SetStudioId("d3af4743-0bb4-4405-a775-d7a6343861e5")
      ' T18_Not_Ready_For_PDI_Connection:OutputPort_T18_Not_Ready_For_PDI_Connection
      O = New OutputPort_T18_Not_Ready_For_PDI_Connection("T18_Not_Ready_For_PDI_Connection", Me, D)
      O.SetStudioId("a81737cf-309b-4e92-a968-f240254dbd42")
      ' T1_Power_On_Detected:InputPort_T1_Power_On_Detected
      O = New InputPort_T1_Power_On_Detected("T1_Power_On_Detected", Me, D)
      O.SetStudioId("e73447ff-5df1-4e2f-aac9-45e309c0ef11")
      ' T21_Ready_For_PDI_Connection:OutputPort_T21_Ready_For_PDI_Connection
      O = New OutputPort_T21_Ready_For_PDI_Connection("T21_Ready_For_PDI_Connection", Me, D)
      O.SetStudioId("096fae5d-d6cb-445d-ac82-d8da6a6b1e0e")
      ' T22_Data_Update_Stop:OutputPort_T22_Data_Update_Stop
      O = New OutputPort_T22_Data_Update_Stop("T22_Data_Update_Stop", Me, D)
      O.SetStudioId("962f2559-86dd-45ff-a55d-0e7e6a43aab1")
      ' T2_Power_Off_Detected:InputPort_T2_Power_Off_Detected
      O = New InputPort_T2_Power_Off_Detected("T2_Power_Off_Detected", Me, D)
      O.SetStudioId("90884992-43e0-4a57-9e44-85baafae2853")
      ' T3_Reset:InputPort_T3_Reset
      O = New InputPort_T3_Reset("T3_Reset", Me, D)
      O.SetStudioId("c6a7d639-f7a7-4565-affa-e4547c9c7a4e")
      ' T4_Booted:InputPort_T4_Booted
      O = New InputPort_T4_Booted("T4_Booted", Me, D)
      O.SetStudioId("afdcf490-f808-429d-a14e-67c859fec7cd")
      ' T5_SIL_Not_Fulfilled:InputPort_T5_SIL_Not_Fulfilled
      O = New InputPort_T5_SIL_Not_Fulfilled("T5_SIL_Not_Fulfilled", Me, D)
      O.SetStudioId("6728dfc2-b4d3-4730-8627-14ca51c25fd2")
      ' T7_Invalid_Or_Missing_Basic_Data:InputPort_T7_Invalid_Or_Missing_Basic_Data
      O = New InputPort_T7_Invalid_Or_Missing_Basic_Data("T7_Invalid_Or_Missing_Basic_Data", Me, D)
      O.SetStudioId("7407794d-47bb-4ebc-90f5-81c38f235858")
      ' T9_PDI_Connection_Established:InputPort_T9_PDI_Connection_Established
      O = New InputPort_T9_PDI_Connection_Established("T9_PDI_Connection_Established", Me, D)
      O.SetStudioId("bb07bd3c-fcda-4135-90be-9f1328c05c92")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class EST : Inherits Logical_Components.F_EST_EfeS_SR : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "EST:F_EST_EfeS_SR"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New EST_F_EST_EfeS_SR_In_SubS_P_SR("SubS_P_SR.EST", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        D20_Con_MDM_Used = SimCore.GetInPorts("D20_Con_MDM_Used")
        D44_Con_tmax_Booting = SimCore.GetInPorts("D44_Con_tmax_Booting")
        D51_EST_EfeS_State = SimCore.GetOutPorts("D51_EST_EfeS_State")
        T10_PDI_Connection_Terminated = SimCore.GetInPorts("T10_PDI_Connection_Terminated")
        T13_Data_Update_After_Booting = SimCore.GetOutPorts("T13_Data_Update_After_Booting")
        T14_Data_Update_After_Operational = SimCore.GetOutPorts("T14_Data_Update_After_Operational")
        T15_Data_Update_In_Initialising = SimCore.GetOutPorts("T15_Data_Update_In_Initialising")
        T16_Data_Installation_Complete = SimCore.GetInPorts("T16_Data_Installation_Complete")
        T17_Data_Update_Finished = SimCore.GetInPorts("T17_Data_Update_Finished")
        T18_Not_Ready_For_PDI_Connection = SimCore.GetOutPorts("T18_Not_Ready_For_PDI_Connection")
        T1_Power_On_Detected = SimCore.GetInPorts("T1_Power_On_Detected")
        T21_Ready_For_PDI_Connection = SimCore.GetOutPorts("T21_Ready_For_PDI_Connection")
        T22_Data_Update_Stop = SimCore.GetOutPorts("T22_Data_Update_Stop")
        T2_Power_Off_Detected = SimCore.GetInPorts("T2_Power_Off_Detected")
        T3_Reset = SimCore.GetInPorts("T3_Reset")
        T4_Booted = SimCore.GetInPorts("T4_Booted")
        T5_SIL_Not_Fulfilled = SimCore.GetInPorts("T5_SIL_Not_Fulfilled")
        T7_Invalid_Or_Missing_Basic_Data = SimCore.GetInPorts("T7_Invalid_Or_Missing_Basic_Data")
        T9_PDI_Connection_Established = SimCore.GetInPorts("T9_PDI_Connection_Established")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class F_SCI_P_F_SCI_P_SR_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_D21_F_SCI_EfeS_Gen_SR_State : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_DT10_Move_Target : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_DT1_Move_Point_Target : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_DT20_Point_Position : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_DT2_Point_Position : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T10_Move : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T11_Stop_Operation : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T18_Start_Status_Report : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T1_Cd_Move_Point : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T20_Point_Position : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T23_Sending_Status_Report_Completed : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T2_Msg_Point_Position : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T30_Report_Timeout : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T3_Msg_Timeout : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T40_Send_Status_Report : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.F_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port DT10_Move_Target in invocation context F_SCI_P
      ' -- to P3|DT1_Move_Target at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "DT10_Move_Target", "DT1_Move_Target", ErrList)
      Next
      ' Port DT2_Point_Position in invocation context F_SCI_P
      ' -- to DT2_OUT_Point_Position|inp at SubS_P_SR.DT2_OUT_Point_Position
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.DT2_OUT_Point_Position")
        Me.BindPort(DestPart, "DT2_Point_Position", "inp", ErrList)
      Next
      ' -- to S_SCI_P|DT2_Point_Position at SubS_P_SR.S_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.S_SCI_P")
        Me.BindPort(DestPart, "DT2_Point_Position", "DT2_Point_Position", ErrList)
      Next
      ' Port T10_Move in invocation context F_SCI_P
      ' -- to P3|T1_Move at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "T10_Move", "T1_Move", ErrList)
      Next
      ' Port T11_Stop_Operation in invocation context F_SCI_P
      ' -- to P3|T2_Stop_Operation at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "T11_Stop_Operation", "T2_Stop_Operation", ErrList)
      Next
      ' Port T23_Sending_Status_Report_Completed in invocation context F_SCI_P
      ' -- to SCI_Sec|T9_Status_Report_Completed at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "T23_Sending_Status_Report_Completed", "T9_Status_Report_Completed", ErrList)
      Next
      ' -- to T23_Sending_Status_Report_Completed|inp at SubS_P_SR.T23_Sending_Status_Report_Completed
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T23_Sending_Status_Report_Completed")
        Me.BindPort(DestPart, "T23_Sending_Status_Report_Completed", "inp", ErrList)
      Next
      ' Port T2_Msg_Point_Position in invocation context F_SCI_P
      ' -- to S_SCI_P|T2_Msg_Point_Position at SubS_P_SR.S_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.S_SCI_P")
        Me.BindPort(DestPart, "T2_Msg_Point_Position", "T2_Msg_Point_Position", ErrList)
      Next
      ' -- to T2_OUT_Point_Position|inp at SubS_P_SR.T2_OUT_Point_Position
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T2_OUT_Point_Position")
        Me.BindPort(DestPart, "T2_Msg_Point_Position", "inp", ErrList)
      Next
      ' Port T3_Msg_Timeout in invocation context F_SCI_P
      ' -- to S_SCI_P|T3_Msg_Timeout at SubS_P_SR.S_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.S_SCI_P")
        Me.BindPort(DestPart, "T3_Msg_Timeout", "T3_Msg_Timeout", ErrList)
      Next
      ' Port T40_Send_Status_Report in invocation context F_SCI_P
      ' -- to P3|T40_Report_Status at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "T40_Send_Status_Report", "T40_Report_Status", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As SIMULATOR.Logical_Components.F_SCI_P_SR)
      MyBase.New(D, N)
      SetStudioId("9daea24a-bab2-4435-bfc3-a3289cc4bdfc")
      Dim O As Object
      ' D21_F_SCI_EfeS_Gen_SR_State:InputPort_D21_F_SCI_EfeS_Gen_SR_State
      O = New InputPort_D21_F_SCI_EfeS_Gen_SR_State("D21_F_SCI_EfeS_Gen_SR_State", Me, D)
      O.SetStudioId("e7ad6739-337a-45ab-9a62-41aedb92aa9e")
      ' DT10_Move_Target:OutputPort_DT10_Move_Target
      O = New OutputPort_DT10_Move_Target("DT10_Move_Target", Me, D)
      O.SetStudioId("4224ebc5-07ba-4fe4-bfe5-dc5e8c206186")
      ' DT1_Move_Point_Target:InputPort_DT1_Move_Point_Target
      O = New InputPort_DT1_Move_Point_Target("DT1_Move_Point_Target", Me, D)
      O.SetStudioId("52916c32-a923-4dcc-89d3-109824ee01ff")
      ' DT20_Point_Position:InputPort_DT20_Point_Position
      O = New InputPort_DT20_Point_Position("DT20_Point_Position", Me, D)
      O.SetStudioId("5c217f85-9de6-446e-8f15-2857515d7b0a")
      ' DT2_Point_Position:OutputPort_DT2_Point_Position
      O = New OutputPort_DT2_Point_Position("DT2_Point_Position", Me, D)
      O.SetStudioId("6f426cdf-9b1d-49a3-bc9c-bb1dd9ae9731")
      ' T10_Move:OutputPort_T10_Move
      O = New OutputPort_T10_Move("T10_Move", Me, D)
      O.SetStudioId("04167811-8f8e-4ec2-af3a-ae5d0d9258fb")
      ' T11_Stop_Operation:OutputPort_T11_Stop_Operation
      O = New OutputPort_T11_Stop_Operation("T11_Stop_Operation", Me, D)
      O.SetStudioId("b2480649-a23f-4ba6-81ec-ade30cf87c64")
      ' T18_Start_Status_Report:InputPort_T18_Start_Status_Report
      O = New InputPort_T18_Start_Status_Report("T18_Start_Status_Report", Me, D)
      O.SetStudioId("c718f5c7-2c91-4d40-a014-d17567de1604")
      ' T1_Cd_Move_Point:InputPort_T1_Cd_Move_Point
      O = New InputPort_T1_Cd_Move_Point("T1_Cd_Move_Point", Me, D)
      O.SetStudioId("106895f7-97de-4fa3-b9bb-930a02f49af3")
      ' T20_Point_Position:InputPort_T20_Point_Position
      O = New InputPort_T20_Point_Position("T20_Point_Position", Me, D)
      O.SetStudioId("c234083a-b273-47b5-b2f2-4a9d0f15811d")
      ' T23_Sending_Status_Report_Completed:OutputPort_T23_Sending_Status_Report_Completed
      O = New OutputPort_T23_Sending_Status_Report_Completed("T23_Sending_Status_Report_Completed", Me, D)
      O.SetStudioId("feb31eeb-8c15-41f5-a532-2bea3609e177")
      ' T2_Msg_Point_Position:OutputPort_T2_Msg_Point_Position
      O = New OutputPort_T2_Msg_Point_Position("T2_Msg_Point_Position", Me, D)
      O.SetStudioId("b6740485-af5a-4f1e-b6a8-50eef513d052")
      ' T30_Report_Timeout:InputPort_T30_Report_Timeout
      O = New InputPort_T30_Report_Timeout("T30_Report_Timeout", Me, D)
      O.SetStudioId("36f2a7ef-bc8f-41a5-8b74-8e30ea78c76b")
      ' T3_Msg_Timeout:OutputPort_T3_Msg_Timeout
      O = New OutputPort_T3_Msg_Timeout("T3_Msg_Timeout", Me, D)
      O.SetStudioId("45c97286-f9b0-4d5f-9531-884162069e47")
      ' T40_Send_Status_Report:OutputPort_T40_Send_Status_Report
      O = New OutputPort_T40_Send_Status_Report("T40_Send_Status_Report", Me, D)
      O.SetStudioId("c5e7c86c-0481-49b1-a971-20977b1733df")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class F_SCI_P : Inherits Logical_Components.F_SCI_P_SR : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "F_SCI_P:F_SCI_P_SR"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New F_SCI_P_F_SCI_P_SR_In_SubS_P_SR("SubS_P_SR.F_SCI_P", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        D21_F_SCI_EfeS_Gen_SR_State = SimCore.GetInPorts("D21_F_SCI_EfeS_Gen_SR_State")
        DT10_Move_Target = SimCore.GetOutPorts("DT10_Move_Target")
        DT1_Move_Point_Target = SimCore.GetInPorts("DT1_Move_Point_Target")
        DT20_Point_Position = SimCore.GetInPorts("DT20_Point_Position")
        DT2_Point_Position = SimCore.GetOutPorts("DT2_Point_Position")
        T10_Move = SimCore.GetOutPorts("T10_Move")
        T11_Stop_Operation = SimCore.GetOutPorts("T11_Stop_Operation")
        T18_Start_Status_Report = SimCore.GetInPorts("T18_Start_Status_Report")
        T1_Cd_Move_Point = SimCore.GetInPorts("T1_Cd_Move_Point")
        T20_Point_Position = SimCore.GetInPorts("T20_Point_Position")
        T23_Sending_Status_Report_Completed = SimCore.GetOutPorts("T23_Sending_Status_Report_Completed")
        T2_Msg_Point_Position = SimCore.GetOutPorts("T2_Msg_Point_Position")
        T30_Report_Timeout = SimCore.GetInPorts("T30_Report_Timeout")
        T3_Msg_Timeout = SimCore.GetOutPorts("T3_Msg_Timeout")
        T40_Send_Status_Report = SimCore.GetOutPorts("T40_Send_Status_Report")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class P3_F_P3_SR_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_D10_Move_Left : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_D11_Move_Right : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D13_PM2_Activation : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D20_F_EST_EfeS_Gen_SR_State : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D21_PM1_Position : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D22_PM2_Position : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_D25_Redrive : Inherits OOutputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D30_Con_007000 : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D32_Con_007600 : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D33_Con_007900 : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D34_Con_008000 : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D35_Con_008200 : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D37_Con_008400 : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D38_Con_008500 : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D4_Con_tmax_Point_Operation : Inherits OInputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_D5_Drive_State : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_D6_Detection_State : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_DT1_Move_Target : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_DT20_Point_Position : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T1_Move : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T20_Point_Position : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T2_Stop_Operation : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T30_Report_Timeout : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T40_Report_Status : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T4_Information_No_End_Position : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T5_Info_End_Position_Arrived : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T6_Information_Trailed_Point : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T7_Information_Out_Of_Sequence : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.P3)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port D10_Move_Left in invocation context P3
      ' -- to D10_Move_Left|inp at SubS_P_SR.D10_Move_Left
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.D10_Move_Left")
        Me.BindPort(DestPart, "D10_Move_Left", "inp", ErrList)
      Next
      ' Port D11_Move_Right in invocation context P3
      ' -- to D11_Move_Right|inp at SubS_P_SR.D11_Move_Right
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.D11_Move_Right")
        Me.BindPort(DestPart, "D11_Move_Right", "inp", ErrList)
      Next
      ' Port D25_Redrive in invocation context P3
      ' -- to D25_Redrive|inp at SubS_P_SR.D25_Redrive
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.D25_Redrive")
        Me.BindPort(DestPart, "D25_Redrive", "inp", ErrList)
      Next
      ' Port D5_Drive_State in invocation context P3
      ' -- to D5_Drive_State|inp at SubS_P_SR.D5_Drive_State
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.D5_Drive_State")
        Me.BindPort(DestPart, "D5_Drive_State", "inp", ErrList)
      Next
      ' Port D6_Detection_State in invocation context P3
      ' -- to D6_Detection_State|inp at SubS_P_SR.D6_Detection_State
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.D6_Detection_State")
        Me.BindPort(DestPart, "D6_Detection_State", "inp", ErrList)
      Next
      ' Port DT20_Point_Position in invocation context P3
      ' -- to DT20_Position|inp at SubS_P_SR.DT20_Position
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.DT20_Position")
        Me.BindPort(DestPart, "DT20_Point_Position", "inp", ErrList)
      Next
      ' -- to F_SCI_P|DT20_Point_Position at SubS_P_SR.F_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.F_SCI_P")
        Me.BindPort(DestPart, "DT20_Point_Position", "DT20_Point_Position", ErrList)
      Next
      ' Port T20_Point_Position in invocation context P3
      ' -- to F_SCI_P|T20_Point_Position at SubS_P_SR.F_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.F_SCI_P")
        Me.BindPort(DestPart, "T20_Point_Position", "T20_Point_Position", ErrList)
      Next
      ' Port T30_Report_Timeout in invocation context P3
      ' -- to F_SCI_P|T30_Report_Timeout at SubS_P_SR.F_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.F_SCI_P")
        Me.BindPort(DestPart, "T30_Report_Timeout", "T30_Report_Timeout", ErrList)
      Next
      ' Port T4_Information_No_End_Position in invocation context P3
      ' -- to T4_Information_No_End_Position|inp at SubS_P_SR.T4_Information_No_End_Position
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T4_Information_No_End_Position")
        Me.BindPort(DestPart, "T4_Information_No_End_Position", "inp", ErrList)
      Next
      ' Port T5_Info_End_Position_Arrived in invocation context P3
      ' -- to T5_Info_End_Position_Arrived|inp at SubS_P_SR.T5_Info_End_Position_Arrived
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T5_Info_End_Position_Arrived")
        Me.BindPort(DestPart, "T5_Info_End_Position_Arrived", "inp", ErrList)
      Next
      ' Port T6_Information_Trailed_Point in invocation context P3
      ' -- to T6_Information_Trailed_Point|inp at SubS_P_SR.T6_Information_Trailed_Point
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T6_Information_Trailed_Point")
        Me.BindPort(DestPart, "T6_Information_Trailed_Point", "inp", ErrList)
      Next
      ' Port T7_Information_Out_Of_Sequence in invocation context P3
      ' -- to T7_Information_Out_Of_Sequence|inp at SubS_P_SR.T7_Information_Out_Of_Sequence
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T7_Information_Out_Of_Sequence")
        Me.BindPort(DestPart, "T7_Information_Out_Of_Sequence", "inp", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As SIMULATOR.Logical_Components.F_P3_SR)
      MyBase.New(D, N)
      SetStudioId("7760ac4b-7edf-4e5a-b534-04dc3cfa02ee")
      Dim O As Object
      ' D10_Move_Left:OutputPort_D10_Move_Left
      O = New OutputPort_D10_Move_Left("D10_Move_Left", Me, D)
      O.SetStudioId("7ec7441a-bb66-4bda-a4aa-cfbb90ee60b6")
      ' D11_Move_Right:OutputPort_D11_Move_Right
      O = New OutputPort_D11_Move_Right("D11_Move_Right", Me, D)
      O.SetStudioId("81c3f227-2d21-4061-97f4-182711899d77")
      ' D13_PM2_Activation:InputPort_D13_PM2_Activation
      O = New InputPort_D13_PM2_Activation("D13_PM2_Activation", Me, D)
      O.SetStudioId("4307d16c-e26c-465c-94d5-20429a130c43")
      ' D20_F_EST_EfeS_Gen_SR_State:InputPort_D20_F_EST_EfeS_Gen_SR_State
      O = New InputPort_D20_F_EST_EfeS_Gen_SR_State("D20_F_EST_EfeS_Gen_SR_State", Me, D)
      O.SetStudioId("2b1beeb2-fadf-45ce-953f-a7c14303be4e")
      ' D21_PM1_Position:InputPort_D21_PM1_Position
      O = New InputPort_D21_PM1_Position("D21_PM1_Position", Me, D)
      O.SetStudioId("1c97f870-6a2c-4780-9043-dad3d656581b")
      ' D22_PM2_Position:InputPort_D22_PM2_Position
      O = New InputPort_D22_PM2_Position("D22_PM2_Position", Me, D)
      O.SetStudioId("40ba8018-f972-4939-9827-d6eec2492d57")
      ' D25_Redrive:OutputPort_D25_Redrive
      O = New OutputPort_D25_Redrive("D25_Redrive", Me, D)
      O.SetStudioId("b12e2a23-aa2c-4023-b82c-1ac1acc7d038")
      ' D30_Con_007000:InputPort_D30_Con_007000
      O = New InputPort_D30_Con_007000("D30_Con_007000", Me, D)
      O.SetStudioId("8f09620a-7be5-44be-af94-0e7c3e81b74b")
      ' D32_Con_007600:InputPort_D32_Con_007600
      O = New InputPort_D32_Con_007600("D32_Con_007600", Me, D)
      O.SetStudioId("fd649def-dcee-44a1-89c6-e3fa0ee17a0a")
      ' D33_Con_007900:InputPort_D33_Con_007900
      O = New InputPort_D33_Con_007900("D33_Con_007900", Me, D)
      O.SetStudioId("31670ee5-f069-4463-b350-ab70e718228a")
      ' D34_Con_008000:InputPort_D34_Con_008000
      O = New InputPort_D34_Con_008000("D34_Con_008000", Me, D)
      O.SetStudioId("1cd28e4f-6b08-4f6e-b9ee-491ca9309207")
      ' D35_Con_008200:InputPort_D35_Con_008200
      O = New InputPort_D35_Con_008200("D35_Con_008200", Me, D)
      O.SetStudioId("d45d6124-3f37-40e3-a641-11b1904c8f5b")
      ' D37_Con_008400:InputPort_D37_Con_008400
      O = New InputPort_D37_Con_008400("D37_Con_008400", Me, D)
      O.SetStudioId("873fe477-5fd2-4709-ab46-74d4a066afd2")
      ' D38_Con_008500:InputPort_D38_Con_008500
      O = New InputPort_D38_Con_008500("D38_Con_008500", Me, D)
      O.SetStudioId("a693fb66-965b-493a-b907-503abe08bd99")
      ' D4_Con_tmax_Point_Operation:InputPort_D4_Con_tmax_Point_Operation
      O = New InputPort_D4_Con_tmax_Point_Operation("D4_Con_tmax_Point_Operation", Me, D)
      O.SetStudioId("b91496f5-e243-4f15-ad0f-b6e48f5d8c0c")
      ' D5_Drive_State:OutputPort_D5_Drive_State
      O = New OutputPort_D5_Drive_State("D5_Drive_State", Me, D)
      O.SetStudioId("ac7d846e-48fa-4d2a-9f3f-b76a0ad662a6")
      ' D6_Detection_State:OutputPort_D6_Detection_State
      O = New OutputPort_D6_Detection_State("D6_Detection_State", Me, D)
      O.SetStudioId("0ae1e7ba-c19a-43b6-827f-d4593423d9c3")
      ' DT1_Move_Target:InputPort_DT1_Move_Target
      O = New InputPort_DT1_Move_Target("DT1_Move_Target", Me, D)
      O.SetStudioId("ccb9d390-82a8-478c-8b4e-1b87a331bc52")
      ' DT20_Point_Position:OutputPort_DT20_Point_Position
      O = New OutputPort_DT20_Point_Position("DT20_Point_Position", Me, D)
      O.SetStudioId("57d8e303-215c-4d8f-86da-82d0de2fece0")
      ' T1_Move:InputPort_T1_Move
      O = New InputPort_T1_Move("T1_Move", Me, D)
      O.SetStudioId("a21e35f0-2ffd-4fb0-a91c-1e6c42c033c2")
      ' T20_Point_Position:OutputPort_T20_Point_Position
      O = New OutputPort_T20_Point_Position("T20_Point_Position", Me, D)
      O.SetStudioId("8a4de56d-4d2c-49af-9c89-b3160f81527e")
      ' T2_Stop_Operation:InputPort_T2_Stop_Operation
      O = New InputPort_T2_Stop_Operation("T2_Stop_Operation", Me, D)
      O.SetStudioId("7056052e-b62a-43ed-8f88-0a760421fe79")
      ' T30_Report_Timeout:OutputPort_T30_Report_Timeout
      O = New OutputPort_T30_Report_Timeout("T30_Report_Timeout", Me, D)
      O.SetStudioId("2fd6fb42-0bb6-438d-9a0b-a0d459b3abe8")
      ' T40_Report_Status:InputPort_T40_Report_Status
      O = New InputPort_T40_Report_Status("T40_Report_Status", Me, D)
      O.SetStudioId("be34a353-303d-425d-a3dc-ec7dfb93d51d")
      ' T4_Information_No_End_Position:OutputPort_T4_Information_No_End_Position
      O = New OutputPort_T4_Information_No_End_Position("T4_Information_No_End_Position", Me, D)
      O.SetStudioId("327637c8-849c-4150-a4c1-46768a714d71")
      ' T5_Info_End_Position_Arrived:OutputPort_T5_Info_End_Position_Arrived
      O = New OutputPort_T5_Info_End_Position_Arrived("T5_Info_End_Position_Arrived", Me, D)
      O.SetStudioId("518de745-1c21-4a90-a852-0b939cb70957")
      ' T6_Information_Trailed_Point:OutputPort_T6_Information_Trailed_Point
      O = New OutputPort_T6_Information_Trailed_Point("T6_Information_Trailed_Point", Me, D)
      O.SetStudioId("ed6fa79d-6bbd-4217-8733-155b6089edd4")
      ' T7_Information_Out_Of_Sequence:OutputPort_T7_Information_Out_Of_Sequence
      O = New OutputPort_T7_Information_Out_Of_Sequence("T7_Information_Out_Of_Sequence", Me, D)
      O.SetStudioId("8549a6bf-6c73-41d8-934e-a3e40b70cb68")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class P3 : Inherits Logical_Components.F_P3_SR : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "P3:F_P3_SR"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New P3_F_P3_SR_In_SubS_P_SR("SubS_P_SR.P3", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        D10_Move_Left = SimCore.GetOutPorts("D10_Move_Left")
        D11_Move_Right = SimCore.GetOutPorts("D11_Move_Right")
        D13_PM2_Activation = SimCore.GetInPorts("D13_PM2_Activation")
        D20_F_EST_EfeS_Gen_SR_State = SimCore.GetInPorts("D20_F_EST_EfeS_Gen_SR_State")
        D21_PM1_Position = SimCore.GetInPorts("D21_PM1_Position")
        D22_PM2_Position = SimCore.GetInPorts("D22_PM2_Position")
        D25_Redrive = SimCore.GetOutPorts("D25_Redrive")
        D30_Con_007000 = SimCore.GetInPorts("D30_Con_007000")
        D32_Con_007600 = SimCore.GetInPorts("D32_Con_007600")
        D33_Con_007900 = SimCore.GetInPorts("D33_Con_007900")
        D34_Con_008000 = SimCore.GetInPorts("D34_Con_008000")
        D35_Con_008200 = SimCore.GetInPorts("D35_Con_008200")
        D37_Con_008400 = SimCore.GetInPorts("D37_Con_008400")
        D38_Con_008500 = SimCore.GetInPorts("D38_Con_008500")
        D4_Con_tmax_Point_Operation = SimCore.GetInPorts("D4_Con_tmax_Point_Operation")
        D5_Drive_State = SimCore.GetOutPorts("D5_Drive_State")
        D6_Detection_State = SimCore.GetOutPorts("D6_Detection_State")
        DT1_Move_Target = SimCore.GetInPorts("DT1_Move_Target")
        DT20_Point_Position = SimCore.GetOutPorts("DT20_Point_Position")
        T1_Move = SimCore.GetInPorts("T1_Move")
        T20_Point_Position = SimCore.GetOutPorts("T20_Point_Position")
        T2_Stop_Operation = SimCore.GetInPorts("T2_Stop_Operation")
        T30_Report_Timeout = SimCore.GetOutPorts("T30_Report_Timeout")
        T40_Report_Status = SimCore.GetInPorts("T40_Report_Status")
        T4_Information_No_End_Position = SimCore.GetOutPorts("T4_Information_No_End_Position")
        T5_Info_End_Position_Arrived = SimCore.GetOutPorts("T5_Info_End_Position_Arrived")
        T6_Information_Trailed_Point = SimCore.GetOutPorts("T6_Information_Trailed_Point")
        T7_Information_Out_Of_Sequence = SimCore.GetOutPorts("T7_Information_Out_Of_Sequence")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class PM1_Position_InputComboBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.PM1_Position)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context PM1_Position
      ' -- to P3|D21_PM1_Position at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D21_PM1_Position", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputComboBox.InputComboBox)
      MyBase.New(D, N)
      SetStudioId("18f59227-b672-4ae3-9de3-6af56053cb0a")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("e49ad06a-8521-4488-9ee7-295bf08cbe21")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class PM1_Position : Inherits EULYNX_Profile.Controls.InputComboBox.InputComboBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "PM1_Position:InputComboBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New PM1_Position_InputComboBox_In_SubS_P_SR("SubS_P_SR.PM1_Position", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class PM2_Position_InputComboBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.PM2_Position)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context PM2_Position
      ' -- to P3|D22_PM2_Position at SubS_P_SR.P3
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.P3")
        Me.BindPort(DestPart, "outp", "D22_PM2_Position", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.InputComboBox.InputComboBox)
      MyBase.New(D, N)
      SetStudioId("2491f9ec-256a-4f9e-a8ae-b8cf622b748c")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("28808b56-91ff-4291-8daa-8661e1d4fd12")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class PM2_Position : Inherits EULYNX_Profile.Controls.InputComboBox.InputComboBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "PM2_Position:InputComboBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New PM2_Position_InputComboBox_In_SubS_P_SR("SubS_P_SR.PM2_Position", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class S_SCI_P_S_SCI_P_SR_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_D21_S_SCI_EfeS_Gen_SR_State : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_DT10_Move_Point : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_DT1_Move_Point_Target : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_DT20_Point_Position : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_DT2_Point_Position : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T10_Move_Point : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T1_Cd_Move_Point : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T20_Point_Position : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T2_Msg_Point_Position : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T30_Timeout : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T3_Msg_Timeout : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.S_SCI_P)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port DT1_Move_Point_Target in invocation context S_SCI_P
      ' -- to DT1_OUT_Move_Point_Target|inp at SubS_P_SR.DT1_OUT_Move_Point_Target
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.DT1_OUT_Move_Point_Target")
        Me.BindPort(DestPart, "DT1_Move_Point_Target", "inp", ErrList)
      Next
      ' -- to F_SCI_P|DT1_Move_Point_Target at SubS_P_SR.F_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.F_SCI_P")
        Me.BindPort(DestPart, "DT1_Move_Point_Target", "DT1_Move_Point_Target", ErrList)
      Next
      ' Port DT20_Point_Position in invocation context S_SCI_P
      ' -- to DT2_Point_Position|inp at SubS_P_SR.DT2_Point_Position
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.DT2_Point_Position")
        Me.BindPort(DestPart, "DT20_Point_Position", "inp", ErrList)
      Next
      ' Port T1_Cd_Move_Point in invocation context S_SCI_P
      ' -- to F_SCI_P|T1_Cd_Move_Point at SubS_P_SR.F_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.F_SCI_P")
        Me.BindPort(DestPart, "T1_Cd_Move_Point", "T1_Cd_Move_Point", ErrList)
      Next
      ' -- to T1_OUT_Move_Point|inp at SubS_P_SR.T1_OUT_Move_Point
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T1_OUT_Move_Point")
        Me.BindPort(DestPart, "T1_Cd_Move_Point", "inp", ErrList)
      Next
      ' Port T20_Point_Position in invocation context S_SCI_P
      ' -- to T2_Msg_Point_Position|inp at SubS_P_SR.T2_Msg_Point_Position
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T2_Msg_Point_Position")
        Me.BindPort(DestPart, "T20_Point_Position", "inp", ErrList)
      Next
      ' Port T30_Timeout in invocation context S_SCI_P
      ' -- to T3_Msg_Timeout|inp at SubS_P_SR.T3_Msg_Timeout
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T3_Msg_Timeout")
        Me.BindPort(DestPart, "T30_Timeout", "inp", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As SIMULATOR.Logical_Components.S_SCI_P_SR)
      MyBase.New(D, N)
      SetStudioId("ff41514d-09a5-4f9b-9bff-c6e87e019569")
      Dim O As Object
      ' D21_S_SCI_EfeS_Gen_SR_State:InputPort_D21_S_SCI_EfeS_Gen_SR_State
      O = New InputPort_D21_S_SCI_EfeS_Gen_SR_State("D21_S_SCI_EfeS_Gen_SR_State", Me, D)
      O.SetStudioId("a1c59e33-a710-4cea-bd40-c83cb1e99f06")
      ' DT10_Move_Point:InputPort_DT10_Move_Point
      O = New InputPort_DT10_Move_Point("DT10_Move_Point", Me, D)
      O.SetStudioId("f3883a23-ae58-498c-bd32-7beaa598b522")
      ' DT1_Move_Point_Target:OutputPort_DT1_Move_Point_Target
      O = New OutputPort_DT1_Move_Point_Target("DT1_Move_Point_Target", Me, D)
      O.SetStudioId("326c7ecb-6259-45f5-acc7-cfacdab677b0")
      ' DT20_Point_Position:OutputPort_DT20_Point_Position
      O = New OutputPort_DT20_Point_Position("DT20_Point_Position", Me, D)
      O.SetStudioId("8d710a9a-2cff-46c7-b237-bfaff7ae74b4")
      ' DT2_Point_Position:InputPort_DT2_Point_Position
      O = New InputPort_DT2_Point_Position("DT2_Point_Position", Me, D)
      O.SetStudioId("b4bce0fb-1b6b-4a18-8475-87b25ee148f2")
      ' T10_Move_Point:InputPort_T10_Move_Point
      O = New InputPort_T10_Move_Point("T10_Move_Point", Me, D)
      O.SetStudioId("080be3f9-537f-4a4d-8064-dd51a82b8989")
      ' T1_Cd_Move_Point:OutputPort_T1_Cd_Move_Point
      O = New OutputPort_T1_Cd_Move_Point("T1_Cd_Move_Point", Me, D)
      O.SetStudioId("cde6019e-a2a8-45df-ae0e-18aeef77864e")
      ' T20_Point_Position:OutputPort_T20_Point_Position
      O = New OutputPort_T20_Point_Position("T20_Point_Position", Me, D)
      O.SetStudioId("d6d9e638-d1a9-497b-9df0-7d9fb66bc73b")
      ' T2_Msg_Point_Position:InputPort_T2_Msg_Point_Position
      O = New InputPort_T2_Msg_Point_Position("T2_Msg_Point_Position", Me, D)
      O.SetStudioId("777ef13e-e708-4b88-b91f-15b3ffbb05f5")
      ' T30_Timeout:OutputPort_T30_Timeout
      O = New OutputPort_T30_Timeout("T30_Timeout", Me, D)
      O.SetStudioId("8dee909b-1924-4c2f-84b7-e09a204a4770")
      ' T3_Msg_Timeout:InputPort_T3_Msg_Timeout
      O = New InputPort_T3_Msg_Timeout("T3_Msg_Timeout", Me, D)
      O.SetStudioId("4c075566-8618-4ed5-9902-bff0191ec1e1")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class S_SCI_P : Inherits Logical_Components.S_SCI_P_SR : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "S_SCI_P:S_SCI_P_SR"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New S_SCI_P_S_SCI_P_SR_In_SubS_P_SR("SubS_P_SR.S_SCI_P", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        D21_S_SCI_EfeS_Gen_SR_State = SimCore.GetInPorts("D21_S_SCI_EfeS_Gen_SR_State")
        DT10_Move_Point = SimCore.GetInPorts("DT10_Move_Point")
        DT1_Move_Point_Target = SimCore.GetOutPorts("DT1_Move_Point_Target")
        DT20_Point_Position = SimCore.GetOutPorts("DT20_Point_Position")
        DT2_Point_Position = SimCore.GetInPorts("DT2_Point_Position")
        T10_Move_Point = SimCore.GetInPorts("T10_Move_Point")
        T1_Cd_Move_Point = SimCore.GetOutPorts("T1_Cd_Move_Point")
        T20_Point_Position = SimCore.GetOutPorts("T20_Point_Position")
        T2_Msg_Point_Position = SimCore.GetInPorts("T2_Msg_Point_Position")
        T30_Timeout = SimCore.GetOutPorts("T30_Timeout")
        T3_Msg_Timeout = SimCore.GetInPorts("T3_Msg_Timeout")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class SCI_Prim_S_SCI_EfeS_Prim_SR_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_D23_Con_Checksum_Data_Used : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D2_Con_tmax_PDI_Connection : Inherits OInputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D3_Con_PDI_Version : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D4_Con_Checksum_Data : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_D50_PDI_Connection_State : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_DT13_Checksum_Data : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_DT13_Result : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_DT7_PDI_Version : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T10_SCP_Connection_Terminated : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T12_Terminate_SCP_Connection : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T13_Msg_PDI_Version_Check : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T14_Msg_Start_Initialisation : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T15_Msg_Initialisation_Completed : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T20_Protocol_Error : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T21_Formal_Telegram_Error : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T22_Content_Telegram_Error : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T5_SCP_Connection_Established : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T6_Establish_SCP_Connection : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T7_Cd_PDI_Version_Check : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T8_Cd_Initialisation_Request : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Prim)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port D50_PDI_Connection_State in invocation context SCI_Prim
      ' -- to D50_PDI_Connection_State|inp at SubS_P_SR.D50_PDI_Connection_State
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.D50_PDI_Connection_State")
        Me.BindPort(DestPart, "D50_PDI_Connection_State", "inp", ErrList)
      Next
      ' -- to S_SCI_P|D21_S_SCI_EfeS_Gen_SR_State at SubS_P_SR.S_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.S_SCI_P")
        Me.BindPort(DestPart, "D50_PDI_Connection_State", "D21_S_SCI_EfeS_Gen_SR_State", ErrList)
      Next
      ' Port DT7_PDI_Version in invocation context SCI_Prim
      ' -- to DT7_PDI_Version1|inp at SubS_P_SR.DT7_PDI_Version1
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.DT7_PDI_Version1")
        Me.BindPort(DestPart, "DT7_PDI_Version", "inp", ErrList)
      Next
      ' -- to SCI_Sec|DT7_PDI_Version at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "DT7_PDI_Version", "DT7_PDI_Version", ErrList)
      Next
      ' Port T12_Terminate_SCP_Connection in invocation context SCI_Prim
      ' -- to T12_Terminate_SCP_Connection_I|inp at SubS_P_SR.T12_Terminate_SCP_Connection_I
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T12_Terminate_SCP_Connection_I")
        Me.BindPort(DestPart, "T12_Terminate_SCP_Connection", "inp", ErrList)
      Next
      ' Port T6_Establish_SCP_Connection in invocation context SCI_Prim
      ' -- to T6_Establish_SCP_Connection_I|inp at SubS_P_SR.T6_Establish_SCP_Connection_I
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T6_Establish_SCP_Connection_I")
        Me.BindPort(DestPart, "T6_Establish_SCP_Connection", "inp", ErrList)
      Next
      ' Port T7_Cd_PDI_Version_Check in invocation context SCI_Prim
      ' -- to SCI_Sec|T7_Cd_PDI_Version_Check at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "T7_Cd_PDI_Version_Check", "T7_Cd_PDI_Version_Check", ErrList)
      Next
      ' -- to T7_Cd_PDI_Version_Check1|inp at SubS_P_SR.T7_Cd_PDI_Version_Check1
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T7_Cd_PDI_Version_Check1")
        Me.BindPort(DestPart, "T7_Cd_PDI_Version_Check", "inp", ErrList)
      Next
      ' Port T8_Cd_Initialisation_Request in invocation context SCI_Prim
      ' -- to SCI_Sec|T8_Cd_Initialisation_Request at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "T8_Cd_Initialisation_Request", "T8_Cd_Initialisation_Request", ErrList)
      Next
      ' -- to T8_Cd_Initialisation_Request1|inp at SubS_P_SR.T8_Cd_Initialisation_Request1
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T8_Cd_Initialisation_Request1")
        Me.BindPort(DestPart, "T8_Cd_Initialisation_Request", "inp", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As SIMULATOR.Logical_Components.S_SCI_EfeS_Prim_SR)
      MyBase.New(D, N)
      SetStudioId("cfc1d7fe-dcfe-41f6-9ce2-cbd26ffeb11b")
      Dim O As Object
      ' D23_Con_Checksum_Data_Used:InputPort_D23_Con_Checksum_Data_Used
      O = New InputPort_D23_Con_Checksum_Data_Used("D23_Con_Checksum_Data_Used", Me, D)
      O.SetStudioId("669e53e6-aef1-45b2-9701-231d37436192")
      ' D2_Con_tmax_PDI_Connection:InputPort_D2_Con_tmax_PDI_Connection
      O = New InputPort_D2_Con_tmax_PDI_Connection("D2_Con_tmax_PDI_Connection", Me, D)
      O.SetStudioId("427588b9-9538-4138-9869-97a4bf60f9ec")
      ' D3_Con_PDI_Version:InputPort_D3_Con_PDI_Version
      O = New InputPort_D3_Con_PDI_Version("D3_Con_PDI_Version", Me, D)
      O.SetStudioId("cae65de0-9007-4047-85f9-02f924c9724d")
      ' D4_Con_Checksum_Data:InputPort_D4_Con_Checksum_Data
      O = New InputPort_D4_Con_Checksum_Data("D4_Con_Checksum_Data", Me, D)
      O.SetStudioId("b2cba8dd-ae7b-4528-9b1b-7bc9f861f7fb")
      ' D50_PDI_Connection_State:OutputPort_D50_PDI_Connection_State
      O = New OutputPort_D50_PDI_Connection_State("D50_PDI_Connection_State", Me, D)
      O.SetStudioId("4c4b5d2f-3d12-4e84-8cd6-3803bc336b3d")
      ' DT13_Checksum_Data:InputPort_DT13_Checksum_Data
      O = New InputPort_DT13_Checksum_Data("DT13_Checksum_Data", Me, D)
      O.SetStudioId("c2249a40-c3ff-4182-8608-d053532f3772")
      ' DT13_Result:InputPort_DT13_Result
      O = New InputPort_DT13_Result("DT13_Result", Me, D)
      O.SetStudioId("f32504d0-2559-4e57-9643-4737269cee46")
      ' DT7_PDI_Version:OutputPort_DT7_PDI_Version
      O = New OutputPort_DT7_PDI_Version("DT7_PDI_Version", Me, D)
      O.SetStudioId("eb64f7fc-7dfc-4222-82af-15ffeb12cb9c")
      ' T10_SCP_Connection_Terminated:InputPort_T10_SCP_Connection_Terminated
      O = New InputPort_T10_SCP_Connection_Terminated("T10_SCP_Connection_Terminated", Me, D)
      O.SetStudioId("42b01835-f606-4d79-a945-63df06412523")
      ' T12_Terminate_SCP_Connection:OutputPort_T12_Terminate_SCP_Connection
      O = New OutputPort_T12_Terminate_SCP_Connection("T12_Terminate_SCP_Connection", Me, D)
      O.SetStudioId("1cadb459-8083-446c-9ee5-6732b3a7b3bc")
      ' T13_Msg_PDI_Version_Check:InputPort_T13_Msg_PDI_Version_Check
      O = New InputPort_T13_Msg_PDI_Version_Check("T13_Msg_PDI_Version_Check", Me, D)
      O.SetStudioId("fa84a5cd-f158-46f1-8a14-3579f56ce154")
      ' T14_Msg_Start_Initialisation:InputPort_T14_Msg_Start_Initialisation
      O = New InputPort_T14_Msg_Start_Initialisation("T14_Msg_Start_Initialisation", Me, D)
      O.SetStudioId("b2850963-289c-4c82-9154-36f598b34262")
      ' T15_Msg_Initialisation_Completed:InputPort_T15_Msg_Initialisation_Completed
      O = New InputPort_T15_Msg_Initialisation_Completed("T15_Msg_Initialisation_Completed", Me, D)
      O.SetStudioId("ea115c6c-46e1-4219-8ff2-f2574142083e")
      ' T20_Protocol_Error:InputPort_T20_Protocol_Error
      O = New InputPort_T20_Protocol_Error("T20_Protocol_Error", Me, D)
      O.SetStudioId("58f36b66-f736-4fb8-a767-7c5a2da78ac9")
      ' T21_Formal_Telegram_Error:InputPort_T21_Formal_Telegram_Error
      O = New InputPort_T21_Formal_Telegram_Error("T21_Formal_Telegram_Error", Me, D)
      O.SetStudioId("e4ff96da-9cc7-47e0-a8eb-c9abde0dbba2")
      ' T22_Content_Telegram_Error:InputPort_T22_Content_Telegram_Error
      O = New InputPort_T22_Content_Telegram_Error("T22_Content_Telegram_Error", Me, D)
      O.SetStudioId("4a8d2762-fe6a-452b-bcbd-2848edc703e0")
      ' T5_SCP_Connection_Established:InputPort_T5_SCP_Connection_Established
      O = New InputPort_T5_SCP_Connection_Established("T5_SCP_Connection_Established", Me, D)
      O.SetStudioId("566f45ee-de50-4d73-86f1-2bee07828a3a")
      ' T6_Establish_SCP_Connection:OutputPort_T6_Establish_SCP_Connection
      O = New OutputPort_T6_Establish_SCP_Connection("T6_Establish_SCP_Connection", Me, D)
      O.SetStudioId("f2c7c3c3-571b-4447-bf42-82a81bfcac90")
      ' T7_Cd_PDI_Version_Check:OutputPort_T7_Cd_PDI_Version_Check
      O = New OutputPort_T7_Cd_PDI_Version_Check("T7_Cd_PDI_Version_Check", Me, D)
      O.SetStudioId("e3f4e578-8a63-4eb8-be66-72ea6a35d435")
      ' T8_Cd_Initialisation_Request:OutputPort_T8_Cd_Initialisation_Request
      O = New OutputPort_T8_Cd_Initialisation_Request("T8_Cd_Initialisation_Request", Me, D)
      O.SetStudioId("fa0e6933-5e66-4d40-b194-3094550b9665")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class SCI_Prim : Inherits Logical_Components.S_SCI_EfeS_Prim_SR : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "SCI_Prim:S_SCI_EfeS_Prim_SR"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New SCI_Prim_S_SCI_EfeS_Prim_SR_In_SubS_P_SR("SubS_P_SR.SCI_Prim", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        D23_Con_Checksum_Data_Used = SimCore.GetInPorts("D23_Con_Checksum_Data_Used")
        D2_Con_tmax_PDI_Connection = SimCore.GetInPorts("D2_Con_tmax_PDI_Connection")
        D3_Con_PDI_Version = SimCore.GetInPorts("D3_Con_PDI_Version")
        D4_Con_Checksum_Data = SimCore.GetInPorts("D4_Con_Checksum_Data")
        D50_PDI_Connection_State = SimCore.GetOutPorts("D50_PDI_Connection_State")
        DT13_Checksum_Data = SimCore.GetInPorts("DT13_Checksum_Data")
        DT13_Result = SimCore.GetInPorts("DT13_Result")
        DT7_PDI_Version = SimCore.GetOutPorts("DT7_PDI_Version")
        T10_SCP_Connection_Terminated = SimCore.GetInPorts("T10_SCP_Connection_Terminated")
        T12_Terminate_SCP_Connection = SimCore.GetOutPorts("T12_Terminate_SCP_Connection")
        T13_Msg_PDI_Version_Check = SimCore.GetInPorts("T13_Msg_PDI_Version_Check")
        T14_Msg_Start_Initialisation = SimCore.GetInPorts("T14_Msg_Start_Initialisation")
        T15_Msg_Initialisation_Completed = SimCore.GetInPorts("T15_Msg_Initialisation_Completed")
        T20_Protocol_Error = SimCore.GetInPorts("T20_Protocol_Error")
        T21_Formal_Telegram_Error = SimCore.GetInPorts("T21_Formal_Telegram_Error")
        T22_Content_Telegram_Error = SimCore.GetInPorts("T22_Content_Telegram_Error")
        T5_SCP_Connection_Established = SimCore.GetInPorts("T5_SCP_Connection_Established")
        T6_Establish_SCP_Connection = SimCore.GetOutPorts("T6_Establish_SCP_Connection")
        T7_Cd_PDI_Version_Check = SimCore.GetOutPorts("T7_Cd_PDI_Version_Check")
        T8_Cd_Initialisation_Request = SimCore.GetOutPorts("T8_Cd_Initialisation_Request")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class SCI_Sec_F_SCI_EfeS_Sec_SR_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_D23_Con_Checksum_Data_Used : Inherits OInputPort(Of Boolean)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D3_Con_PDI_Version : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D4_Con_Checksum_Data : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_D50_PDI_Connection_State : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_DT13_Checksum_Data : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_DT13_Result : Inherits OOutputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_DT7_PDI_Version : Inherits OInputPort(Of String)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T10_SCP_Connection_Terminated : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T11_PDI_Connection_Established : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T12_Terminate_SCP_Connection : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T13_Msg_PDI_Version_Check : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T14_Msg_Start_Initialisation : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T15_Msg_Initialisation_Completed : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T17_PDI_Connection_Terminated : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T18_Not_Ready_For_PDI_Connection : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T1_Ready_For_PDI_Connection : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T20_Protocol_Error : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T21_Formal_Telegram_Error : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T22_Content_Telegram_Error : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T5_SCP_Connection_Established : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T6_Start_Status_Report : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T7_Cd_PDI_Version_Check : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T8_Cd_Initialisation_Request : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T9_Status_Report_Completed : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SCI_Sec)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port D50_PDI_Connection_State in invocation context SCI_Sec
      ' -- to D50_PDI_Connection_State_S|inp at SubS_P_SR.D50_PDI_Connection_State_S
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.D50_PDI_Connection_State_S")
        Me.BindPort(DestPart, "D50_PDI_Connection_State", "inp", ErrList)
      Next
      ' -- to F_SCI_P|D21_F_SCI_EfeS_Gen_SR_State at SubS_P_SR.F_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.F_SCI_P")
        Me.BindPort(DestPart, "D50_PDI_Connection_State", "D21_F_SCI_EfeS_Gen_SR_State", ErrList)
      Next
      ' Port DT13_Checksum_Data in invocation context SCI_Sec
      ' -- to DT13_Checksum_data|inp at SubS_P_SR.DT13_Checksum_data
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.DT13_Checksum_data")
        Me.BindPort(DestPart, "DT13_Checksum_Data", "inp", ErrList)
      Next
      ' -- to SCI_Prim|DT13_Checksum_Data at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "DT13_Checksum_Data", "DT13_Checksum_Data", ErrList)
      Next
      ' Port DT13_Result in invocation context SCI_Sec
      ' -- to DT13_Result|inp at SubS_P_SR.DT13_Result
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.DT13_Result")
        Me.BindPort(DestPart, "DT13_Result", "inp", ErrList)
      Next
      ' -- to SCI_Prim|DT13_Result at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "DT13_Result", "DT13_Result", ErrList)
      Next
      ' Port T11_PDI_Connection_Established in invocation context SCI_Sec
      ' -- to EST|T9_PDI_Connection_Established at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "T11_PDI_Connection_Established", "T9_PDI_Connection_Established", ErrList)
      Next
      ' Port T12_Terminate_SCP_Connection in invocation context SCI_Sec
      ' -- to T12_Disconnect_SCP|inp at SubS_P_SR.T12_Disconnect_SCP
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T12_Disconnect_SCP")
        Me.BindPort(DestPart, "T12_Terminate_SCP_Connection", "inp", ErrList)
      Next
      ' Port T13_Msg_PDI_Version_Check in invocation context SCI_Sec
      ' -- to SCI_Prim|T13_Msg_PDI_Version_Check at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "T13_Msg_PDI_Version_Check", "T13_Msg_PDI_Version_Check", ErrList)
      Next
      ' -- to T13_Msg_PDI_Version_Check|inp at SubS_P_SR.T13_Msg_PDI_Version_Check
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T13_Msg_PDI_Version_Check")
        Me.BindPort(DestPart, "T13_Msg_PDI_Version_Check", "inp", ErrList)
      Next
      ' Port T14_Msg_Start_Initialisation in invocation context SCI_Sec
      ' -- to SCI_Prim|T14_Msg_Start_Initialisation at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "T14_Msg_Start_Initialisation", "T14_Msg_Start_Initialisation", ErrList)
      Next
      ' -- to T14_Msg_Start_Initialisation|inp at SubS_P_SR.T14_Msg_Start_Initialisation
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T14_Msg_Start_Initialisation")
        Me.BindPort(DestPart, "T14_Msg_Start_Initialisation", "inp", ErrList)
      Next
      ' Port T15_Msg_Initialisation_Completed in invocation context SCI_Sec
      ' -- to SCI_Prim|T15_Msg_Initialisation_Completed at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "T15_Msg_Initialisation_Completed", "T15_Msg_Initialisation_Completed", ErrList)
      Next
      ' -- to T15_Msg_Initialisation_Completed|inp at SubS_P_SR.T15_Msg_Initialisation_Completed
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T15_Msg_Initialisation_Completed")
        Me.BindPort(DestPart, "T15_Msg_Initialisation_Completed", "inp", ErrList)
      Next
      ' Port T17_PDI_Connection_Terminated in invocation context SCI_Sec
      ' -- to EST|T10_PDI_Connection_Terminated at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "T17_PDI_Connection_Terminated", "T10_PDI_Connection_Terminated", ErrList)
      Next
      ' Port T6_Start_Status_Report in invocation context SCI_Sec
      ' -- to F_SCI_P|T18_Start_Status_Report at SubS_P_SR.F_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.F_SCI_P")
        Me.BindPort(DestPart, "T6_Start_Status_Report", "T18_Start_Status_Report", ErrList)
      Next
      ' -- to T18_Start_Status_Report|inp at SubS_P_SR.T18_Start_Status_Report
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T18_Start_Status_Report")
        Me.BindPort(DestPart, "T6_Start_Status_Report", "inp", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As SIMULATOR.Logical_Components.F_SCI_EfeS_Sec_SR)
      MyBase.New(D, N)
      SetStudioId("1afedb6d-ed4a-4e8b-bf09-3163061920ed")
      Dim O As Object
      ' D23_Con_Checksum_Data_Used:InputPort_D23_Con_Checksum_Data_Used
      O = New InputPort_D23_Con_Checksum_Data_Used("D23_Con_Checksum_Data_Used", Me, D)
      O.SetStudioId("fc7e120b-f75f-4f48-9928-4d00efe15b47")
      ' D3_Con_PDI_Version:InputPort_D3_Con_PDI_Version
      O = New InputPort_D3_Con_PDI_Version("D3_Con_PDI_Version", Me, D)
      O.SetStudioId("08bce560-5c17-455b-9498-3f626352a31e")
      ' D4_Con_Checksum_Data:InputPort_D4_Con_Checksum_Data
      O = New InputPort_D4_Con_Checksum_Data("D4_Con_Checksum_Data", Me, D)
      O.SetStudioId("f073d1a3-684d-4cbc-b54c-833fd95be5ad")
      ' D50_PDI_Connection_State:OutputPort_D50_PDI_Connection_State
      O = New OutputPort_D50_PDI_Connection_State("D50_PDI_Connection_State", Me, D)
      O.SetStudioId("8647f74d-c156-4c0d-b216-e0c09d27f19b")
      ' DT13_Checksum_Data:OutputPort_DT13_Checksum_Data
      O = New OutputPort_DT13_Checksum_Data("DT13_Checksum_Data", Me, D)
      O.SetStudioId("919908c4-50b1-4e8e-9e6b-41258403f3a2")
      ' DT13_Result:OutputPort_DT13_Result
      O = New OutputPort_DT13_Result("DT13_Result", Me, D)
      O.SetStudioId("bbd2db15-f920-425c-8fb4-4b7d983d5dfb")
      ' DT7_PDI_Version:InputPort_DT7_PDI_Version
      O = New InputPort_DT7_PDI_Version("DT7_PDI_Version", Me, D)
      O.SetStudioId("8f50b91e-fc5e-43dc-983d-1be04ed7ccc8")
      ' T10_SCP_Connection_Terminated:InputPort_T10_SCP_Connection_Terminated
      O = New InputPort_T10_SCP_Connection_Terminated("T10_SCP_Connection_Terminated", Me, D)
      O.SetStudioId("39028a18-c287-4141-9eee-76a524de5e5e")
      ' T11_PDI_Connection_Established:OutputPort_T11_PDI_Connection_Established
      O = New OutputPort_T11_PDI_Connection_Established("T11_PDI_Connection_Established", Me, D)
      O.SetStudioId("dce69a04-7d01-45dc-b612-fa4ef12bdfed")
      ' T12_Terminate_SCP_Connection:OutputPort_T12_Terminate_SCP_Connection
      O = New OutputPort_T12_Terminate_SCP_Connection("T12_Terminate_SCP_Connection", Me, D)
      O.SetStudioId("4a9e63c6-11f1-4b91-9f4d-eb131b41113c")
      ' T13_Msg_PDI_Version_Check:OutputPort_T13_Msg_PDI_Version_Check
      O = New OutputPort_T13_Msg_PDI_Version_Check("T13_Msg_PDI_Version_Check", Me, D)
      O.SetStudioId("93da9111-6840-4390-93fd-5003bc786c17")
      ' T14_Msg_Start_Initialisation:OutputPort_T14_Msg_Start_Initialisation
      O = New OutputPort_T14_Msg_Start_Initialisation("T14_Msg_Start_Initialisation", Me, D)
      O.SetStudioId("cd3a0b5f-68cf-4569-a950-b85713f7ea01")
      ' T15_Msg_Initialisation_Completed:OutputPort_T15_Msg_Initialisation_Completed
      O = New OutputPort_T15_Msg_Initialisation_Completed("T15_Msg_Initialisation_Completed", Me, D)
      O.SetStudioId("78b93ac9-641a-4fc6-b916-dfafcd0f25db")
      ' T17_PDI_Connection_Terminated:OutputPort_T17_PDI_Connection_Terminated
      O = New OutputPort_T17_PDI_Connection_Terminated("T17_PDI_Connection_Terminated", Me, D)
      O.SetStudioId("b4e77b7e-dc06-4d19-91cb-76a66c78adbe")
      ' T18_Not_Ready_For_PDI_Connection:InputPort_T18_Not_Ready_For_PDI_Connection
      O = New InputPort_T18_Not_Ready_For_PDI_Connection("T18_Not_Ready_For_PDI_Connection", Me, D)
      O.SetStudioId("0f93525c-2949-420b-be0c-6c40cda6c064")
      ' T1_Ready_For_PDI_Connection:InputPort_T1_Ready_For_PDI_Connection
      O = New InputPort_T1_Ready_For_PDI_Connection("T1_Ready_For_PDI_Connection", Me, D)
      O.SetStudioId("36330354-df41-415d-8d5a-d21afddf05e4")
      ' T20_Protocol_Error:InputPort_T20_Protocol_Error
      O = New InputPort_T20_Protocol_Error("T20_Protocol_Error", Me, D)
      O.SetStudioId("e4971e81-1468-420b-b87f-66f0371340ec")
      ' T21_Formal_Telegram_Error:InputPort_T21_Formal_Telegram_Error
      O = New InputPort_T21_Formal_Telegram_Error("T21_Formal_Telegram_Error", Me, D)
      O.SetStudioId("0e0762a5-f3bb-4d2b-81a3-3f96e642feb0")
      ' T22_Content_Telegram_Error:InputPort_T22_Content_Telegram_Error
      O = New InputPort_T22_Content_Telegram_Error("T22_Content_Telegram_Error", Me, D)
      O.SetStudioId("078923fd-b6eb-441b-b365-2b9e24ce0729")
      ' T5_SCP_Connection_Established:InputPort_T5_SCP_Connection_Established
      O = New InputPort_T5_SCP_Connection_Established("T5_SCP_Connection_Established", Me, D)
      O.SetStudioId("e7c448d3-b21e-493b-b58c-606f36394dfe")
      ' T6_Start_Status_Report:OutputPort_T6_Start_Status_Report
      O = New OutputPort_T6_Start_Status_Report("T6_Start_Status_Report", Me, D)
      O.SetStudioId("6c9674ff-8409-4755-9560-7e3514e57f8c")
      ' T7_Cd_PDI_Version_Check:InputPort_T7_Cd_PDI_Version_Check
      O = New InputPort_T7_Cd_PDI_Version_Check("T7_Cd_PDI_Version_Check", Me, D)
      O.SetStudioId("2519b22f-a0fc-429e-af90-5110f69952ea")
      ' T8_Cd_Initialisation_Request:InputPort_T8_Cd_Initialisation_Request
      O = New InputPort_T8_Cd_Initialisation_Request("T8_Cd_Initialisation_Request", Me, D)
      O.SetStudioId("406a7fcf-ddde-452e-938f-15801cd3ada9")
      ' T9_Status_Report_Completed:InputPort_T9_Status_Report_Completed
      O = New InputPort_T9_Status_Report_Completed("T9_Status_Report_Completed", Me, D)
      O.SetStudioId("49c6cc87-e5bd-4864-a8fb-95f804826282")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class SCI_Sec : Inherits Logical_Components.F_SCI_EfeS_Sec_SR : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "SCI_Sec:F_SCI_EfeS_Sec_SR"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New SCI_Sec_F_SCI_EfeS_Sec_SR_In_SubS_P_SR("SubS_P_SR.SCI_Sec", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        D23_Con_Checksum_Data_Used = SimCore.GetInPorts("D23_Con_Checksum_Data_Used")
        D3_Con_PDI_Version = SimCore.GetInPorts("D3_Con_PDI_Version")
        D4_Con_Checksum_Data = SimCore.GetInPorts("D4_Con_Checksum_Data")
        D50_PDI_Connection_State = SimCore.GetOutPorts("D50_PDI_Connection_State")
        DT13_Checksum_Data = SimCore.GetOutPorts("DT13_Checksum_Data")
        DT13_Result = SimCore.GetOutPorts("DT13_Result")
        DT7_PDI_Version = SimCore.GetInPorts("DT7_PDI_Version")
        T10_SCP_Connection_Terminated = SimCore.GetInPorts("T10_SCP_Connection_Terminated")
        T11_PDI_Connection_Established = SimCore.GetOutPorts("T11_PDI_Connection_Established")
        T12_Terminate_SCP_Connection = SimCore.GetOutPorts("T12_Terminate_SCP_Connection")
        T13_Msg_PDI_Version_Check = SimCore.GetOutPorts("T13_Msg_PDI_Version_Check")
        T14_Msg_Start_Initialisation = SimCore.GetOutPorts("T14_Msg_Start_Initialisation")
        T15_Msg_Initialisation_Completed = SimCore.GetOutPorts("T15_Msg_Initialisation_Completed")
        T17_PDI_Connection_Terminated = SimCore.GetOutPorts("T17_PDI_Connection_Terminated")
        T18_Not_Ready_For_PDI_Connection = SimCore.GetInPorts("T18_Not_Ready_For_PDI_Connection")
        T1_Ready_For_PDI_Connection = SimCore.GetInPorts("T1_Ready_For_PDI_Connection")
        T20_Protocol_Error = SimCore.GetInPorts("T20_Protocol_Error")
        T21_Formal_Telegram_Error = SimCore.GetInPorts("T21_Formal_Telegram_Error")
        T22_Content_Telegram_Error = SimCore.GetInPorts("T22_Content_Telegram_Error")
        T5_SCP_Connection_Established = SimCore.GetInPorts("T5_SCP_Connection_Established")
        T6_Start_Status_Report = SimCore.GetOutPorts("T6_Start_Status_Report")
        T7_Cd_PDI_Version_Check = SimCore.GetInPorts("T7_Cd_PDI_Version_Check")
        T8_Cd_Initialisation_Request = SimCore.GetInPorts("T8_Cd_Initialisation_Request")
        T9_Status_Report_Completed = SimCore.GetInPorts("T9_Status_Report_Completed")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class SMI_F_SMI_EfeS_SR_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_D1_Con_t_Ini_Def_Delay : Inherits OInputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D2_Con_t_Ini_Step : Inherits OInputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D3_Con_t_Ini_Max : Inherits OInputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D4_Con_tmax_Response_MDM : Inherits OInputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_D5_Con_tmax_DataTransmission : Inherits OInputPort(Of Integer)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T10_Data_Valid : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T11_Data_Invalid : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T12_Data_Installation_Successfully : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T13_Data_Update_After_Booting : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T14_Data_Update_After_Operational : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T15_Data_Update_In_Initialising : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T16_Data_Installation_Complete : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T19_Validate_Data : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T20_Ready_For_Update_Of_Data : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class OutputPort_T21_Data_Update_Finished : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T22_Data_Update_Stop : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T6_Data_Up_To_Date : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T7_Data_Not_Up_To_Date : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T8_Data : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Class InputPort_T9_Transmission_Complete : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.SMI)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port T16_Data_Installation_Complete in invocation context SMI
      ' -- to EST|T16_Data_Installation_Complete at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "T16_Data_Installation_Complete", "T16_Data_Installation_Complete", ErrList)
      Next
      ' Port T19_Validate_Data in invocation context SMI
      ' -- to T19_Validate_Data|inp at SubS_P_SR.T19_Validate_Data
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T19_Validate_Data")
        Me.BindPort(DestPart, "T19_Validate_Data", "inp", ErrList)
      Next
      ' Port T20_Ready_For_Update_Of_Data in invocation context SMI
      ' -- to T20_Ready_For_Update_Of_Data|inp at SubS_P_SR.T20_Ready_For_Update_Of_Data
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T20_Ready_For_Update_Of_Data")
        Me.BindPort(DestPart, "T20_Ready_For_Update_Of_Data", "inp", ErrList)
      Next
      ' Port T21_Data_Update_Finished in invocation context SMI
      ' -- to EST|T17_Data_Update_Finished at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "T21_Data_Update_Finished", "T17_Data_Update_Finished", ErrList)
      Next
      ' -- to T21_Data_Update_Finished|inp at SubS_P_SR.T21_Data_Update_Finished
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T21_Data_Update_Finished")
        Me.BindPort(DestPart, "T21_Data_Update_Finished", "inp", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As SIMULATOR.Logical_Components.F_SMI_EfeS_SR)
      MyBase.New(D, N)
      SetStudioId("8b9332e7-835c-462f-8f90-f91cfdf2e3da")
      Dim O As Object
      ' D1_Con_t_Ini_Def_Delay:InputPort_D1_Con_t_Ini_Def_Delay
      O = New InputPort_D1_Con_t_Ini_Def_Delay("D1_Con_t_Ini_Def_Delay", Me, D)
      O.SetStudioId("c32c9d70-4f06-4fbc-add4-a6bdf5f93632")
      ' D2_Con_t_Ini_Step:InputPort_D2_Con_t_Ini_Step
      O = New InputPort_D2_Con_t_Ini_Step("D2_Con_t_Ini_Step", Me, D)
      O.SetStudioId("f89dc1fb-978e-440e-9e83-9c7e95f08409")
      ' D3_Con_t_Ini_Max:InputPort_D3_Con_t_Ini_Max
      O = New InputPort_D3_Con_t_Ini_Max("D3_Con_t_Ini_Max", Me, D)
      O.SetStudioId("a061b583-ae76-4304-b3f0-b50f6f3beaf4")
      ' D4_Con_tmax_Response_MDM:InputPort_D4_Con_tmax_Response_MDM
      O = New InputPort_D4_Con_tmax_Response_MDM("D4_Con_tmax_Response_MDM", Me, D)
      O.SetStudioId("d937eaa5-bfa2-4b4a-a4b9-f0f70ff653e3")
      ' D5_Con_tmax_DataTransmission:InputPort_D5_Con_tmax_DataTransmission
      O = New InputPort_D5_Con_tmax_DataTransmission("D5_Con_tmax_DataTransmission", Me, D)
      O.SetStudioId("aff7aafa-5f43-4f7e-a44e-4a85f993d505")
      ' T10_Data_Valid:InputPort_T10_Data_Valid
      O = New InputPort_T10_Data_Valid("T10_Data_Valid", Me, D)
      O.SetStudioId("a6ca2bfb-d4d3-460e-8d63-3c2ecb46d209")
      ' T11_Data_Invalid:InputPort_T11_Data_Invalid
      O = New InputPort_T11_Data_Invalid("T11_Data_Invalid", Me, D)
      O.SetStudioId("7a713d6d-90b6-4a65-ba58-786c2b7b9041")
      ' T12_Data_Installation_Successfully:InputPort_T12_Data_Installation_Successfully
      O = New InputPort_T12_Data_Installation_Successfully("T12_Data_Installation_Successfully", Me, D)
      O.SetStudioId("e1399f8d-a249-4b1c-8c27-f9e18f407254")
      ' T13_Data_Update_After_Booting:InputPort_T13_Data_Update_After_Booting
      O = New InputPort_T13_Data_Update_After_Booting("T13_Data_Update_After_Booting", Me, D)
      O.SetStudioId("cb5ec6b2-ea37-4ff0-95a9-bd9d59fe8010")
      ' T14_Data_Update_After_Operational:InputPort_T14_Data_Update_After_Operational
      O = New InputPort_T14_Data_Update_After_Operational("T14_Data_Update_After_Operational", Me, D)
      O.SetStudioId("5a5f3362-d042-4946-8b18-90092cdbacd0")
      ' T15_Data_Update_In_Initialising:InputPort_T15_Data_Update_In_Initialising
      O = New InputPort_T15_Data_Update_In_Initialising("T15_Data_Update_In_Initialising", Me, D)
      O.SetStudioId("26b74c2c-e348-4099-af46-cf01706cdb94")
      ' T16_Data_Installation_Complete:OutputPort_T16_Data_Installation_Complete
      O = New OutputPort_T16_Data_Installation_Complete("T16_Data_Installation_Complete", Me, D)
      O.SetStudioId("3904861d-574c-4665-9266-170b473e8413")
      ' T19_Validate_Data:OutputPort_T19_Validate_Data
      O = New OutputPort_T19_Validate_Data("T19_Validate_Data", Me, D)
      O.SetStudioId("e6c79878-4fc0-429f-9458-0cebfd72a55b")
      ' T20_Ready_For_Update_Of_Data:OutputPort_T20_Ready_For_Update_Of_Data
      O = New OutputPort_T20_Ready_For_Update_Of_Data("T20_Ready_For_Update_Of_Data", Me, D)
      O.SetStudioId("7b962e9f-85fd-4184-a73a-7aeb5218b033")
      ' T21_Data_Update_Finished:OutputPort_T21_Data_Update_Finished
      O = New OutputPort_T21_Data_Update_Finished("T21_Data_Update_Finished", Me, D)
      O.SetStudioId("8ed91242-6e76-4325-b8aa-84a1d9b8bc62")
      ' T22_Data_Update_Stop:InputPort_T22_Data_Update_Stop
      O = New InputPort_T22_Data_Update_Stop("T22_Data_Update_Stop", Me, D)
      O.SetStudioId("2ce95d8a-aa13-4047-82f8-ff421d9c223a")
      ' T6_Data_Up_To_Date:InputPort_T6_Data_Up_To_Date
      O = New InputPort_T6_Data_Up_To_Date("T6_Data_Up_To_Date", Me, D)
      O.SetStudioId("07203715-8b22-4699-993c-7eb8c217ac8b")
      ' T7_Data_Not_Up_To_Date:InputPort_T7_Data_Not_Up_To_Date
      O = New InputPort_T7_Data_Not_Up_To_Date("T7_Data_Not_Up_To_Date", Me, D)
      O.SetStudioId("969cea50-2698-4c26-abbc-17b2d734dab5")
      ' T8_Data:InputPort_T8_Data
      O = New InputPort_T8_Data("T8_Data", Me, D)
      O.SetStudioId("41b90d51-a692-432c-a3fe-27872533e296")
      ' T9_Transmission_Complete:InputPort_T9_Transmission_Complete
      O = New InputPort_T9_Transmission_Complete("T9_Transmission_Complete", Me, D)
      O.SetStudioId("61406a48-f812-474b-93e7-bfb758df468a")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class SMI : Inherits Logical_Components.F_SMI_EfeS_SR : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "SMI:F_SMI_EfeS_SR"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New SMI_F_SMI_EfeS_SR_In_SubS_P_SR("SubS_P_SR.SMI", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        D1_Con_t_Ini_Def_Delay = SimCore.GetInPorts("D1_Con_t_Ini_Def_Delay")
        D2_Con_t_Ini_Step = SimCore.GetInPorts("D2_Con_t_Ini_Step")
        D3_Con_t_Ini_Max = SimCore.GetInPorts("D3_Con_t_Ini_Max")
        D4_Con_tmax_Response_MDM = SimCore.GetInPorts("D4_Con_tmax_Response_MDM")
        D5_Con_tmax_DataTransmission = SimCore.GetInPorts("D5_Con_tmax_DataTransmission")
        T10_Data_Valid = SimCore.GetInPorts("T10_Data_Valid")
        T11_Data_Invalid = SimCore.GetInPorts("T11_Data_Invalid")
        T12_Data_Installation_Successfully = SimCore.GetInPorts("T12_Data_Installation_Successfully")
        T13_Data_Update_After_Booting = SimCore.GetInPorts("T13_Data_Update_After_Booting")
        T14_Data_Update_After_Operational = SimCore.GetInPorts("T14_Data_Update_After_Operational")
        T15_Data_Update_In_Initialising = SimCore.GetInPorts("T15_Data_Update_In_Initialising")
        T16_Data_Installation_Complete = SimCore.GetOutPorts("T16_Data_Installation_Complete")
        T19_Validate_Data = SimCore.GetOutPorts("T19_Validate_Data")
        T20_Ready_For_Update_Of_Data = SimCore.GetOutPorts("T20_Ready_For_Update_Of_Data")
        T21_Data_Update_Finished = SimCore.GetOutPorts("T21_Data_Update_Finished")
        T22_Data_Update_Stop = SimCore.GetInPorts("T22_Data_Update_Stop")
        T6_Data_Up_To_Date = SimCore.GetInPorts("T6_Data_Up_To_Date")
        T7_Data_Not_Up_To_Date = SimCore.GetInPorts("T7_Data_Not_Up_To_Date")
        T8_Data = SimCore.GetInPorts("T8_Data")
        T9_Transmission_Complete = SimCore.GetInPorts("T9_Transmission_Complete")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T10_Data_Valid_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T10_Data_Valid)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T10_Data_Valid
      ' -- to SMI|T10_Data_Valid at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "T10_Data_Valid", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("810467e0-cfc9-42b1-af39-65d1daa99b17")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("726af687-fbea-4ba1-94d6-10d09d896a9c")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)>
  Public Class T10_Data_Valid : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T10_Data_Valid:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")>
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T10_Data_Valid_PulseButton_In_SubS_P_SR("SubS_P_SR.T10_Data_Valid", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function

  End Class
  'I MODIFIED THIS CLASS:
  Public Class T10_SCP_Connection_Terminated_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T10_SCP_Connection_Terminated)
        MyBase.New(N, Core, PortOwner)

      End Sub

    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T10_SCP_Connection_Terminated
      ' -- to SCI_Prim|T10_SCP_Connection_Terminated at SubS_P_SR.SCI_Prim
      'I commented this out:
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "T10_SCP_Connection_Terminated", ErrList)
      Next
      ' -- to SCI_Sec|T10_SCP_Connection_Terminated at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "outp", "T10_SCP_Connection_Terminated", ErrList)
      Next

    End Sub

    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("ead8e52e-d36c-4b34-8c4b-c66acf012c7a")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("1a1b2a08-7cf7-4961-af12-b9ebe5686569")

    End Sub

  End Class
  'I added this class:
  'Public Class T10_SCP_Connection_Terminated_I_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
  '  Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
  '    Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T10_SCP_Connection_Terminated)
  '      MyBase.New(N, Core, PortOwner)

  '    End Sub

  '  End Class
  '  Public Overrides Sub Bind(ByVal ErrList As OErrorList)
  '    Dim DestPart As OSimDeviceCore = Nothing
  '    UnBind()
  '    ' Port outp in invocation context T10_SCP_Connection_Terminated
  '    ' -- to SCI_Prim|T10_SCP_Connection_Terminated at SubS_P_SR.SCI_Prim
  '    For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
  '      Me.BindPort(DestPart, "outp", "T10_SCP_Connection_Terminated", ErrList)
  '    Next
  '  End Sub

  '  Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
  '    MyBase.New(D, N)
  '    SetStudioId("ead8e52e-d36c-4b34-8c4b-c66acf012c70")
  '    Dim O As Object
  '    ' outp:OutputPort_outp
  '    O = New OutputPort_outp("outp", Me, D)
  '    O.SetStudioId("1a1b2a08-7cf7-4961-af12-b9ebe5686568")
  '  End Sub
  'End Class
  <System.ComponentModel.ToolboxItem(True)>
  Public Class T10_SCP_Connection_Terminated : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T10_SCP_Connection_Terminated:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")>
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T10_SCP_Connection_Terminated_PulseButton_In_SubS_P_SR("SubS_P_SR.T10_SCP_Connection_Terminated", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
  End Class
  'I added this class:
  '<System.ComponentModel.ToolboxItem(True)>
  'Public Class T10_SCP_Connection_Terminated_I : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice
  '  Protected Shadows WithEvents SimCore As OSimDeviceCore
  '  Private _SySimTooltip As String = "T10_SCP_Connection_Terminated:PulseButton"
  '  <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")>
  '  Public Property SySimTooltip() As String
  '    Get
  '      Return _SySimTooltip
  '    End Get
  '    Set(ByVal Value As String)
  '      _SySimTooltip = Value
  '    End Set
  '  End Property
  '  Private LastScanTime As TimeSpan
  '  Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
  '    If SimCore Is Nothing Then
  '      SimCore = New T10_SCP_Connection_Terminated_I_PulseButton_In_SubS_P_SR("SubS_P_SR.T10_SCP_Connection_Terminated", Me)
  '      Dim T As Type = Me.GetType()
  '      Dim BaseT As Type = T.BaseType
  '      While BaseT IsNot Nothing
  '        Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
  '        If Prop IsNot Nothing Then
  '          Prop.SetValue(Me, SimCore, Nothing)
  '        End If
  '        BaseT = BaseT.BaseType
  '      End While
  '      outp = SimCore.GetOutPorts("outp")
  '    End If
  '    Return SimCore
  '  End Function
  'End Class
  Public Class T11_Data_Invalid_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T11_Data_Invalid)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T11_Data_Invalid
      ' -- to SMI|T11_Data_Invalid at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "T11_Data_Invalid", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("7cfd2128-a3c8-43f9-9e75-95e7d2f1acc2")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("7d2c6ef6-ca4a-439f-a6ba-23cd0f795902")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T11_Data_Invalid : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T11_Data_Invalid:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T11_Data_Invalid_PulseButton_In_SubS_P_SR("SubS_P_SR.T11_Data_Invalid", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T12_Data_Installation_Successfully_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T12_Data_Installation_Successfully)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T12_Data_Installation_Successfully
      ' -- to SMI|T12_Data_Installation_Successfully at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "T12_Data_Installation_Successfully", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("911c7297-e2d4-4aee-87fa-ec03a080e640")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("26b2bb64-6afa-4482-892c-4784af372c1c")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T12_Data_Installation_Successfully : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T12_Data_Installation_Successfully:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T12_Data_Installation_Successfully_PulseButton_In_SubS_P_SR("SubS_P_SR.T12_Data_Installation_Successfully", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T12_Disconnect_SCP_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T12_Disconnect_SCP)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("9768e9fe-798f-4119-8f94-2fe821be3776")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("e931853d-2474-4ce6-a99c-2164fc281a4a")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T12_Disconnect_SCP : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T12_Disconnect_SCP:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T12_Disconnect_SCP_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T12_Disconnect_SCP", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T12_Terminate_SCP_Connection_I_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T12_Terminate_SCP_Connection_I)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("a1142fab-3fae-4324-b4fd-7bb9d916cb8c")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("16f9c709-1f70-4d7b-9a55-29f2748e7a2c")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T12_Terminate_SCP_Connection_I : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T12_Terminate_SCP_Connection_I:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T12_Terminate_SCP_Connection_I_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T12_Terminate_SCP_Connection_I", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T13_Msg_PDI_Version_Check_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T13_Msg_PDI_Version_Check)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("e4728dbd-4b1d-4123-bd76-ac91b855e83a")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("b660ae25-a597-44ce-ab1b-8d81aed2d33b")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T13_Msg_PDI_Version_Check : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T13_Msg_PDI_Version_Check:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T13_Msg_PDI_Version_Check_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T13_Msg_PDI_Version_Check", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T14_Msg_Start_Initialisation_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T14_Msg_Start_Initialisation)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("209d65bf-3811-4886-964a-ab472decc3b0")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("7478eb9d-1e3e-4929-b36f-5ad7778b618f")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T14_Msg_Start_Initialisation : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T14_Msg_Start_Initialisation:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T14_Msg_Start_Initialisation_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T14_Msg_Start_Initialisation", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T15_Msg_Initialisation_Completed_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T15_Msg_Initialisation_Completed)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("9cbde6b6-cfca-417f-9743-d15b67e35ee9")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("f9a56222-f822-4167-b8ca-d9e908518038")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T15_Msg_Initialisation_Completed : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T15_Msg_Initialisation_Completed:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T15_Msg_Initialisation_Completed_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T15_Msg_Initialisation_Completed", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T18_Start_Status_Report_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T18_Start_Status_Report)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("29a7c6c1-b520-4c4a-be8b-e0107f6f5857")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("5750581f-a1c1-4c26-88c4-817f16eabbf2")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T18_Start_Status_Report : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T18_Start_Status_Report:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T18_Start_Status_Report_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T18_Start_Status_Report", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T19_Validate_Data_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T19_Validate_Data)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("f7087371-5395-45cd-8eaf-76c3277c9625")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("086ba046-819e-43ca-bb8e-e60be4ea510c")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T19_Validate_Data : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T19_Validate_Data:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T19_Validate_Data_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T19_Validate_Data", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T1_Move_Point_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T1_Move_Point)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T1_Move_Point
      ' -- to S_SCI_P|T10_Move_Point at SubS_P_SR.S_SCI_P
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.S_SCI_P")
        Me.BindPort(DestPart, "outp", "T10_Move_Point", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("ad45c170-de5d-4dc3-afb4-83a7c3a3c4fd")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("c6ed9197-5f57-4fe4-834b-fe87640c7ae5")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T1_Move_Point : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T1_Move_Point:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T1_Move_Point_PulseButton_In_SubS_P_SR("SubS_P_SR.T1_Move_Point", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T1_OUT_Move_Point_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T1_OUT_Move_Point)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("1b365fd2-9c75-4d10-b058-e32fbfc299a3")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("9a858804-972e-4936-9bc3-68420666887d")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T1_OUT_Move_Point : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T1_OUT_Move_Point:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T1_OUT_Move_Point_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T1_OUT_Move_Point", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T1_Power_On_Detected_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T1_Power_On_Detected)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T1_Power_On_Detected
      ' -- to EST|T1_Power_On_Detected at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "outp", "T1_Power_On_Detected", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("90000bdd-2b7c-44b3-bf44-817f4c4e3817")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("ea5a891b-811c-48bd-94a1-f26a54ed473c")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T1_Power_On_Detected : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T1_Power_On_Detected:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T1_Power_On_Detected_PulseButton_In_SubS_P_SR("SubS_P_SR.T1_Power_On_Detected", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T20_Protocol_Error_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T20_Protocol_Error)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T20_Protocol_Error
      ' -- to SCI_Sec|T20_Protocol_Error at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "outp", "T20_Protocol_Error", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("a0b84623-ecbb-4b8b-ad51-d4f12e3bb871")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("de94edd0-30ca-44e1-82f2-e8ec337abb27")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T20_Protocol_Error : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T20_Protocol_Error:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T20_Protocol_Error_PulseButton_In_SubS_P_SR("SubS_P_SR.T20_Protocol_Error", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T20_Protocol_Error_I_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T20_Protocol_Error_I)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T20_Protocol_Error_I
      ' -- to SCI_Prim|T20_Protocol_Error at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "T20_Protocol_Error", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("c73ec70f-5e5e-43d2-b63c-14bd58c5f99d")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("b3658d68-92b5-4691-94f1-94675e8c246a")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T20_Protocol_Error_I : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T20_Protocol_Error_I:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T20_Protocol_Error_I_PulseButton_In_SubS_P_SR("SubS_P_SR.T20_Protocol_Error_I", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T20_Ready_For_Update_Of_Data_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T20_Ready_For_Update_Of_Data)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("3d36f945-f83e-458c-b6de-6085da7e2b7f")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("ca1b5560-a94e-4ddd-9bab-bacb03279083")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T20_Ready_For_Update_Of_Data : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T20_Ready_For_Update_Of_Data:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T20_Ready_For_Update_Of_Data_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T20_Ready_For_Update_Of_Data", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T21_Data_Update_Finished_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T21_Data_Update_Finished)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("353beb12-a298-4ecc-9cd5-9726cbdc894f")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("793ab7a1-7a66-4008-bf28-c94378a5b714")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T21_Data_Update_Finished : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T21_Data_Update_Finished:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T21_Data_Update_Finished_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T21_Data_Update_Finished", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T21_Formal_Telegram_Error_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T21_Formal_Telegram_Error)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T21_Formal_Telegram_Error
      ' -- to SCI_Sec|T21_Formal_Telegram_Error at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "outp", "T21_Formal_Telegram_Error", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("fd23c4bb-381a-46bc-9a6f-412d2dd5d0b4")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("01f43c9d-22ae-4674-818e-472acb2c912e")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T21_Formal_Telegram_Error : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T21_Formal_Telegram_Error:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T21_Formal_Telegram_Error_PulseButton_In_SubS_P_SR("SubS_P_SR.T21_Formal_Telegram_Error", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T21_Formal_Telegram_Error_I_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T21_Formal_Telegram_Error_I)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T21_Formal_Telegram_Error_I
      ' -- to SCI_Prim|T21_Formal_Telegram_Error at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "T21_Formal_Telegram_Error", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("d0e320e1-48ce-4188-9a2e-cbfe7359107c")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("5b430c1e-9b2e-4ace-bd09-ccf5de6a09c0")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T21_Formal_Telegram_Error_I : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T21_Formal_Telegram_Error_I:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T21_Formal_Telegram_Error_I_PulseButton_In_SubS_P_SR("SubS_P_SR.T21_Formal_Telegram_Error_I", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T22_Content_Telegram_Error_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T22_Content_Telegram_Error)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T22_Content_Telegram_Error
      ' -- to SCI_Sec|T22_Content_Telegram_Error at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "outp", "T22_Content_Telegram_Error", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("83566a88-f150-4750-999c-5950beeeba14")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("3b72f44a-4960-45f4-b23e-92b0904cbf68")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T22_Content_Telegram_Error : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T22_Content_Telegram_Error:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T22_Content_Telegram_Error_PulseButton_In_SubS_P_SR("SubS_P_SR.T22_Content_Telegram_Error", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T22_Content_Telegram_Error_I_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T22_Content_Telegram_Error_I)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T22_Content_Telegram_Error_I
      ' -- to SCI_Prim|T22_Content_Telegram_Error at SubS_P_SR.SCI_Prim
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "T22_Content_Telegram_Error", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("f4275289-3681-4e13-8620-e43033ff088c")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("4f9b4bf9-3912-460c-94e5-6c0208a2f54b")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T22_Content_Telegram_Error_I : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T22_Content_Telegram_Error_I:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T22_Content_Telegram_Error_I_PulseButton_In_SubS_P_SR("SubS_P_SR.T22_Content_Telegram_Error_I", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T23_Sending_Status_Report_Completed_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T23_Sending_Status_Report_Completed)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("3e265343-f91e-495b-b7e0-97eb49e641e4")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("d0cc672c-d9a4-4649-965e-364b904cccdc")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T23_Sending_Status_Report_Completed : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T23_Sending_Status_Report_Completed:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T23_Sending_Status_Report_Completed_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T23_Sending_Status_Report_Completed", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T23_SIL_Not_Fulfilled_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T23_SIL_Not_Fulfilled)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("5cef8e21-d4f8-4121-b642-8c9d2d99defa")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("717aa488-de90-4e35-a905-3049de9fe75a")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T23_SIL_Not_Fulfilled : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T23_SIL_Not_Fulfilled:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T23_SIL_Not_Fulfilled_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T23_SIL_Not_Fulfilled", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T2_Msg_Point_Position_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T2_Msg_Point_Position)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("1828683d-ba24-46f4-97bf-02265a1da617")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("a528b687-6b2d-4dac-90d3-42b33c9426f1")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T2_Msg_Point_Position : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T2_Msg_Point_Position:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T2_Msg_Point_Position_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T2_Msg_Point_Position", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T2_OUT_Point_Position_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T2_OUT_Point_Position)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("11e72911-4654-458e-8b78-712d89204679")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("09394b81-6f1a-436f-ab64-b811b5c0c26b")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T2_OUT_Point_Position : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T2_OUT_Point_Position:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T2_OUT_Point_Position_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T2_OUT_Point_Position", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T2_Power_Off_Detected_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T2_Power_Off_Detected)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T2_Power_Off_Detected
      ' -- to EST|T2_Power_Off_Detected at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "outp", "T2_Power_Off_Detected", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("a3b81d63-39a8-4cae-b9cf-be61865de3a9")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("1a68c231-91a8-46db-9db6-b87128f153b5")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T2_Power_Off_Detected : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T2_Power_Off_Detected:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T2_Power_Off_Detected_PulseButton_In_SubS_P_SR("SubS_P_SR.T2_Power_Off_Detected", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T3_Msg_Timeout_PulsedPortStatusBox_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T3_Msg_Timeout)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulsedPortStatusBox.PulsedPortStatusBox)
      MyBase.New(D, N)
      SetStudioId("ea5b82db-236d-4c13-a513-2323168f233c")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("31cdfcba-52cd-4a8f-abae-923a6dd545a8")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T3_Msg_Timeout : Inherits EULYNX_Profile.Controls.PulsedPortStatusBox.PulsedPortStatusBox : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T3_Msg_Timeout:PulsedPortStatusBox"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T3_Msg_Timeout_PulsedPortStatusBox_In_SubS_P_SR("SubS_P_SR.T3_Msg_Timeout", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T3_Reset_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T3_Reset)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T3_Reset
      ' -- to EST|T3_Reset at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "outp", "T3_Reset", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("0b021f03-950b-4b0c-83b3-4f1b76c00656")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("d45ce4ab-eecb-42f4-b03e-470a0194d943")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T3_Reset : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T3_Reset:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T3_Reset_PulseButton_In_SubS_P_SR("SubS_P_SR.T3_Reset", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T4_Booted_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T4_Booted)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T4_Booted
      ' -- to EST|T4_Booted at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "outp", "T4_Booted", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("b349ecd7-922e-43a4-85a6-8cab69d5c09f")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("898ca521-de80-4eb2-aeb7-21250aff7118")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T4_Booted : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T4_Booted:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T4_Booted_PulseButton_In_SubS_P_SR("SubS_P_SR.T4_Booted", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T4_Information_No_End_Position_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T4_Information_No_End_Position)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("8451a16e-071c-4cf5-9539-63f68f5ddb12")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("304c8812-f4de-4e84-9ab0-e67608138672")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T4_Information_No_End_Position : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T4_Information_No_End_Position:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T4_Information_No_End_Position_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T4_Information_No_End_Position", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T5_Info_End_Position_Arrived_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T5_Info_End_Position_Arrived)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("a7ba83e3-66bc-44d2-8f36-35df7c9c6d19")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("9c083b14-ef47-4b3c-bd17-664ef286fc30")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)>
  Public Class T5_Info_End_Position_Arrived : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T5_Info_End_Position_Arrived:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")>
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T5_Info_End_Position_Arrived_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T5_Info_End_Position_Arrived", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function

    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub

    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub

    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub

  End Class
  'I MODIFIED THIS CLASS:
  Public Class T5_SCP_Connection_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T5_SCP_Connection)
        MyBase.New(N, Core, PortOwner)

      End Sub

    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T5_SCP_Connection
      ' -- to SCI_Prim|T5_SCP_Connection_Established at SubS_P_SR.SCI_Prim
      'I commented this out:
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
        Me.BindPort(DestPart, "outp", "T5_SCP_Connection_Established", ErrList)
      Next
      ' -- to SCI_Sec|T5_SCP_Connection_Established at SubS_P_SR.SCI_Sec
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Sec")
        Me.BindPort(DestPart, "outp", "T5_SCP_Connection_Established", ErrList)
      Next

    End Sub

    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("24a5ea94-c71a-4f8b-af06-2b5cbafedfe8")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("90c29acb-d226-46ce-8ac8-f06b303f63e2")

    End Sub

  End Class
  'I added this class:
  'Public Class T5_SCP_Connection_I_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
  '  Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
  '    Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T5_SCP_Connection)
  '      MyBase.New(N, Core, PortOwner)

  '    End Sub

  '  End Class
  '  Public Overrides Sub Bind(ByVal ErrList As OErrorList)
  '    Dim DestPart As OSimDeviceCore = Nothing
  '    UnBind()
  '    ' Port outp in invocation context T5_SCP_Connection
  '    ' -- to SCI_Prim|T5_SCP_Connection_Established at SubS_P_SR.SCI_Prim
  '    For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SCI_Prim")
  '      Me.BindPort(DestPart, "outp", "T5_SCP_Connection_Established", ErrList)
  '    Next
  '  End Sub

  '  Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
  '    MyBase.New(D, N)
  '    SetStudioId("24a5ea94-c71a-4f8b-af06-2b5cbafedfe7")
  '    Dim O As Object
  '    ' outp:OutputPort_outp
  '    O = New OutputPort_outp("outp", Me, D)
  '    O.SetStudioId("90c29acb-d226-46ce-8ac8-f06b303f63e1")

  '  End Sub

  'End Class
  <System.ComponentModel.ToolboxItem(True)>
  Public Class T5_SCP_Connection : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T5_SCP_Connection:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")>
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T5_SCP_Connection_PulseButton_In_SubS_P_SR("SubS_P_SR.T5_SCP_Connection", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function

  End Class
  'I added this class:
  '<System.ComponentModel.ToolboxItem(True)>
  'Public Class T5_SCP_Connection_I : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice
  '  Protected Shadows WithEvents SimCore As OSimDeviceCore
  '  Private _SySimTooltip As String = "T5_SCP_Connection:PulseButton"
  '  <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")>
  '  Public Property SySimTooltip() As String
  '    Get
  '      Return _SySimTooltip
  '    End Get
  '    Set(ByVal Value As String)
  '      _SySimTooltip = Value
  '    End Set
  '  End Property
  '  Private LastScanTime As TimeSpan
  '  Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
  '    If SimCore Is Nothing Then
  '      SimCore = New T5_SCP_Connection_I_PulseButton_In_SubS_P_SR("SubS_P_SR.T5_SCP_Connection", Me)
  '      Dim T As Type = Me.GetType()
  '      Dim BaseT As Type = T.BaseType
  '      While BaseT IsNot Nothing
  '        Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
  '        If Prop IsNot Nothing Then
  '          Prop.SetValue(Me, SimCore, Nothing)
  '        End If
  '        BaseT = BaseT.BaseType
  '      End While
  '      outp = SimCore.GetOutPorts("outp")
  '    End If
  '    Return SimCore
  '  End Function

  'End Class
  Public Class T5_SIL_Not_Fulfilled_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T5_SIL_Not_Fulfilled)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T5_SIL_Not_Fulfilled
      ' -- to EST|T5_SIL_Not_Fulfilled at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "outp", "T5_SIL_Not_Fulfilled", ErrList)
      Next
      ' -- to T23_SIL_Not_Fulfilled|inp at SubS_P_SR.T23_SIL_Not_Fulfilled
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.T23_SIL_Not_Fulfilled")
        Me.BindPort(DestPart, "outp", "inp", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("1c174014-d085-485b-acea-81046b3d3d35")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("183624ac-c855-459f-aa44-1a2be6ed1e72")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T5_SIL_Not_Fulfilled : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T5_SIL_Not_Fulfilled:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T5_SIL_Not_Fulfilled_PulseButton_In_SubS_P_SR("SubS_P_SR.T5_SIL_Not_Fulfilled", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T6_Data_Up_To_Date_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T6_Data_Up_To_Date)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T6_Data_Up_To_Date
      ' -- to SMI|T6_Data_Up_To_Date at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "T6_Data_Up_To_Date", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("304e3378-c45e-4b1b-8ec6-3334fcba169f")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("99696a29-7861-4aa1-bd71-79371ef4ff71")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T6_Data_Up_To_Date : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T6_Data_Up_To_Date:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T6_Data_Up_To_Date_PulseButton_In_SubS_P_SR("SubS_P_SR.T6_Data_Up_To_Date", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T6_Establish_SCP_Connection_I_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T6_Establish_SCP_Connection_I)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("a040469b-36e7-4499-8f65-c24586b85cd5")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("53f26989-a3b7-44af-a9c2-db6e00a42afb")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T6_Establish_SCP_Connection_I : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T6_Establish_SCP_Connection_I:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T6_Establish_SCP_Connection_I_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T6_Establish_SCP_Connection_I", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T6_Information_Trailed_Point_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T6_Information_Trailed_Point)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("bdcebe1a-f031-4c94-90fa-a8d930da0076")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("dfce21de-fd80-46e8-975f-d5d055f441be")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T6_Information_Trailed_Point : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T6_Information_Trailed_Point:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T6_Information_Trailed_Point_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T6_Information_Trailed_Point", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T7_Cd_PDI_Version_Check1_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T7_Cd_PDI_Version_Check1)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("5e86978e-d4da-4b50-b5a6-cf3e07b10dc5")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("59d6b937-639f-4b3a-aee2-b71e39b0ad73")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T7_Cd_PDI_Version_Check1 : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T7_Cd_PDI_Version_Check1:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T7_Cd_PDI_Version_Check1_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T7_Cd_PDI_Version_Check1", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T7_Data_Not_Up_To_Date_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T7_Data_Not_Up_To_Date)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T7_Data_Not_Up_To_Date
      ' -- to SMI|T7_Data_Not_Up_To_Date at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "T7_Data_Not_Up_To_Date", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("71e05544-f3f2-4402-af38-74e1b43ce04b")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("55d3ffab-e4ea-48c3-bae3-4ae87ea6ab6a")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T7_Data_Not_Up_To_Date : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T7_Data_Not_Up_To_Date:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T7_Data_Not_Up_To_Date_PulseButton_In_SubS_P_SR("SubS_P_SR.T7_Data_Not_Up_To_Date", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T7_Information_Out_Of_Sequence_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T7_Information_Out_Of_Sequence)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("6e4b0b69-f4b3-46ff-9545-b0809060a3f1")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("60e7cf64-ae73-4a57-965a-a6773e646ca9")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T7_Information_Out_Of_Sequence : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T7_Information_Out_Of_Sequence:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T7_Information_Out_Of_Sequence_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T7_Information_Out_Of_Sequence", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T7_Invalid_Or_Missing_Basic_Data_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T7_Invalid_Or_Missing_Basic_Data)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T7_Invalid_Or_Missing_Basic_Data
      ' -- to EST|T7_Invalid_Or_Missing_Basic_Data at SubS_P_SR.EST
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.EST")
        Me.BindPort(DestPart, "outp", "T7_Invalid_Or_Missing_Basic_Data", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("e3fe0c69-1f86-45dc-9f3b-d65250403a95")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("58ae83f6-637c-4625-af41-3fb779505021")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T7_Invalid_Or_Missing_Basic_Data : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T7_Invalid_Or_Missing_Basic_Data:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T7_Invalid_Or_Missing_Basic_Data_PulseButton_In_SubS_P_SR("SubS_P_SR.T7_Invalid_Or_Missing_Basic_Data", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T8_Cd_Initialisation_Request1_PulseIndicator_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class InputPort_inp : Inherits OInputPort(Of EULYNX_Profile.Data_Types.PulsedIn)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T8_Cd_Initialisation_Request1)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator)
      MyBase.New(D, N)
      SetStudioId("887fed92-3713-471f-9e7e-e65ba88cdb2a")
      Dim O As Object
      ' inp:InputPort_inp
      O = New InputPort_inp("inp", Me, D)
      O.SetStudioId("eb37d12d-38fc-46cd-a465-0f0e5ba80fb5")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T8_Cd_Initialisation_Request1 : Inherits EULYNX_Profile.Controls.PulseIndicator.PulseIndicator : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T8_Cd_Initialisation_Request1:PulseIndicator"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T8_Cd_Initialisation_Request1_PulseIndicator_In_SubS_P_SR("SubS_P_SR.T8_Cd_Initialisation_Request1", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        inp = SimCore.GetInPorts("inp")
      End If
      Return SimCore
    End Function
    
    Public Sub OnAdvanceTo(ByVal Tm As Timespan) Handles SimCore.OnAdvanceTo
      Dim Dur As New SMSupport.Duration
      SMQueueStep(Tm, Dur)
    End Sub
    
    Public Sub OnSimulationStart() Handles SimCore.OnSimulationStart
      SMGInitialize()
    End Sub
    
    Public Sub OnSimulationEnd() Handles SimCore.OnSimulationEnd
      SMGTerminate()
    End Sub
    
  End Class
  Public Class T8_Data_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T8_Data)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T8_Data
      ' -- to SMI|T8_Data at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "T8_Data", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("4dc94e5d-01d2-41f7-95e6-4f02d3a77b27")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("46d8265e-88d5-4c87-acae-1a89c7b084ac")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T8_Data : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T8_Data:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T8_Data_PulseButton_In_SubS_P_SR("SubS_P_SR.T8_Data", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class T9_Transmission_Complete_PulseButton_In_SubS_P_SR : Inherits OSimDeviceCore
    Public Class OutputPort_outp : Inherits OOutputPort(Of EULYNX_Profile.Data_Types.PulsedOut)
      Public Sub New(ByVal N As String, ByVal Core As OSimDeviceCore, ByVal PortOwner As SubS_P_SRPackage.T9_Transmission_Complete)
          MyBase.New(N, Core, PortOwner)
        
      End Sub
      
    End Class
    Public Overrides Sub Bind(ByVal ErrList As OErrorList)
      Dim DestPart As OSimDeviceCore = Nothing
      UnBind()
      ' Port outp in invocation context T9_Transmission_Complete
      ' -- to SMI|T9_Transmission_Complete at SubS_P_SR.SMI
      For Each DestPart In GetSimMaster().GetAllSimCoreNamed("SubS_P_SR.SMI")
        Me.BindPort(DestPart, "outp", "T9_Transmission_Complete", ErrList)
      Next
      
    End Sub
    
    Public Sub New(ByVal N As String, ByVal D As EULYNX_Profile.Controls.PulseButton.PulseButton)
      MyBase.New(D, N)
      SetStudioId("73538b81-1e06-42a5-99a9-832ccc9759f2")
      Dim O As Object
      ' outp:OutputPort_outp
      O = New OutputPort_outp("outp", Me, D)
      O.SetStudioId("6322e3fb-3ef6-4b23-b5c9-2e60c0fc2d0e")
      
    End Sub
    
  End Class
  <System.ComponentModel.ToolboxItem(True)> _
  Public Class T9_Transmission_Complete : Inherits EULYNX_Profile.Controls.PulseButton.PulseButton : Implements OISimDevice 
    Protected Shadows WithEvents SimCore As OSimDeviceCore
    Private _SySimTooltip As String = "T9_Transmission_Complete:PulseButton"
    <System.ComponentModel.Category("SySim"), System.ComponentModel.Description("Control Tooltip")> _
    Public Property SySimTooltip() As String
      Get
        Return _SySimTooltip
      End Get
      Set(ByVal Value As String)
        _SySimTooltip = Value
      End Set
    End Property
    Private LastScanTime As Timespan
    Public Overridable Function GetSimCore() As OSimDeviceCore Implements OISimDevice.GetSimCore
      If SimCore Is Nothing Then
        SimCore = New T9_Transmission_Complete_PulseButton_In_SubS_P_SR("SubS_P_SR.T9_Transmission_Complete", Me)
        Dim T As Type = Me.GetType()
        Dim BaseT As Type = T.BaseType
        While BaseT IsNot Nothing
          Dim Prop As Reflection.PropertyInfo = BaseT.GetProperty ("SimCore", Reflection.BindingFlags.NonPublic + Reflection.BindingFlags.Public + Reflection.BindingFlags.Instance + Reflection.BindingFlags.IgnoreCase)
          If Prop IsNot Nothing Then
            Prop.SetValue(Me, SimCore, Nothing)
          End If
          BaseT = BaseT.BaseType
        End While
        outp = SimCore.GetOutPorts("outp")
      End If
      Return SimCore
    End Function
    
  End Class
  Public Class SubS_P_SRSimMaster : Inherits OSimMaster
    Private F_SCI_PAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "F_SCI_P", 1, 1)
    Private F_SCI_P As Logical_Components.F_SCI_P_SR
    Private T12_Data_Installation_SuccessfullyAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T12_Data_Installation_Successfully", 1, 1)
    Private T12_Data_Installation_Successfully As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T6_Data_Up_To_DateAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T6_Data_Up_To_Date", 1, 1)
    Private T6_Data_Up_To_Date As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T7_Data_Not_Up_To_DateAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T7_Data_Not_Up_To_Date", 1, 1)
    Private T7_Data_Not_Up_To_Date As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T8_DataAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T8_Data", 1, 1)
    Private T8_Data As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T9_Transmission_CompleteAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T9_Transmission_Complete", 1, 1)
    Private T9_Transmission_Complete As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T10_Data_ValidAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T10_Data_Valid", 1, 1)
    Private T10_Data_Valid As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T11_Data_InvalidAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T11_Data_Invalid", 1, 1)
    Private T11_Data_Invalid As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private D1_Con_t_Ini_Def_DelayAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D1_Con_t_Ini_Def_Delay", 1, 1)
    Private D1_Con_t_Ini_Def_Delay As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox
    Private D2_Con_t_Ini_StepAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D2_Con_t_Ini_Step", 1, 1)
    Private D2_Con_t_Ini_Step As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox
    Private D3_Con_t_Ini_MaxAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D3_Con_t_Ini_Max", 1, 1)
    Private D3_Con_t_Ini_Max As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox
    Private D4_Con_tmax_Response_MDMAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D4_Con_tmax_Response_MDM", 1, 1)
    Private D4_Con_tmax_Response_MDM As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox
    Private T1_Power_On_DetectedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T1_Power_On_Detected", 1, 1)
    Private T1_Power_On_Detected As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T2_Power_Off_DetectedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T2_Power_Off_Detected", 1, 1)
    Private T2_Power_Off_Detected As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T3_ResetAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T3_Reset", 1, 1)
    Private T3_Reset As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T4_BootedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T4_Booted", 1, 1)
    Private T4_Booted As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private D20_Con_MDM_UsedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D20_Con_MDM_Used", 1, 1)
    Private D20_Con_MDM_Used As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private T7_Invalid_Or_Missing_Basic_DataAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T7_Invalid_Or_Missing_Basic_Data", 1, 1)
    Private T7_Invalid_Or_Missing_Basic_Data As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T1_Move_PointAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T1_Move_Point", 1, 1)
    Private T1_Move_Point As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private DT1_Move_Point_TargetAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "DT1_Move_Point_Target", 1, 1)
    Private DT1_Move_Point_Target As EULYNX_Profile.Controls.InputComboBox.InputComboBox
    Private DT2_Point_PositionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "DT2_Point_Position", 1, 1)
    Private DT2_Point_Position As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private T5_SCP_ConnectionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T5_SCP_Connection", 1, 1)
    Private T5_SCP_Connection As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private DT13_ResultAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "DT13_Result", 1, 1)
    Private DT13_Result As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private DT13_Checksum_dataAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "DT13_Checksum_data", 1, 1)
    Private DT13_Checksum_data As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private T19_Validate_DataAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T19_Validate_Data", 1, 1)
    Private T19_Validate_Data As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T20_Ready_For_Update_Of_DataAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T20_Ready_For_Update_Of_Data", 1, 1)
    Private T20_Ready_For_Update_Of_Data As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T2_Msg_Point_PositionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T2_Msg_Point_Position", 1, 1)
    Private T2_Msg_Point_Position As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T13_Msg_PDI_Version_CheckAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T13_Msg_PDI_Version_Check", 1, 1)
    Private T13_Msg_PDI_Version_Check As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T14_Msg_Start_InitialisationAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T14_Msg_Start_Initialisation", 1, 1)
    Private T14_Msg_Start_Initialisation As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T15_Msg_Initialisation_CompletedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T15_Msg_Initialisation_Completed", 1, 1)
    Private T15_Msg_Initialisation_Completed As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private D3_Con_PDI_VersionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D3_Con_PDI_Version", 1, 1)
    Private D3_Con_PDI_Version As EULYNX_Profile.Controls.InputTextBox.InputTextBox
    Private D4_Checksum_DataAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D4_Checksum_Data", 1, 1)
    Private D4_Checksum_Data As EULYNX_Profile.Controls.InputTextBox.InputTextBox
    Private D51_F_EST_EfeS_Gen_SR_stateAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D51_F_EST_EfeS_Gen_SR_state", 1, 1)
    Private D51_F_EST_EfeS_Gen_SR_state As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private D10_Move_LeftAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D10_Move_Left", 1, 1)
    Private D10_Move_Left As EULYNX_Profile.Controls.BoolIndicator.BoolIndicator
    Private D11_Move_RightAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D11_Move_Right", 1, 1)
    Private D11_Move_Right As EULYNX_Profile.Controls.BoolIndicator.BoolIndicator
    Private D4_Con_tmax_Point_OperationAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D4_Con_tmax_Point_Operation", 1, 1)
    Private D4_Con_tmax_Point_Operation As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox
    Private T3_Msg_TimeoutAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T3_Msg_Timeout", 1, 1)
    Private T3_Msg_Timeout As EULYNX_Profile.Controls.PulsedPortStatusBox.PulsedPortStatusBox
    Private D50_PDI_Connection_State_SAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D50_PDI_Connection_State_S", 1, 1)
    Private D50_PDI_Connection_State_S As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private D5_Drive_StateAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D5_Drive_State", 1, 1)
    Private D5_Drive_State As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private T4_Information_No_End_PositionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T4_Information_No_End_Position", 1, 1)
    Private T4_Information_No_End_Position As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private DT20_PositionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "DT20_Position", 1, 1)
    Private DT20_Position As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private D6_Detection_StateAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D6_Detection_State", 1, 1)
    Private D6_Detection_State As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private D30_Con_007000Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D30_Con_007000", 1, 1)
    Private D30_Con_007000 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D32_Con_007600Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D32_Con_007600", 1, 1)
    Private D32_Con_007600 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D33_Con_007900Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D33_Con_007900", 1, 1)
    Private D33_Con_007900 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D34_Con_008000Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D34_Con_008000", 1, 1)
    Private D34_Con_008000 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D35_Con_008200Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D35_Con_008200", 1, 1)
    Private D35_Con_008200 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D36_Con_008300Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D36_Con_008300", 1, 1)
    Private D36_Con_008300 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D37_Con_008400Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D37_Con_008400", 1, 1)
    Private D37_Con_008400 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D31_Con_007400Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D31_Con_007400", 1, 1)
    Private D31_Con_007400 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D38_Con_008500Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D38_Con_008500", 1, 1)
    Private D38_Con_008500 As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private P3Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "P3", 1, 1)
    Private P3 As Logical_Components.F_P3_SR
    Private T6_Information_Trailed_PointAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T6_Information_Trailed_Point", 1, 1)
    Private T6_Information_Trailed_Point As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T7_Information_Out_Of_SequenceAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T7_Information_Out_Of_Sequence", 1, 1)
    Private T7_Information_Out_Of_Sequence As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T12_Disconnect_SCPAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T12_Disconnect_SCP", 1, 1)
    Private T12_Disconnect_SCP As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T20_Protocol_ErrorAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T20_Protocol_Error", 1, 1)
    Private T20_Protocol_Error As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T22_Content_Telegram_ErrorAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T22_Content_Telegram_Error", 1, 1)
    Private T22_Content_Telegram_Error As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T21_Formal_Telegram_ErrorAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T21_Formal_Telegram_Error", 1, 1)
    Private T21_Formal_Telegram_Error As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T23_SIL_Not_FulfilledAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T23_SIL_Not_Fulfilled", 1, 1)
    Private T23_SIL_Not_Fulfilled As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private PM1_PositionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "PM1_Position", 1, 1)
    Private PM1_Position As EULYNX_Profile.Controls.InputComboBox.InputComboBox
    Private PM2_PositionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "PM2_Position", 1, 1)
    Private PM2_Position As EULYNX_Profile.Controls.InputComboBox.InputComboBox
    Private SCI_SecAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "SCI_Sec", 1, 1)
    Private SCI_Sec As Logical_Components.F_SCI_EfeS_Sec_SR
    Private SCI_PrimAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "SCI_Prim", 1, 1)
    Private SCI_Prim As Logical_Components.S_SCI_EfeS_Prim_SR
    Private SMIAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "SMI", 1, 1)
    Private SMI As Logical_Components.F_SMI_EfeS_SR
    Private ESTAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "EST", 1, 1)
    Private EST As Logical_Components.F_EST_EfeS_SR
    Private D5_Con_tmax_DataTransmissionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D5_Con_tmax_DataTransmission", 1, 1)
    Private D5_Con_tmax_DataTransmission As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox
    Private T10_SCP_Connection_TerminatedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T10_SCP_Connection_Terminated", 1, 1)
    Private T10_SCP_Connection_Terminated As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private D23_Con_Checksum_Data_UsedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D23_Con_Checksum_Data_Used", 1, 1)
    Private D23_Con_Checksum_Data_Used As EULYNX_Profile.Controls.BoolSlider.BoolSlider
    Private D2_Con_tmax_PDI_Connection_IAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D2_Con_tmax_PDI_Connection_I", 1, 1)
    Private D2_Con_tmax_PDI_Connection_I As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox
    Private D3_Con_PDI_Version_IAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D3_Con_PDI_Version_I", 1, 1)
    Private D3_Con_PDI_Version_I As EULYNX_Profile.Controls.InputTextBox.InputTextBox
    Private D4_Con_Checksum_Data_IAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D4_Con_Checksum_Data_I", 1, 1)
    Private D4_Con_Checksum_Data_I As EULYNX_Profile.Controls.InputTextBox.InputTextBox
    Private T12_Terminate_SCP_Connection_IAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T12_Terminate_SCP_Connection_I", 1, 1)
    Private T12_Terminate_SCP_Connection_I As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T6_Establish_SCP_Connection_IAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T6_Establish_SCP_Connection_I", 1, 1)
    Private T6_Establish_SCP_Connection_I As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T20_Protocol_Error_IAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T20_Protocol_Error_I", 1, 1)
    Private T20_Protocol_Error_I As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T21_Formal_Telegram_Error_IAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T21_Formal_Telegram_Error_I", 1, 1)
    Private T21_Formal_Telegram_Error_I As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T22_Content_Telegram_Error_IAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T22_Content_Telegram_Error_I", 1, 1)
    Private T22_Content_Telegram_Error_I As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private T18_Start_Status_ReportAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T18_Start_Status_Report", 1, 1)
    Private T18_Start_Status_Report As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T7_Cd_PDI_Version_Check1Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T7_Cd_PDI_Version_Check1", 1, 1)
    Private T7_Cd_PDI_Version_Check1 As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T8_Cd_Initialisation_Request1Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T8_Cd_Initialisation_Request1", 1, 1)
    Private T8_Cd_Initialisation_Request1 As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private DT7_PDI_Version1Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "DT7_PDI_Version1", 1, 1)
    Private DT7_PDI_Version1 As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private D50_PDI_Connection_StateAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D50_PDI_Connection_State", 1, 1)
    Private D50_PDI_Connection_State As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private D44_Con_tmax_BootingAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D44_Con_tmax_Booting", 1, 1)
    Private D44_Con_tmax_Booting As EULYNX_Profile.Controls.InputIntegerBox.InputIntegerBox
    Private D25_RedriveAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D25_Redrive", 1, 1)
    Private D25_Redrive As EULYNX_Profile.Controls.BoolIndicator.BoolIndicator
    Private T5_Info_End_Position_ArrivedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T5_Info_End_Position_Arrived", 1, 1)
    Private T5_Info_End_Position_Arrived As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T23_Sending_Status_Report_CompletedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T23_Sending_Status_Report_Completed", 1, 1)
    Private T23_Sending_Status_Report_Completed As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T21_Data_Update_FinishedAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T21_Data_Update_Finished", 1, 1)
    Private T21_Data_Update_Finished As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T5_SIL_Not_FulfilledAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T5_SIL_Not_Fulfilled", 1, 1)
    Private T5_SIL_Not_Fulfilled As EULYNX_Profile.Controls.PulseButton.PulseButton
    Private S_SCI_PAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "S_SCI_P", 1, 1)
    Private S_SCI_P As Logical_Components.S_SCI_P_SR
    Private T2_OUT_Point_PositionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T2_OUT_Point_Position", 1, 1)
    Private T2_OUT_Point_Position As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private T1_OUT_Move_PointAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "T1_OUT_Move_Point", 1, 1)
    Private T1_OUT_Move_Point As EULYNX_Profile.Controls.PulseIndicator.PulseIndicator
    Private DT2_OUT_Point_PositionAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "DT2_OUT_Point_Position", 1, 1)
    Private DT2_OUT_Point_Position As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private DT1_OUT_Move_Point_TargetAccessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "DT1_OUT_Move_Point_Target", 1, 1)
    Private DT1_OUT_Move_Point_Target As EULYNX_Profile.Controls.OutputTextBox.OutputTextBox
    Private D13_Activation_PM2Accessor As TSimRoleAccessorOne = New TSimRoleAccessorOne(Me, "D13_Activation_PM2", 1, 1)
    Private D13_Activation_PM2 As EULYNX_Profile.Controls.InputComboBox.InputComboBox
    Private ActualForm As SubS_P_SRForm
    Private ClassInstanceList As New SortedList(Of String, Type)
    Public Sub New(ByVal F As System.Windows.Forms.Form)
      MyBase.New(F)
      ActualForm = F
      SetName("SubS_P_SR")
      GetFactory().SetMaster(Me)
      Dim OwningClass As Type, CandidateClass As Type
      ' Build the factory descriptor structure
      ' Parent invocation: []
      ' Role:              [D10_Move_Left]
      ' FWK Full Name:     [D10_Move_Left]
      OwningClass = Nothing
      CandidateClass = GetType(D10_Move_Left)
      GetFactory().AddDescriptors(OwningClass, "D10_Move_Left", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D11_Move_Right]
      ' FWK Full Name:     [D11_Move_Right]
      OwningClass = Nothing
      CandidateClass = GetType(D11_Move_Right)
      GetFactory().AddDescriptors(OwningClass, "D11_Move_Right", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D13_Activation_PM2]
      ' FWK Full Name:     [D13_Activation_PM2]
      OwningClass = Nothing
      CandidateClass = GetType(D13_Activation_PM2)
      GetFactory().AddDescriptors(OwningClass, "D13_Activation_PM2", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D1_Con_t_Ini_Def_Delay]
      ' FWK Full Name:     [D1_Con_t_Ini_Def_Delay]
      OwningClass = Nothing
      CandidateClass = GetType(D1_Con_t_Ini_Def_Delay)
      GetFactory().AddDescriptors(OwningClass, "D1_Con_t_Ini_Def_Delay", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D20_Con_MDM_Used]
      ' FWK Full Name:     [D20_Con_MDM_Used]
      OwningClass = Nothing
      CandidateClass = GetType(D20_Con_MDM_Used)
      GetFactory().AddDescriptors(OwningClass, "D20_Con_MDM_Used", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D23_Con_Checksum_Data_Used]
      ' FWK Full Name:     [D23_Con_Checksum_Data_Used]
      OwningClass = Nothing
      CandidateClass = GetType(D23_Con_Checksum_Data_Used)
      GetFactory().AddDescriptors(OwningClass, "D23_Con_Checksum_Data_Used", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D25_Redrive]
      ' FWK Full Name:     [D25_Redrive]
      OwningClass = Nothing
      CandidateClass = GetType(D25_Redrive)
      GetFactory().AddDescriptors(OwningClass, "D25_Redrive", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D2_Con_t_Ini_Step]
      ' FWK Full Name:     [D2_Con_t_Ini_Step]
      OwningClass = Nothing
      CandidateClass = GetType(D2_Con_t_Ini_Step)
      GetFactory().AddDescriptors(OwningClass, "D2_Con_t_Ini_Step", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D2_Con_tmax_PDI_Connection_I]
      ' FWK Full Name:     [D2_Con_tmax_PDI_Connection_I]
      OwningClass = Nothing
      CandidateClass = GetType(D2_Con_tmax_PDI_Connection_I)
      GetFactory().AddDescriptors(OwningClass, "D2_Con_tmax_PDI_Connection_I", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D30_Con_007000]
      ' FWK Full Name:     [D30_Con_007000]
      OwningClass = Nothing
      CandidateClass = GetType(D30_Con_007000)
      GetFactory().AddDescriptors(OwningClass, "D30_Con_007000", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D31_Con_007400]
      ' FWK Full Name:     [D31_Con_007400]
      OwningClass = Nothing
      CandidateClass = GetType(D31_Con_007400)
      GetFactory().AddDescriptors(OwningClass, "D31_Con_007400", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D32_Con_007600]
      ' FWK Full Name:     [D32_Con_007600]
      OwningClass = Nothing
      CandidateClass = GetType(D32_Con_007600)
      GetFactory().AddDescriptors(OwningClass, "D32_Con_007600", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D33_Con_007900]
      ' FWK Full Name:     [D33_Con_007900]
      OwningClass = Nothing
      CandidateClass = GetType(D33_Con_007900)
      GetFactory().AddDescriptors(OwningClass, "D33_Con_007900", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D34_Con_008000]
      ' FWK Full Name:     [D34_Con_008000]
      OwningClass = Nothing
      CandidateClass = GetType(D34_Con_008000)
      GetFactory().AddDescriptors(OwningClass, "D34_Con_008000", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D35_Con_008200]
      ' FWK Full Name:     [D35_Con_008200]
      OwningClass = Nothing
      CandidateClass = GetType(D35_Con_008200)
      GetFactory().AddDescriptors(OwningClass, "D35_Con_008200", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D36_Con_008300]
      ' FWK Full Name:     [D36_Con_008300]
      OwningClass = Nothing
      CandidateClass = GetType(D36_Con_008300)
      GetFactory().AddDescriptors(OwningClass, "D36_Con_008300", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D37_Con_008400]
      ' FWK Full Name:     [D37_Con_008400]
      OwningClass = Nothing
      CandidateClass = GetType(D37_Con_008400)
      GetFactory().AddDescriptors(OwningClass, "D37_Con_008400", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D38_Con_008500]
      ' FWK Full Name:     [D38_Con_008500]
      OwningClass = Nothing
      CandidateClass = GetType(D38_Con_008500)
      GetFactory().AddDescriptors(OwningClass, "D38_Con_008500", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D3_Con_PDI_Version]
      ' FWK Full Name:     [D3_Con_PDI_Version]
      OwningClass = Nothing
      CandidateClass = GetType(D3_Con_PDI_Version)
      GetFactory().AddDescriptors(OwningClass, "D3_Con_PDI_Version", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D3_Con_PDI_Version_I]
      ' FWK Full Name:     [D3_Con_PDI_Version_I]
      OwningClass = Nothing
      CandidateClass = GetType(D3_Con_PDI_Version_I)
      GetFactory().AddDescriptors(OwningClass, "D3_Con_PDI_Version_I", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D3_Con_t_Ini_Max]
      ' FWK Full Name:     [D3_Con_t_Ini_Max]
      OwningClass = Nothing
      CandidateClass = GetType(D3_Con_t_Ini_Max)
      GetFactory().AddDescriptors(OwningClass, "D3_Con_t_Ini_Max", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D44_Con_tmax_Booting]
      ' FWK Full Name:     [D44_Con_tmax_Booting]
      OwningClass = Nothing
      CandidateClass = GetType(D44_Con_tmax_Booting)
      GetFactory().AddDescriptors(OwningClass, "D44_Con_tmax_Booting", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D4_Checksum_Data]
      ' FWK Full Name:     [D4_Checksum_Data]
      OwningClass = Nothing
      CandidateClass = GetType(D4_Checksum_Data)
      GetFactory().AddDescriptors(OwningClass, "D4_Checksum_Data", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D4_Con_Checksum_Data_I]
      ' FWK Full Name:     [D4_Con_Checksum_Data_I]
      OwningClass = Nothing
      CandidateClass = GetType(D4_Con_Checksum_Data_I)
      GetFactory().AddDescriptors(OwningClass, "D4_Con_Checksum_Data_I", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D4_Con_tmax_Point_Operation]
      ' FWK Full Name:     [D4_Con_tmax_Point_Operation]
      OwningClass = Nothing
      CandidateClass = GetType(D4_Con_tmax_Point_Operation)
      GetFactory().AddDescriptors(OwningClass, "D4_Con_tmax_Point_Operation", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D4_Con_tmax_Response_MDM]
      ' FWK Full Name:     [D4_Con_tmax_Response_MDM]
      OwningClass = Nothing
      CandidateClass = GetType(D4_Con_tmax_Response_MDM)
      GetFactory().AddDescriptors(OwningClass, "D4_Con_tmax_Response_MDM", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D50_PDI_Connection_State]
      ' FWK Full Name:     [D50_PDI_Connection_State]
      OwningClass = Nothing
      CandidateClass = GetType(D50_PDI_Connection_State)
      GetFactory().AddDescriptors(OwningClass, "D50_PDI_Connection_State", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D50_PDI_Connection_State_S]
      ' FWK Full Name:     [D50_PDI_Connection_State_S]
      OwningClass = Nothing
      CandidateClass = GetType(D50_PDI_Connection_State_S)
      GetFactory().AddDescriptors(OwningClass, "D50_PDI_Connection_State_S", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D51_F_EST_EfeS_Gen_SR_state]
      ' FWK Full Name:     [D51_F_EST_EfeS_Gen_SR_state]
      OwningClass = Nothing
      CandidateClass = GetType(D51_F_EST_EfeS_Gen_SR_state)
      GetFactory().AddDescriptors(OwningClass, "D51_F_EST_EfeS_Gen_SR_state", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D5_Con_tmax_DataTransmission]
      ' FWK Full Name:     [D5_Con_tmax_DataTransmission]
      OwningClass = Nothing
      CandidateClass = GetType(D5_Con_tmax_DataTransmission)
      GetFactory().AddDescriptors(OwningClass, "D5_Con_tmax_DataTransmission", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D5_Drive_State]
      ' FWK Full Name:     [D5_Drive_State]
      OwningClass = Nothing
      CandidateClass = GetType(D5_Drive_State)
      GetFactory().AddDescriptors(OwningClass, "D5_Drive_State", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [D6_Detection_State]
      ' FWK Full Name:     [D6_Detection_State]
      OwningClass = Nothing
      CandidateClass = GetType(D6_Detection_State)
      GetFactory().AddDescriptors(OwningClass, "D6_Detection_State", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [DT13_Checksum_data]
      ' FWK Full Name:     [DT13_Checksum_data]
      OwningClass = Nothing
      CandidateClass = GetType(DT13_Checksum_data)
      GetFactory().AddDescriptors(OwningClass, "DT13_Checksum_data", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [DT13_Result]
      ' FWK Full Name:     [DT13_Result]
      OwningClass = Nothing
      CandidateClass = GetType(DT13_Result)
      GetFactory().AddDescriptors(OwningClass, "DT13_Result", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [DT1_Move_Point_Target]
      ' FWK Full Name:     [DT1_Move_Point_Target]
      OwningClass = Nothing
      CandidateClass = GetType(DT1_Move_Point_Target)
      GetFactory().AddDescriptors(OwningClass, "DT1_Move_Point_Target", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [DT1_OUT_Move_Point_Target]
      ' FWK Full Name:     [DT1_OUT_Move_Point_Target]
      OwningClass = Nothing
      CandidateClass = GetType(DT1_OUT_Move_Point_Target)
      GetFactory().AddDescriptors(OwningClass, "DT1_OUT_Move_Point_Target", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [DT20_Position]
      ' FWK Full Name:     [DT20_Position]
      OwningClass = Nothing
      CandidateClass = GetType(DT20_Position)
      GetFactory().AddDescriptors(OwningClass, "DT20_Position", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [DT2_OUT_Point_Position]
      ' FWK Full Name:     [DT2_OUT_Point_Position]
      OwningClass = Nothing
      CandidateClass = GetType(DT2_OUT_Point_Position)
      GetFactory().AddDescriptors(OwningClass, "DT2_OUT_Point_Position", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [DT2_Point_Position]
      ' FWK Full Name:     [DT2_Point_Position]
      OwningClass = Nothing
      CandidateClass = GetType(DT2_Point_Position)
      GetFactory().AddDescriptors(OwningClass, "DT2_Point_Position", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [DT7_PDI_Version1]
      ' FWK Full Name:     [DT7_PDI_Version1]
      OwningClass = Nothing
      CandidateClass = GetType(DT7_PDI_Version1)
      GetFactory().AddDescriptors(OwningClass, "DT7_PDI_Version1", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [EST]
      ' FWK Full Name:     [EST]
      OwningClass = Nothing
      CandidateClass = GetType(EST)
      GetFactory().AddDescriptors(OwningClass, "EST", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [F_SCI_P]
      ' FWK Full Name:     [F_SCI_P]
      OwningClass = Nothing
      CandidateClass = GetType(F_SCI_P)
      GetFactory().AddDescriptors(OwningClass, "F_SCI_P", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [P3]
      ' FWK Full Name:     [P3]
      OwningClass = Nothing
      CandidateClass = GetType(P3)
      GetFactory().AddDescriptors(OwningClass, "P3", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [PM1_Position]
      ' FWK Full Name:     [PM1_Position]
      OwningClass = Nothing
      CandidateClass = GetType(PM1_Position)
      GetFactory().AddDescriptors(OwningClass, "PM1_Position", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [PM2_Position]
      ' FWK Full Name:     [PM2_Position]
      OwningClass = Nothing
      CandidateClass = GetType(PM2_Position)
      GetFactory().AddDescriptors(OwningClass, "PM2_Position", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [S_SCI_P]
      ' FWK Full Name:     [S_SCI_P]
      OwningClass = Nothing
      CandidateClass = GetType(S_SCI_P)
      GetFactory().AddDescriptors(OwningClass, "S_SCI_P", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [SCI_Prim]
      ' FWK Full Name:     [SCI_Prim]
      OwningClass = Nothing
      CandidateClass = GetType(SCI_Prim)
      GetFactory().AddDescriptors(OwningClass, "SCI_Prim", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [SCI_Sec]
      ' FWK Full Name:     [SCI_Sec]
      OwningClass = Nothing
      CandidateClass = GetType(SCI_Sec)
      GetFactory().AddDescriptors(OwningClass, "SCI_Sec", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [SMI]
      ' FWK Full Name:     [SMI]
      OwningClass = Nothing
      CandidateClass = GetType(SMI)
      GetFactory().AddDescriptors(OwningClass, "SMI", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T10_Data_Valid]
      ' FWK Full Name:     [T10_Data_Valid]
      OwningClass = Nothing
      CandidateClass = GetType(T10_Data_Valid)
      GetFactory().AddDescriptors(OwningClass, "T10_Data_Valid", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T10_SCP_Connection_Terminated]
      ' FWK Full Name:     [T10_SCP_Connection_Terminated]
      OwningClass = Nothing
      CandidateClass = GetType(T10_SCP_Connection_Terminated)
      GetFactory().AddDescriptors(OwningClass, "T10_SCP_Connection_Terminated", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T11_Data_Invalid]
      ' FWK Full Name:     [T11_Data_Invalid]
      OwningClass = Nothing
      CandidateClass = GetType(T11_Data_Invalid)
      GetFactory().AddDescriptors(OwningClass, "T11_Data_Invalid", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T12_Data_Installation_Successfully]
      ' FWK Full Name:     [T12_Data_Installation_Successfully]
      OwningClass = Nothing
      CandidateClass = GetType(T12_Data_Installation_Successfully)
      GetFactory().AddDescriptors(OwningClass, "T12_Data_Installation_Successfully", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T12_Disconnect_SCP]
      ' FWK Full Name:     [T12_Disconnect_SCP]
      OwningClass = Nothing
      CandidateClass = GetType(T12_Disconnect_SCP)
      GetFactory().AddDescriptors(OwningClass, "T12_Disconnect_SCP", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T12_Terminate_SCP_Connection_I]
      ' FWK Full Name:     [T12_Terminate_SCP_Connection_I]
      OwningClass = Nothing
      CandidateClass = GetType(T12_Terminate_SCP_Connection_I)
      GetFactory().AddDescriptors(OwningClass, "T12_Terminate_SCP_Connection_I", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T13_Msg_PDI_Version_Check]
      ' FWK Full Name:     [T13_Msg_PDI_Version_Check]
      OwningClass = Nothing
      CandidateClass = GetType(T13_Msg_PDI_Version_Check)
      GetFactory().AddDescriptors(OwningClass, "T13_Msg_PDI_Version_Check", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T14_Msg_Start_Initialisation]
      ' FWK Full Name:     [T14_Msg_Start_Initialisation]
      OwningClass = Nothing
      CandidateClass = GetType(T14_Msg_Start_Initialisation)
      GetFactory().AddDescriptors(OwningClass, "T14_Msg_Start_Initialisation", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T15_Msg_Initialisation_Completed]
      ' FWK Full Name:     [T15_Msg_Initialisation_Completed]
      OwningClass = Nothing
      CandidateClass = GetType(T15_Msg_Initialisation_Completed)
      GetFactory().AddDescriptors(OwningClass, "T15_Msg_Initialisation_Completed", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T18_Start_Status_Report]
      ' FWK Full Name:     [T18_Start_Status_Report]
      OwningClass = Nothing
      CandidateClass = GetType(T18_Start_Status_Report)
      GetFactory().AddDescriptors(OwningClass, "T18_Start_Status_Report", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T19_Validate_Data]
      ' FWK Full Name:     [T19_Validate_Data]
      OwningClass = Nothing
      CandidateClass = GetType(T19_Validate_Data)
      GetFactory().AddDescriptors(OwningClass, "T19_Validate_Data", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T1_Move_Point]
      ' FWK Full Name:     [T1_Move_Point]
      OwningClass = Nothing
      CandidateClass = GetType(T1_Move_Point)
      GetFactory().AddDescriptors(OwningClass, "T1_Move_Point", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T1_OUT_Move_Point]
      ' FWK Full Name:     [T1_OUT_Move_Point]
      OwningClass = Nothing
      CandidateClass = GetType(T1_OUT_Move_Point)
      GetFactory().AddDescriptors(OwningClass, "T1_OUT_Move_Point", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T1_Power_On_Detected]
      ' FWK Full Name:     [T1_Power_On_Detected]
      OwningClass = Nothing
      CandidateClass = GetType(T1_Power_On_Detected)
      GetFactory().AddDescriptors(OwningClass, "T1_Power_On_Detected", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T20_Protocol_Error]
      ' FWK Full Name:     [T20_Protocol_Error]
      OwningClass = Nothing
      CandidateClass = GetType(T20_Protocol_Error)
      GetFactory().AddDescriptors(OwningClass, "T20_Protocol_Error", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T20_Protocol_Error_I]
      ' FWK Full Name:     [T20_Protocol_Error_I]
      OwningClass = Nothing
      CandidateClass = GetType(T20_Protocol_Error_I)
      GetFactory().AddDescriptors(OwningClass, "T20_Protocol_Error_I", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T20_Ready_For_Update_Of_Data]
      ' FWK Full Name:     [T20_Ready_For_Update_Of_Data]
      OwningClass = Nothing
      CandidateClass = GetType(T20_Ready_For_Update_Of_Data)
      GetFactory().AddDescriptors(OwningClass, "T20_Ready_For_Update_Of_Data", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T21_Data_Update_Finished]
      ' FWK Full Name:     [T21_Data_Update_Finished]
      OwningClass = Nothing
      CandidateClass = GetType(T21_Data_Update_Finished)
      GetFactory().AddDescriptors(OwningClass, "T21_Data_Update_Finished", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T21_Formal_Telegram_Error]
      ' FWK Full Name:     [T21_Formal_Telegram_Error]
      OwningClass = Nothing
      CandidateClass = GetType(T21_Formal_Telegram_Error)
      GetFactory().AddDescriptors(OwningClass, "T21_Formal_Telegram_Error", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T21_Formal_Telegram_Error_I]
      ' FWK Full Name:     [T21_Formal_Telegram_Error_I]
      OwningClass = Nothing
      CandidateClass = GetType(T21_Formal_Telegram_Error_I)
      GetFactory().AddDescriptors(OwningClass, "T21_Formal_Telegram_Error_I", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T22_Content_Telegram_Error]
      ' FWK Full Name:     [T22_Content_Telegram_Error]
      OwningClass = Nothing
      CandidateClass = GetType(T22_Content_Telegram_Error)
      GetFactory().AddDescriptors(OwningClass, "T22_Content_Telegram_Error", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T22_Content_Telegram_Error_I]
      ' FWK Full Name:     [T22_Content_Telegram_Error_I]
      OwningClass = Nothing
      CandidateClass = GetType(T22_Content_Telegram_Error_I)
      GetFactory().AddDescriptors(OwningClass, "T22_Content_Telegram_Error_I", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T23_Sending_Status_Report_Completed]
      ' FWK Full Name:     [T23_Sending_Status_Report_Completed]
      OwningClass = Nothing
      CandidateClass = GetType(T23_Sending_Status_Report_Completed)
      GetFactory().AddDescriptors(OwningClass, "T23_Sending_Status_Report_Completed", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T23_SIL_Not_Fulfilled]
      ' FWK Full Name:     [T23_SIL_Not_Fulfilled]
      OwningClass = Nothing
      CandidateClass = GetType(T23_SIL_Not_Fulfilled)
      GetFactory().AddDescriptors(OwningClass, "T23_SIL_Not_Fulfilled", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T2_Msg_Point_Position]
      ' FWK Full Name:     [T2_Msg_Point_Position]
      OwningClass = Nothing
      CandidateClass = GetType(T2_Msg_Point_Position)
      GetFactory().AddDescriptors(OwningClass, "T2_Msg_Point_Position", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T2_OUT_Point_Position]
      ' FWK Full Name:     [T2_OUT_Point_Position]
      OwningClass = Nothing
      CandidateClass = GetType(T2_OUT_Point_Position)
      GetFactory().AddDescriptors(OwningClass, "T2_OUT_Point_Position", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T2_Power_Off_Detected]
      ' FWK Full Name:     [T2_Power_Off_Detected]
      OwningClass = Nothing
      CandidateClass = GetType(T2_Power_Off_Detected)
      GetFactory().AddDescriptors(OwningClass, "T2_Power_Off_Detected", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T3_Msg_Timeout]
      ' FWK Full Name:     [T3_Msg_Timeout]
      OwningClass = Nothing
      CandidateClass = GetType(T3_Msg_Timeout)
      GetFactory().AddDescriptors(OwningClass, "T3_Msg_Timeout", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T3_Reset]
      ' FWK Full Name:     [T3_Reset]
      OwningClass = Nothing
      CandidateClass = GetType(T3_Reset)
      GetFactory().AddDescriptors(OwningClass, "T3_Reset", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T4_Booted]
      ' FWK Full Name:     [T4_Booted]
      OwningClass = Nothing
      CandidateClass = GetType(T4_Booted)
      GetFactory().AddDescriptors(OwningClass, "T4_Booted", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T4_Information_No_End_Position]
      ' FWK Full Name:     [T4_Information_No_End_Position]
      OwningClass = Nothing
      CandidateClass = GetType(T4_Information_No_End_Position)
      GetFactory().AddDescriptors(OwningClass, "T4_Information_No_End_Position", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T5_Info_End_Position_Arrived]
      ' FWK Full Name:     [T5_Info_End_Position_Arrived]
      OwningClass = Nothing
      CandidateClass = GetType(T5_Info_End_Position_Arrived)
      GetFactory().AddDescriptors(OwningClass, "T5_Info_End_Position_Arrived", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T5_SCP_Connection]
      ' FWK Full Name:     [T5_SCP_Connection]
      OwningClass = Nothing
      CandidateClass = GetType(T5_SCP_Connection)
      GetFactory().AddDescriptors(OwningClass, "T5_SCP_Connection", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T5_SIL_Not_Fulfilled]
      ' FWK Full Name:     [T5_SIL_Not_Fulfilled]
      OwningClass = Nothing
      CandidateClass = GetType(T5_SIL_Not_Fulfilled)
      GetFactory().AddDescriptors(OwningClass, "T5_SIL_Not_Fulfilled", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T6_Data_Up_To_Date]
      ' FWK Full Name:     [T6_Data_Up_To_Date]
      OwningClass = Nothing
      CandidateClass = GetType(T6_Data_Up_To_Date)
      GetFactory().AddDescriptors(OwningClass, "T6_Data_Up_To_Date", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T6_Establish_SCP_Connection_I]
      ' FWK Full Name:     [T6_Establish_SCP_Connection_I]
      OwningClass = Nothing
      CandidateClass = GetType(T6_Establish_SCP_Connection_I)
      GetFactory().AddDescriptors(OwningClass, "T6_Establish_SCP_Connection_I", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T6_Information_Trailed_Point]
      ' FWK Full Name:     [T6_Information_Trailed_Point]
      OwningClass = Nothing
      CandidateClass = GetType(T6_Information_Trailed_Point)
      GetFactory().AddDescriptors(OwningClass, "T6_Information_Trailed_Point", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T7_Cd_PDI_Version_Check1]
      ' FWK Full Name:     [T7_Cd_PDI_Version_Check1]
      OwningClass = Nothing
      CandidateClass = GetType(T7_Cd_PDI_Version_Check1)
      GetFactory().AddDescriptors(OwningClass, "T7_Cd_PDI_Version_Check1", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T7_Data_Not_Up_To_Date]
      ' FWK Full Name:     [T7_Data_Not_Up_To_Date]
      OwningClass = Nothing
      CandidateClass = GetType(T7_Data_Not_Up_To_Date)
      GetFactory().AddDescriptors(OwningClass, "T7_Data_Not_Up_To_Date", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T7_Information_Out_Of_Sequence]
      ' FWK Full Name:     [T7_Information_Out_Of_Sequence]
      OwningClass = Nothing
      CandidateClass = GetType(T7_Information_Out_Of_Sequence)
      GetFactory().AddDescriptors(OwningClass, "T7_Information_Out_Of_Sequence", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T7_Invalid_Or_Missing_Basic_Data]
      ' FWK Full Name:     [T7_Invalid_Or_Missing_Basic_Data]
      OwningClass = Nothing
      CandidateClass = GetType(T7_Invalid_Or_Missing_Basic_Data)
      GetFactory().AddDescriptors(OwningClass, "T7_Invalid_Or_Missing_Basic_Data", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T8_Cd_Initialisation_Request1]
      ' FWK Full Name:     [T8_Cd_Initialisation_Request1]
      OwningClass = Nothing
      CandidateClass = GetType(T8_Cd_Initialisation_Request1)
      GetFactory().AddDescriptors(OwningClass, "T8_Cd_Initialisation_Request1", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T8_Data]
      ' FWK Full Name:     [T8_Data]
      OwningClass = Nothing
      CandidateClass = GetType(T8_Data)
      GetFactory().AddDescriptors(OwningClass, "T8_Data", CandidateClass, True, ErrorList)
      ' Parent invocation: []
      ' Role:              [T9_Transmission_Complete]
      ' FWK Full Name:     [T9_Transmission_Complete]
      OwningClass = Nothing
      CandidateClass = GetType(T9_Transmission_Complete)
      GetFactory().AddDescriptors(OwningClass, "T9_Transmission_Complete", CandidateClass, True, ErrorList)
      
    End Sub

    Public Overrides Sub Build()
      Dim CtrlLst As New List(Of Control)
      GetControlsOf(TheForm, CtrlLst)
      For Each Ctrl As Control In CtrlLst
        Dim DeviceItf As OISimDevice = Nothing
        Try
          DeviceItf = Ctrl
        Catch
        End Try
        If DeviceItf IsNot Nothing Then
          AddSimCores(DeviceItf)
        End If
      Next

    End Sub
    Public Function GetControlBar() As SySimControlBar_SubS_P_SR
      Return TheControlBar
    End Function

    Public Sub CompleteBuild()
      ' Check/take ctrl bar
      Try
        TheControlBar = GetOneSimCoreNamed(SySimControlBar.CtrlName).GetSimDev()
      Catch
      End Try
      If TheControlBar IsNot Nothing Then
        ' Bind events
        AddHandler TheControlBar.OCRun.Click, AddressOf Me.DoRun
        AddHandler TheControlBar.OCExit.Click, AddressOf Me.DoHalt
        AddHandler TheControlBar.OCPause.Click, AddressOf Me.DoSuspend
        AddHandler TheControlBar.OCStep.Click, AddressOf Me.DoStep
        AddHandler TheControlBar.OCLog.Click, AddressOf Me.DoLog
        AddHandler TheControlBar.OCErrors.Click, AddressOf Me.DoShowErrors
      Else
        MsgBox("Cannot run a simulation without a SySim Control Bar control", MsgBoxStyle.OkOnly, "PTC Integrity Modeler SySim") ' Complain if missing control bar
        End
      End If
      ' CTor might have discovered errors (missing constructors in classes) so don't try creating if any and repot those
      If Not ErrorList.HasErrors() Then
        ' Create instances as per minimum role multiplicity
        GetFactory().CreateInitialInstances(ErrorList)
      
        ' Tooltip
        Dim CtrlLst As New List(Of Control)
        GetControlsOf(TheForm, CtrlLst)
        For Each Ctrl As Control In CtrlLst
          Dim DeviceItf As OISimDevice = Nothing
          Try
            Dim O As Object = Ctrl
            Dim TT As String = O.SySimTooltip
            ActualForm.GetTheToolTip().SetToolTip(Ctrl, TT)
            For Each SubC As Control In Ctrl.Controls
              ActualForm.GetTheToolTip().SetToolTip(SubC, TT)
            Next
          Catch
          End Try
        Next
      End If
      
    End Sub
    
    Public Function InstanceFactory(ByVal TypeToInstantiate As String, ByVal InstanceToContain As Object, ByVal RoleToInsertInto As String) As Object
      Dim Ret As Object = Nothing
      If InstanceToContain Is Nothing Then InstanceToContain = Me
      Dim FullInstanceName = ""
      If InstanceToContain IsNot Me Then
        FullInstanceName = InstanceToContain.FullName()
      End If
      If FullInstanceName <> "" Then FullInstanceName += "_"
      FullInstanceName += RoleToInsertInto
      Dim SearchKey As String = TypeToInstantiate + "$" + FullInstanceName
      If ClassInstanceList.ContainsKey(SearchKey) Then
        Dim TypeToCreate As Type = ClassInstanceList(SearchKey)
      End If
      Return Ret
    End Function
    
    Public Overrides Sub Check()
      MyBase.Check()
    End Sub
    
  End Class
  Public Class SySimControlBar_SubS_P_SR : Inherits SySimControlBar
  End Class
End Namespace
