Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.InputComboBox
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class InputComboBox : Inherits ComboBox
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Protected outp As OOutputPort(Of String)
    Public Sub send(ByVal Ph As OPhase) Handles SimCore.OnWriteOutputs
      ' ## VBOperationBody [00b0086e-4692-422c-8441-5bfb0a977f32] 
      outp.SetValue(Me.Text)
      'Console.WriteLine(Me.Name + "::" + Me.GetType().Name + " sends " + Me.Text)
      ' ## VBOperationBody End 
    End Sub
    
  End Class
End Namespace
