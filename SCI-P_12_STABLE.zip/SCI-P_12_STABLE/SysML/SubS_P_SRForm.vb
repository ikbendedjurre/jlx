Option Explicit On
Imports System.Reflection
Imports SIMULATOR.SubS_P_SRPackage
Imports PredefinedControls
Namespace SIMULATOR
	Partial Public Class SubS_P_SRForm : Inherits PredefinedControls.OFormBase
		Private TheToolTip As ToolTip
		Private SimMaster As SIMULATOR.SubS_P_SRPackage.SubS_P_SRSimMaster
		Public Sub New()
			InitializeComponent()
			TheToolTip = New ToolTip()
			SimMaster = New SubS_P_SRSimMaster(Me)
			SimMaster.Build()
			SimMaster.CompleteBuild()
			SimMaster.Bind()
			SimMaster.Check()
			ApplyStyles("SubS_P_SR")

			Adapter.LocalizeGUIElems(Me, SimMaster)

			'When compiling as a form, this automatically starts+pauses the simulation at 0s:
			'SimMaster.DoRun()
			'SimMaster.DoSuspend()
		End Sub
		Public Function GetMaster() As SySimFWK.OSimMaster
			Return SimMaster
		End Function
		Public Sub Reset()
			SimMaster.DoHalt()

			'Simulator configuration (this possibly resets after HALT):
			D44_Con_tmax_Booting1.Text = "999999999" 'We want to disable this timeout entirely (to disable a known fault)
			'Also, it is not associated with a port from the specification, so automated testing does not set it to INF!!

			'Automated testing now sets the Infrastructure Manager, so we can comment this out:
			'D37_0084001.Value = 1 'Configure as ProRail system
			'D34_0080001.Value = 1 'Configure as DB system

			'Start the simulator, then pause it immediately:
			SimMaster.DoRun()
			SimMaster.DoSuspend()
			''Do a step so that all values are initialized:
			'Adapter.Disable()
			''Only now will the adapter start noticing changes in the model:
			'Adapter.Enable()
		End Sub
		Public Sub DoSimStep()
			SimMaster.DoStep()
		End Sub
		Public Function TryObserveOutput(ByRef Output As String) As Boolean
			For i As Integer = 1 To 330 '<-- This must be at least 30000ms (the longest timeout, except D44) = 30s = 300 steps; we add 10%
				If Adapter.DequeueOutput(Output) Then
					Return True
				End If
				SimMaster.DoStep()
			Next
			Return Adapter.DequeueOutput(Output)
		End Function
		Public Function GetTheToolTip() As ToolTip
			Return TheToolTip
		End Function
		Public Function GetTimeStr() As String
			Dim ts As TimeSpan = SimMaster.GetSimTime()
			Return String.Format("{0:00}:{1:00}:{2:00}.{3:0}", Int(ts.TotalHours), ts.Minutes, ts.Seconds, ts.Milliseconds / 100)
		End Function
	End Class
End Namespace
