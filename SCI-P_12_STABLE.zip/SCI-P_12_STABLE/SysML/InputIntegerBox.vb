Option Explicit On
Imports SySimFWK, PredefinedControls

Namespace EULYNX_Profile.Controls.InputIntegerBox
  <System.ComponentModel.ToolboxItem(False)> _
  Public Class InputIntegerBox : Inherits TextBox
    Protected outp As OOutputPort(Of Integer)
    Private Shadows WithEvents SimCore As OSimDeviceCore
    Public Sub send(ByVal Ph As OPhase) Handles SimCore.OnWriteOutputs
      ' ## VBOperationBody [16d126e5-b91e-446f-8da6-d26a3f74b290]
      Try
        outp.SetValue(Integer.Parse(Me.Text))
      Catch e As System.FormatException
        Console.WriteLine("Input port is sending non-integer " + Me.Text + "!")
        Throw e
      End Try
      ' ## VBOperationBody End 
    End Sub

  End Class
End Namespace
